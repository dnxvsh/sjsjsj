package com.stevebuddy;

import net.minecraftforge.common.ForgeConfigSpec;

/** Config file: config/stevebuddy-common.toml (created on first launch). */
public final class BuddyConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.ConfigValue<String> API_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> MODEL;
    public static final ForgeConfigSpec.ConfigValue<String> ENDPOINT;
    public static final ForgeConfigSpec.ConfigValue<String> NAME;
    public static final ForgeConfigSpec.ConfigValue<String> EXTRA_PERSONALITY;
    public static final ForgeConfigSpec.BooleanValue RESPOND_TO_ALL_CHAT;
    public static final ForgeConfigSpec.BooleanValue AUTO_DEFEND;
    public static final ForgeConfigSpec.BooleanValue ALLOW_DIGGING;
    public static final ForgeConfigSpec.BooleanValue TELEPORT_IF_FAR;
    public static final ForgeConfigSpec.IntValue MIN_SECONDS_BETWEEN_CALLS;
    public static final ForgeConfigSpec.IntValue MAX_AUTO_STEPS;
    public static final ForgeConfigSpec.IntValue HISTORY_TURNS;
    public static final ForgeConfigSpec.IntValue SCAN_RADIUS;
    public static final ForgeConfigSpec.DoubleValue MINING_SPEED;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment("AI settings").push("ai");
        API_KEY = b.comment("Your Gemini API key (from Google AI Studio). Keep it private! You can also set the GEMINI_API_KEY environment variable instead.")
                .define("apiKey", "");
        MODEL = b.comment("Gemini model id. If you get 404 / 'model no longer available', try another one (e.g. gemini-3.5-flash, gemini-3.1-flash-lite, gemini-3.6-flash).")
                .define("model", "gemini-3.5-flash");
        ENDPOINT = b.comment("Leave empty for the default Google endpoint. Advanced: custom base URL ending with /models/")
                .define("endpoint", "");
        MIN_SECONDS_BETWEEN_CALLS = b.comment("Minimum seconds between AI calls (protects your free-tier rate limit).")
                .defineInRange("minSecondsBetweenCalls", 3, 0, 120);
        MAX_AUTO_STEPS = b.comment("Max automatic follow-up AI calls per request (stops endless loops / cost).")
                .defineInRange("maxAutoSteps", 40, 1, 500);
        HISTORY_TURNS = b.comment("How many past exchanges Steve remembers.")
                .defineInRange("historyTurns", 10, 1, 50);
        b.pop();

        b.comment("Steve settings").push("steve");
        NAME = b.comment("Steve's name.").define("name", "Steve");
        EXTRA_PERSONALITY = b.comment("Extra personality text added to Steve's instructions (optional).")
                .define("extraPersonality", "");
        RESPOND_TO_ALL_CHAT = b.comment("true = Steve answers every chat message you send. false = only messages that contain his name.")
                .define("respondToAllChat", true);
        AUTO_DEFEND = b.comment("Steve automatically fights monsters that come near.")
                .define("autoDefend", true);
        ALLOW_DIGGING = b.comment("Allow Steve to dig tunnels toward blocks he can't walk to (ores underground).")
                .define("allowDigging", true);
        TELEPORT_IF_FAR = b.comment("Teleport Steve to you if he is more than 40 blocks away while following.")
                .define("teleportIfFar", true);
        MINING_SPEED = b.comment("Mining speed multiplier (1.0 = like a player).")
                .defineInRange("miningSpeed", 1.0D, 0.1D, 20.0D);
        SCAN_RADIUS = b.comment("How far (blocks) Steve 'sees' blocks around him when thinking.")
                .defineInRange("scanRadius", 14, 6, 24);
        b.pop();

        SPEC = b.build();
    }

    public static String name() {
        try {
            String n = NAME.get();
            return n == null || n.isBlank() ? "Steve" : n;
        } catch (Exception e) {
            return "Steve";
        }
    }

    private BuddyConfig() {}
}
