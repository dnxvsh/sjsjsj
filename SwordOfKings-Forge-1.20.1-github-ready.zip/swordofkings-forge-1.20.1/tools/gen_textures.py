#!/usr/bin/env python3
"""Generates every texture of the Sword of Kings mod (pixel art, procedural)."""
import json, math, os, random
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "swordofkings", "textures")
HS = 8  # supersampling factor for smooth shapes


def rgb(h):
    return ((h >> 16) & 255, (h >> 8) & 255, h & 255)


def downsample(hi, size, thr=110):
    """Box downsample then binarize alpha so edges stay crisp (pixel-art look)."""
    small = hi.resize((size, size), Image.BOX)
    px = small.load()
    for y in range(size):
        for x in range(size):
            r, g, b, a = px[x, y]
            px[x, y] = (r, g, b, 255) if a >= thr else (0, 0, 0, 0)
    return small


# ------------------------------------------------------------------ SWORD ----
S = 32
FRAMES = 16
P0, P1, P2 = (10.5, 22.0), (21.0, 15.5), (29.5, 2.5)


def bez(t):
    u = 1 - t
    return (u * u * P0[0] + 2 * u * t * P1[0] + t * t * P2[0],
            u * u * P0[1] + 2 * u * t * P1[1] + t * t * P2[1])


def bez_n(t):
    u = 1 - t
    dx = 2 * u * (P1[0] - P0[0]) + 2 * t * (P2[0] - P1[0])
    dy = 2 * u * (P1[1] - P0[1]) + 2 * t * (P2[1] - P1[1])
    l = math.hypot(dx, dy)
    return (-dy / l, dx / l), (dx / l, dy / l)  # normal (towards lower-right = edge), tangent


def half_width(t):
    hw = 1.95 * (1 - 0.35 * t)
    if t > 0.90:
        hw *= max(0.0, (1 - t) / 0.10)
    return hw


def sword_base():
    """Returns (layer image 32x32 RGBA, blade-mask image, wrap-mask) with static parts."""
    hi = Image.new("RGBA", (S * HS, S * HS), (0, 0, 0, 0))
    d = ImageDraw.Draw(hi)
    k = HS
    # blade polygon
    spine, edge = [], []
    N = 80
    for i in range(N + 1):
        t = i / N
        c = bez(t)
        n, _ = bez_n(t)
        hw = half_width(t)
        spine.append(((c[0] - n[0] * hw) * k, (c[1] - n[1] * hw) * k))
        edge.append(((c[0] + n[0] * hw) * k, (c[1] + n[1] * hw) * k))
    poly = spine + edge[::-1]
    d.polygon(poly, fill=rgb(0x4a4660) + (255,))
    # spine darker band
    sp2 = [((bez(i / N)[0] - bez_n(i / N)[0][0] * half_width(i / N) * 0.55) * k,
            (bez(i / N)[1] - bez_n(i / N)[0][1] * half_width(i / N) * 0.55) * k) for i in range(N + 1)]
    d.line(sp2, fill=rgb(0x2a2638) + (255,), width=int(0.9 * k))
    # hamon / bright edge line
    ed2 = [((bez(i / N)[0] + bez_n(i / N)[0][0] * half_width(i / N) * 0.62) * k,
            (bez(i / N)[1] + bez_n(i / N)[0][1] * half_width(i / N) * 0.62) * k) for i in range(N + 1)]
    d.line(ed2, fill=rgb(0xe9e9f6) + (255,), width=int(0.8 * k))
    # fuller glowing red line down the middle
    mid = [(bez(i / N)[0] * k, bez(i / N)[1] * k) for i in range(int(N * 0.9))]
    d.line(mid, fill=rgb(0x7d0c19) + (255,), width=int(0.6 * k))
    blade = downsample(hi, S)

    hi2 = Image.new("RGBA", (S * HS, S * HS), (0, 0, 0, 0))
    d2 = ImageDraw.Draw(hi2)
    # handle (tsuka)
    hx0, hy0, hx1, hy1 = 9.0, 23.5, 3.2, 29.3
    ang = math.atan2(hy1 - hy0, hx1 - hx0)
    nx, ny = -math.sin(ang), math.cos(ang)
    w = 1.35
    hpoly = [((hx0 + nx * w) * k, (hy0 + ny * w) * k), ((hx1 + nx * w) * k, (hy1 + ny * w) * k),
             ((hx1 - nx * w) * k, (hy1 - ny * w) * k), ((hx0 - nx * w) * k, (hy0 - ny * w) * k)]
    d2.polygon(hpoly, fill=(255, 255, 255, 255))
    d2.ellipse([(hx1 - 1.7) * k, (hy1 - 1.7) * k, (hx1 + 1.7) * k, (hy1 + 1.7) * k], fill=(255, 255, 255, 255))
    handle_mask = downsample(hi2, S)

    hi3 = Image.new("RGBA", (S * HS, S * HS), (0, 0, 0, 0))
    d3 = ImageDraw.Draw(hi3)
    # tsuba (guard) perpendicular to blade at base
    c = bez(0.0)
    c = (c[0] - 0.9, c[1] + 0.9)
    n, t = bez_n(0.0)
    L, T = 3.0, 0.75
    g = [((c[0] + n[0] * L + t[0] * T) * k, (c[1] + n[1] * L + t[1] * T) * k),
         ((c[0] + n[0] * L - t[0] * T) * k, (c[1] + n[1] * L - t[1] * T) * k),
         ((c[0] - n[0] * L - t[0] * T) * k, (c[1] - n[1] * L - t[1] * T) * k),
         ((c[0] - n[0] * L + t[0] * T) * k, (c[1] - n[1] * L + t[1] * T) * k)]
    d3.polygon(g, fill=(255, 255, 255, 255))
    guard_mask = downsample(hi3, S)
    return blade, handle_mask, guard_mask, c


def hash01(x, y, salt=0):
    v = math.sin(x * 12.9898 + y * 78.233 + salt * 37.719) * 43758.5453
    return v - math.floor(v)


def make_sword_frame(f, base):
    blade, handle_mask, guard_mask, gc = base
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    px = img.load()
    bp, hp, gp = blade.load(), handle_mask.load(), guard_mask.load()
    rnd = random.Random(1000 + f)
    pulse = 0.5 + 0.5 * math.sin(f / FRAMES * 2 * math.pi)

    # blade mask dilated -> aura ring
    mask = Image.new("L", (S, S), 0)
    mp = mask.load()
    for y in range(S):
        for x in range(S):
            if bp[x, y][3] or hp[x, y][3] or gp[x, y][3]:
                mp[x, y] = 255
    dil = mask.filter(ImageFilter.MaxFilter(5))
    dil2 = mask.filter(ImageFilter.MaxFilter(3))
    dp, dp2 = dil.load(), dil2.load()
    auras = [rgb(0xe01020), rgb(0xe01020), rgb(0xff5060), rgb(0xffffff), rgb(0x4a1068)]
    for y in range(S):
        for x in range(S):
            if dp[x, y] and not mp[x, y]:
                inner = dp2[x, y] > 0
                chance = (0.38 if inner else 0.10) * (0.55 + 0.7 * pulse)
                if hash01(x, y, f) < chance:
                    col = auras[int(hash01(x + 3, y + 7, f // 2) * len(auras))]
                    px[x, y] = col + (255,)

    # blade
    for y in range(S):
        for x in range(S):
            if bp[x, y][3]:
                r, g, b, _ = bp[x, y]
                # blood smears on lower half
                if hash01(x, y, 5) > 0.72 and (x + (S - y)) < 27:
                    r, g, b = rgb(0x7a0a14)
                px[x, y] = (r, g, b, 255)

    # flowing blood droplets along the blade
    for kk in range(6):
        s = ((kk * 0.17) + f / FRAMES) % 1.0
        c = bez(0.05 + s * 0.8)
        n, _ = bez_n(0.05 + s * 0.8)
        off = (kk % 3 - 1) * 0.55
        x = int(c[0] + n[0] * off)
        y = int(c[1] + n[1] * off)
        if 0 <= x < S and 0 <= y < S and bp[x, y][3]:
            px[x, y] = rgb(0xd0001c) + (255,)
            if 0 <= y + 1 < S and bp[x, y + 1][3]:
                px[x, y + 1] = rgb(0x8a0010) + (255,)

    # glint sweeping up the edge
    s = (f / FRAMES) * 1.4 - 0.2
    for i in range(160):
        t = i / 159
        if abs(t - s) < 0.045:
            c = bez(t)
            n, _ = bez_n(t)
            hw = half_width(t)
            x = int(c[0] + n[0] * hw * 0.62)
            y = int(c[1] + n[1] * hw * 0.62)
            if 0 <= x < S and 0 <= y < S and bp[x, y][3]:
                px[x, y] = (255, 255, 255, 255)

    # pulsing tip
    tip = bez(0.97)
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            x, y = int(tip[0]) + dx, int(tip[1]) + dy
            if 0 <= x < S and 0 <= y < S and (dx == 0 or dy == 0) and hash01(x, y, f) < 0.4 + 0.5 * pulse:
                px[x, y] = (255, int(60 + 150 * pulse), int(60 + 150 * pulse), 255)

    # handle with crimson/black silk wrap
    for y in range(S):
        for x in range(S):
            if hp[x, y][3]:
                if (x + y) % 2 == 0:
                    px[x, y] = rgb(0xa01428 if (f // 4) % 2 == 0 else 0xc01830) + (255,)
                else:
                    px[x, y] = rgb(0x120c18) + (255,)
    # guard
    for y in range(S):
        for x in range(S):
            if gp[x, y][3]:
                px[x, y] = rgb(0xc9a227) + (255,)
    gx, gy = int(gc[0]), int(gc[1])
    if 0 <= gx < S and 0 <= gy < S:
        px[gx, gy] = (255, 40, 40, 255) if f % 4 < 2 else (255, 210, 210, 255)

    # sparkles flying away
    for _ in range(4):
        t = rnd.random()
        c = bez(t)
        n, _ = bez_n(t)
        dist = rnd.uniform(2.6, 5.5)
        side = rnd.choice((-1, 1))
        x = int(c[0] + n[0] * dist * side)
        y = int(c[1] + n[1] * dist * side - rnd.uniform(0, 2))
        if 0 <= x < S and 0 <= y < S and not px[x, y][3]:
            px[x, y] = rnd.choice([rgb(0xffffff), rgb(0xff2030), rgb(0x6a1a8a)]) + (255,)

    # drips falling below the blade
    for kk, tt in enumerate((0.30, 0.52, 0.72)):
        c = bez(tt)
        n, _ = bez_n(tt)
        x = int(c[0] + n[0] * half_width(tt))
        y0 = int(c[1] + n[1] * half_width(tt)) + 1
        dy = int((f * 0.85 + kk * 5) % 10)
        y = y0 + dy
        if 0 <= x < S and 0 <= y < S and not px[x, y][3]:
            px[x, y] = rgb(0xc00018) + (255,)
            if dy > 2 and 0 <= y - 1 < S and not px[x, y - 1][3]:
                px[x, y - 1] = rgb(0x6a000c) + (255,)
    return img


def sword_sheet():
    base = sword_base()
    sheet = Image.new("RGBA", (S, S * FRAMES), (0, 0, 0, 0))
    for f in range(FRAMES):
        sheet.paste(make_sword_frame(f, base), (0, f * S))
    path = os.path.join(ROOT, "item", "sword_of_kings.png")
    sheet.save(path)
    with open(path + ".mcmeta", "w") as fh:
        json.dump({"animation": {"frametime": 2, "interpolate": False}}, fh, indent=2)
    return sheet


# ----------------------------------------------------------------- HAMMER ----
def hammer():
    k = HS
    hi = Image.new("RGBA", (S * k, S * k), (0, 0, 0, 0))
    d = ImageDraw.Draw(hi)
    # handle
    d.line([(4 * k, 28 * k), (20 * k, 12 * k)], fill=rgb(0x3b2a20) + (255,), width=int(2.4 * k))
    d.line([(4 * k, 28 * k), (20 * k, 12 * k)], fill=rgb(0x5a4030) + (255,), width=int(1.0 * k))
    # head: rotated rectangle
    cx, cy = 22.5, 9.5
    a = math.radians(-45)
    ux, uy = math.cos(a), math.sin(a)
    vx, vy = -uy, ux
    L, W = 8.5, 5.2

    def pt(su, sv):
        return ((cx + ux * su + vx * sv) * k, (cy + uy * su + vy * sv) * k)
    head = [pt(-L, -W), pt(L, -W), pt(L, W), pt(-L, W)]
    d.polygon(head, fill=rgb(0x2a2733) + (255,))
    d.polygon([pt(-L + 0.8, -W + 0.8), pt(L - 0.8, -W + 0.8), pt(L - 0.8, 0), pt(-L + 0.8, 0)], fill=rgb(0x3c384a) + (255,))
    for su in (-L, L):
        d.polygon([pt(su - 0.9, -W - .3), pt(su + 0.9, -W - .3), pt(su + 0.9, W + .3), pt(su - 0.9, W + .3)], fill=rgb(0xc9a227) + (255,))
    d.ellipse([ (cx - 1.5) * k, (cy - 1.5) * k, (cx + 1.5) * k, (cy + 1.5) * k], fill=rgb(0xb01020) + (255,))
    img = downsample(hi, S)
    img.save(os.path.join(ROOT, "item", "kings_hammer.png"))


# ------------------------------------------------------------------- GEMS ----
def gem(name, base, light, dark, glint):
    G = 16
    k = 16
    hi = Image.new("RGBA", (G * k, G * k), (0, 0, 0, 0))
    d = ImageDraw.Draw(hi)
    top = [(8, 1), (13, 4), (3, 4)]
    left = [(3, 4), (8, 4), (8, 15), (2, 9)]
    right = [(13, 4), (8, 4), (8, 15), (14, 9)]
    band = [(3, 4), (13, 4), (14, 9), (2, 9)]
    d.polygon([(x * k, y * k) for x, y in [(8, 1), (13, 4), (14, 9), (8, 15), (2, 9), (3, 4)]], fill=base + (255,))
    d.polygon([(x * k, y * k) for x, y in left], fill=dark + (255,))
    d.polygon([(x * k, y * k) for x, y in right], fill=base + (255,))
    d.polygon([(x * k, y * k) for x, y in top], fill=light + (255,))
    d.polygon([(x * k, y * k) for x, y in [(3, 4), (8, 4), (6, 9), (2, 9)]], fill=base + (255,))
    img = downsample(hi, G)
    px = img.load()
    for (x, y) in ((6, 3), (5, 5), (9, 3)):
        if px[x, y][3]:
            px[x, y] = glint + (255,)
    img.save(os.path.join(ROOT, "item", name + ".png"))


# ------------------------------------------------------------------- BOSS ----
class Skin:
    def __init__(self):
        self.img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        self.px = self.img.load()
        self.rnd = random.Random(7)

    def fill(self, x, y, w, h, col, noise=6):
        for j in range(h):
            for i in range(w):
                n = self.rnd.randint(-noise, noise)
                self.px[x + i, y + j] = tuple(max(0, min(255, c + n)) for c in col) + (255,)

    def box(self, u, v, w, h, d, top, bottom, right, front, left, back, noise=6):
        self.fill(u + d, v, w, d, top, noise)
        self.fill(u + d + w, v, w, d, bottom, noise)
        self.fill(u, v + d, d, h, right, noise)
        self.fill(u + d, v + d, w, h, front, noise)
        self.fill(u + d + w, v + d, d, h, left, noise)
        self.fill(u + 2 * d + w, v + d, w, h, back, noise)

    def put(self, x, y, col):
        self.px[x, y] = col + (255,)


def boss():
    PALE, ASH = rgb(0xaeaab8), rgb(0x8a8696)
    ROBE, ROBE2, GOLD, CRIM, BLACK = rgb(0x1e1028), rgb(0x2b1838), rgb(0xc9a227), rgb(0x7a0f1a), rgb(0x0e0a12)
    BEARD = rgb(0xc8c8d2)
    s = Skin()
    # head (0,0) 8x8x8
    s.box(0, 0, 8, 8, 8, BLACK, ASH, ASH, PALE, ASH, BLACK)
    # beard + face details on front face (8,8)
    s.fill(8, 8 + 5, 8, 3, BEARD)
    s.fill(8 + 2, 8 + 5, 4, 1, PALE)  # mouth gap
    s.put(8 + 3, 8 + 5, BLACK); s.put(8 + 4, 8 + 5, BLACK)
    for (ex, ey) in ((1, 3), (2, 3), (5, 3), (6, 3)):
        s.put(8 + ex, 8 + ey, BLACK)
    for (ex, ey) in ((0, 2), (1, 2), (2, 2), (5, 2), (6, 2), (7, 2)):
        s.put(8 + ex, 8 + ey, rgb(0x5a1a2a))
    # beard on sides
    for ox in (0, 16):
        s.fill(ox, 8 + 5, 8, 3, BEARD)
    s.fill(24, 8 + 5, 8, 3, BEARD)
    # hat layer (32,0): crown band
    hat = Skin()
    hat.box(32, 0, 8, 8, 8, GOLD, (0, 0, 0), GOLD, GOLD, GOLD, GOLD, noise=4)
    # clear everything except crown rows (top 3 rows of the side faces) and top face
    for y in range(64):
        for x in range(32, 64):
            if hat.px[x, y][3]:
                pass
    # erase bottom part of the sides + bottom face to keep only crown
    for y in range(8 + 3, 16):
        for x in range(32, 64):
            hat.px[x, y] = (0, 0, 0, 0)
    for y in range(0, 8):
        for x in range(48, 56):  # bottom face
            hat.px[x, y] = (0, 0, 0, 0)
    # spikes: notch every other pixel on the top row of the sides
    for x in range(32, 64):
        if (x % 2) == 0 and hat.px[x, 8][3] and 8 + 0 == 8:
            hat.px[x, 8] = (0, 0, 0, 0)
    # red gems in the crown (front face of hat = x 40..47, y 8..15)
    for gx in (41, 43, 45):
        hat.px[gx, 10] = rgb(0xd01428) + (255,)
    hat.px[44, 3] = rgb(0xd01428) + (255,)
    hat.px[43, 3] = rgb(0xd01428) + (255,)
    # merge hat into skin
    for y in range(16):
        for x in range(32, 64):
            if hat.px[x, y][3]:
                s.px[x, y] = hat.px[x, y]

    # body (16,16) 8x12x4
    s.box(16, 16, 8, 12, 4, ROBE2, BLACK, ROBE, ROBE, ROBE, rgb(0x3c0a14))
    # gold trim down front center + belt
    s.fill(16 + 4 + 3, 16 + 4, 2, 12, GOLD)
    s.fill(16 + 4, 16 + 4 + 8, 8, 2, CRIM)
    s.fill(16 + 4 + 3, 16 + 4 + 8, 2, 2, GOLD)
    s.fill(16 + 4, 16 + 4, 8, 1, GOLD)
    # arms (40,16) 4x12x4  (left arm mirrors the same UV)
    s.box(40, 16, 4, 12, 4, ROBE2, ROBE2, ROBE, ROBE, ROBE, ROBE)
    s.fill(40 + 4, 16 + 4 + 6, 4, 2, GOLD)   # bracer (front)
    s.fill(40, 16 + 4 + 6, 4, 2, GOLD)
    s.fill(40 + 8, 16 + 4 + 6, 4, 2, GOLD)
    s.fill(40 + 12, 16 + 4 + 6, 4, 2, GOLD)
    for (fx) in (40, 44, 48, 52):
        s.fill(fx, 16 + 4 + 9, 4, 3, ASH)       # hands
    s.fill(44, 16, 4, 4, ROBE2); s.fill(48, 16, 4, 4, ASH)
    # legs (0,16) 4x12x4
    s.box(0, 16, 4, 12, 4, ROBE, BLACK, ROBE, ROBE, ROBE, ROBE)
    for (fx) in (0, 4, 8, 12):
        s.fill(fx, 16 + 4 + 9, 4, 3, BLACK)     # boots
        s.fill(fx, 16 + 4 + 8, 4, 1, GOLD)
    s.fill(4 + 1, 16 + 4, 2, 8, CRIM)
    s.img.save(os.path.join(ROOT, "entity", "king_boss.png"))

    # emissive eyes
    e = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    ep = e.load()
    for (ex, ey) in ((1, 3), (2, 3), (5, 3), (6, 3)):
        ep[8 + ex, 8 + ey] = (255, 24, 24, 255)
    ep[8 + 2, 8 + 3] = (255, 200, 200, 255)
    ep[8 + 5, 8 + 3] = (255, 200, 200, 255)
    e.save(os.path.join(ROOT, "entity", "king_boss_eyes.png"))


if __name__ == "__main__":
    sheet = sword_sheet()
    hammer()
    gem("kings_gem_red", rgb(0xd0142c), rgb(0xff6a7a), rgb(0x7a0716), rgb(0xffffff))
    gem("kings_gem_black", rgb(0x1c1030), rgb(0x5a3a8c), rgb(0x08040f), rgb(0xe0b0ff))
    gem("kings_gem_white", rgb(0xe8eef8), rgb(0xffffff), rgb(0xa8b4cc), rgb(0xffffff))
    boss()
    print("textures ok")
