package com.swordofkings.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.swordofkings.SwordOfKingsMod;
import com.swordofkings.entity.KingBossEntity;
import com.swordofkings.registry.ModEntities;
import com.swordofkings.registry.ModItems;
import com.swordofkings.world.BossProgress;
import com.swordofkings.world.KingsWorldData;
import com.swordofkings.world.VaultBuilder;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * /swordofkings progress            - boss kills so far
 * /swordofkings map                 - get the treasure map again (needs the 3 kills)
 * (op) give | unlock | boss | vault | tpvault  - testing helpers
 */
@Mod.EventBusSubscriber(modid = SwordOfKingsMod.MODID)
public final class ModCommands {
    @SubscribeEvent
    public static void onRegister(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        d.register(Commands.literal("swordofkings")
                .then(Commands.literal("progress").executes(c -> progress(c.getSource().getPlayerOrException(), c.getSource())))
                .then(Commands.literal("map").executes(c -> map(c.getSource().getPlayerOrException(), c.getSource())))
                .then(Commands.literal("give").requires(s -> s.hasPermission(2)).executes(c -> give(c.getSource().getPlayerOrException(), c.getSource())))
                .then(Commands.literal("unlock").requires(s -> s.hasPermission(2)).executes(c -> unlock(c.getSource().getPlayerOrException(), c.getSource())))
                .then(Commands.literal("boss").requires(s -> s.hasPermission(2)).executes(c -> boss(c.getSource().getPlayerOrException(), c.getSource())))
                .then(Commands.literal("vault").requires(s -> s.hasPermission(2)).executes(c -> vault(c.getSource().getPlayerOrException(), c.getSource())))
                .then(Commands.literal("tpvault").requires(s -> s.hasPermission(2)).executes(c -> tpVault(c.getSource().getPlayerOrException(), c.getSource()))));
    }

    private static String mark(boolean b) {
        return b ? "✔" : "✘";
    }

    private static int progress(ServerPlayer p, CommandSourceStack src) {
        KingsWorldData.Progress pr = KingsWorldData.get(p.getServer()).of(p.getUUID());
        src.sendSuccess(() -> Component.translatable("msg.swordofkings.progress",
                Component.translatable("boss.swordofkings.dragon"), mark(pr.dragon),
                Component.translatable("boss.swordofkings.wither"), mark(pr.wither),
                Component.translatable("boss.swordofkings.warden"), mark(pr.warden)).withStyle(ChatFormatting.GOLD), false);
        return pr.count();
    }

    private static int map(ServerPlayer p, CommandSourceStack src) throws CommandSyntaxException {
        KingsWorldData.Progress pr = KingsWorldData.get(p.getServer()).of(p.getUUID());
        if (!pr.allBosses()) {
            src.sendFailure(Component.translatable("msg.swordofkings.no_map_yet"));
            return 0;
        }
        BossProgress.giveMap(p);
        return 1;
    }

    private static int give(ServerPlayer p, CommandSourceStack src) {
        ItemStack sword = new ItemStack(ModItems.SWORD_OF_KINGS.get());
        if (!p.getInventory().add(sword)) p.drop(sword, false);
        return 1;
    }

    private static int unlock(ServerPlayer p, CommandSourceStack src) {
        KingsWorldData data = KingsWorldData.get(p.getServer());
        KingsWorldData.Progress pr = data.of(p.getUUID());
        pr.dragon = pr.wither = pr.warden = true;
        data.setDirty();
        BossProgress.giveMap(p);
        return 1;
    }

    private static int boss(ServerPlayer p, CommandSourceStack src) {
        ServerLevel level = p.serverLevel();
        KingBossEntity boss = ModEntities.KING_BOSS.get().create(level);
        if (boss == null) return 0;
        boss.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot() + 180.0F, 0.0F);
        level.addFreshEntity(boss);
        return 1;
    }

    /** Builds a vault around the player's feet (testing only: it overwrites a 19x19x11 area). */
    private static int vault(ServerPlayer p, CommandSourceStack src) {
        VaultBuilder.buildAt(p.serverLevel(), p.blockPosition().below(2), p.getRandom());
        return 1;
    }

    private static int tpVault(ServerPlayer p, CommandSourceStack src) {
        KingsWorldData.Progress pr = KingsWorldData.get(p.getServer()).of(p.getUUID());
        if (!pr.hasVault) {
            src.sendFailure(Component.translatable("msg.swordofkings.no_vault"));
            return 0;
        }
        BlockPos v = pr.vaultPos();
        ServerLevel overworld = p.getServer().overworld();
        p.teleportTo(overworld, v.getX() + 0.5, v.getY() + 1.0, v.getZ() + 5.5, p.getYRot(), p.getXRot());
        return 1;
    }

    private ModCommands() {}
}
