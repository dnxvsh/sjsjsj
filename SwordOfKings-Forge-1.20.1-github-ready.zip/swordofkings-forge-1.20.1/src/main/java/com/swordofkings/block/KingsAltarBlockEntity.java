package com.swordofkings.block;

import com.swordofkings.ability.Fx;
import com.swordofkings.entity.KingBossEntity;
import com.swordofkings.item.SwordOfKingsItem;
import com.swordofkings.registry.ModBlockEntities;
import com.swordofkings.registry.ModEntities;
import com.swordofkings.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * State machine of the altar:
 * ARMED (sword floats, waiting) -> SUMMONING (players hurled back) -> BOSS (the Forsaken King fights)
 * -> CLAIMABLE (king dead, sword answers the next player who comes close) -> EMPTY (sword taken).
 */
public class KingsAltarBlockEntity extends BlockEntity {
    public static final int ARMED = 0;
    public static final int SUMMONING = 1;
    public static final int BOSS = 2;
    public static final int CLAIMABLE = 3;
    public static final int EMPTY = 4;

    public static final int CLAIM_TICKS = 34;
    private static final double TRIGGER_RADIUS = 5.5;
    private static final double CLAIM_RADIUS = 4.5;
    private static final int SUMMON_TICKS = 44;

    private static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(0.9F, 0.02F, 0.06F), 1.8F);
    private static final DustParticleOptions BLACK = new DustParticleOptions(new Vector3f(0.04F, 0.0F, 0.07F), 2.4F);
    private static final DustParticleOptions WHITE = new DustParticleOptions(new Vector3f(1.0F, 1.0F, 1.0F), 1.5F);

    private int phase = ARMED;
    private int summonTicks;
    private int missingTicks;
    @Nullable private UUID bossId;
    @Nullable private UUID claimant;
    private long claimStart = -1L;

    public KingsAltarBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ALTAR.get(), pos, state);
    }

    public int getPhase() { return phase; }
    @Nullable public UUID getClaimant() { return claimant; }
    public long getClaimStart() { return claimStart; }

    // ----------------------------------------------------------------- server
    public static void serverTick(Level level, BlockPos pos, BlockState state, KingsAltarBlockEntity be) {
        if (!(level instanceof ServerLevel server)) return;
        switch (be.phase) {
            case ARMED -> {
                if (level.getGameTime() % 5L == 0L
                        && level.getNearestPlayer(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, TRIGGER_RADIUS, e -> !e.isSpectator()) != null) {
                    be.trigger(server, pos);
                }
            }
            case SUMMONING -> be.tickSummoning(server, pos);
            case BOSS -> be.tickBoss(server);
            case CLAIMABLE -> be.tickClaimable(server, pos);
            default -> { }
        }
    }

    /** A player came close: hurl everybody back with great force, then the king rises. */
    private void trigger(ServerLevel level, BlockPos pos) {
        phase = SUMMONING;
        summonTicks = 0;
        Vec3 c = Vec3.atCenterOf(pos).add(0, 1.0, 0);
        for (Player p : level.getEntitiesOfClass(Player.class, new AABB(pos).inflate(9.0), e -> !e.isSpectator())) {
            Vec3 away = p.position().subtract(c).multiply(1, 0, 1);
            if (away.lengthSqr() < 1.0E-4) away = new Vec3(1, 0, 0);
            p.setDeltaMovement(away.normalize().scale(2.4).add(0, 0.85, 0));
            p.hurtMarked = true;
            p.displayClientMessage(Component.translatable("msg.swordofkings.altar_pushed").withStyle(ChatFormatting.DARK_RED), true);
        }
        Fx.particle(level, ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        Fx.particle(level, ParticleTypes.SONIC_BOOM, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        Fx.burstRing(level, ParticleTypes.END_ROD, c, 48, 0.9);
        Fx.burstRing(level, Fx.RED, c, 48, 0.7);
        Fx.burstRing(level, Fx.BLACK, c, 48, 0.5);
        Fx.flash(level, c, 40, 0xFFFFFF, 0.8F, 12);
        Fx.shake(level, c, 40, 2.0F, 36);
        Fx.sound(level, c.x, c.y, c.z, SoundEvents.WARDEN_SONIC_BOOM, 5.0F, 0.6F);
        Fx.sound(level, c.x, c.y, c.z, SoundEvents.LIGHTNING_BOLT_THUNDER, 5.0F, 0.6F);
        Fx.sound(level, c.x, c.y, c.z, SoundEvents.ENDER_DRAGON_GROWL, 4.0F, 0.6F);
        sync(level);
    }

    private void tickSummoning(ServerLevel level, BlockPos pos) {
        summonTicks++;
        Vec3 spawn = spawnPos(level, pos);
        Vec3 c = Vec3.atCenterOf(pos).add(0, 1.0, 0);
        // darkness streams from the sword to the place the king will stand
        if (summonTicks % 2 == 0) {
            Fx.line(level, Fx.BLACK, c, spawn.add(0, 1.2, 0), 0.9);
            Fx.particle(level, ParticleTypes.SOUL, spawn.x, spawn.y + 0.5, spawn.z, 8, 0.6, 1.2, 0.6, 0.04);
        }
        if (summonTicks % 10 == 0) {
            Fx.bolt(level, spawn.x + (level.random.nextDouble() - 0.5) * 3, spawn.y, spawn.z + (level.random.nextDouble() - 0.5) * 3);
            Fx.sound(level, spawn.x, spawn.y, spawn.z, SoundEvents.WARDEN_HEARTBEAT, 4.0F, 0.5F);
        }
        if (summonTicks >= SUMMON_TICKS) {
            KingBossEntity boss = ModEntities.KING_BOSS.get().create(level);
            if (boss == null) {
                phase = ARMED;
                sync(level);
                return;
            }
            boss.moveTo(spawn.x, spawn.y, spawn.z, level.random.nextFloat() * 360.0F, 0.0F);
            boss.setAltar(pos);
            level.addFreshEntity(boss);
            bossId = boss.getUUID();
            missingTicks = 0;
            phase = BOSS;
            for (int i = 0; i < 4; i++) {
                double a = i * Math.PI / 2;
                Fx.bolt(level, spawn.x + Math.cos(a) * 2.5, spawn.y, spawn.z + Math.sin(a) * 2.5);
            }
            Fx.particle(level, ParticleTypes.EXPLOSION_EMITTER, spawn.x, spawn.y + 1, spawn.z, 1, 0, 0, 0, 0);
            Fx.burstRing(level, Fx.BLACK, spawn.add(0, 0.5, 0), 40, 0.6);
            Fx.sound(level, spawn.x, spawn.y, spawn.z, SoundEvents.WITHER_SPAWN, 4.0F, 0.6F);
            Fx.shake(level, spawn, 40, 1.6F, 30);
            sync(level);
        }
    }

    private void tickBoss(ServerLevel level) {
        if (level.getGameTime() % 20L != 0L) return;
        Entity boss = bossId == null ? null : level.getEntity(bossId);
        if (boss != null && boss.isAlive()) {
            missingTicks = 0;
            return;
        }
        missingTicks += 20;
        if (missingTicks >= 200) {           // boss vanished without dying (discarded, killed by /kill ...): re-arm the altar
            phase = ARMED;
            bossId = null;
            sync(level);
        }
    }

    /** Called by the boss when it dies. */
    public void onBossDefeated() {
        if (!(level instanceof ServerLevel server)) return;
        phase = CLAIMABLE;
        bossId = null;
        claimant = null;
        claimStart = -1L;
        Vec3 c = Vec3.atCenterOf(worldPosition).add(0, 1.5, 0);
        Fx.bolt(server, c.x, worldPosition.getY() + 1, c.z);
        Fx.burstRing(server, Fx.WHITE, c, 36, 0.4);
        Fx.sound(server, c.x, c.y, c.z, SoundEvents.BEACON_ACTIVATE, 4.0F, 0.6F);
        for (Player p : server.getEntitiesOfClass(Player.class, new AABB(worldPosition).inflate(40.0))) {
            p.displayClientMessage(Component.translatable("msg.swordofkings.king_fallen").withStyle(ChatFormatting.GOLD), true);
        }
        sync(server);
    }

    private void tickClaimable(ServerLevel level, BlockPos pos) {
        long now = level.getGameTime();
        if (claimant == null) {
            if (now % 5L != 0L) return;
            Player p = level.getNearestPlayer(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, CLAIM_RADIUS, e -> !e.isSpectator());
            if (p instanceof ServerPlayer) {
                claimant = p.getUUID();
                claimStart = now;
                Vec3 c = Vec3.atCenterOf(pos).add(0, 1.5, 0);
                Fx.sound(level, c.x, c.y, c.z, SoundEvents.BEACON_POWER_SELECT, 3.0F, 0.5F);
                Fx.sound(level, c.x, c.y, c.z, SoundEvents.ENDER_DRAGON_GROWL, 2.0F, 1.4F);
                Fx.flash(level, c, 24, 0xFFFFFF, 0.5F, 8);
                sync(level);
            }
            return;
        }
        Player p = level.getPlayerByUUID(claimant);
        if (!(p instanceof ServerPlayer sp) || p.isRemoved() || p.level() != level) {
            claimant = null;
            claimStart = -1L;
            sync(level);
            return;
        }
        long age = now - claimStart;
        Vec3 from = Vec3.atCenterOf(pos).add(0, 1.5, 0);
        Vec3 to = sp.position().add(0, sp.getBbHeight() * 0.6, 0);
        double prog = Math.min(1.0, age / (double) CLAIM_TICKS);
        Vec3 now3 = from.lerp(to, prog * prog * (3 - 2 * prog));
        Fx.particle(level, Fx.RED, now3.x, now3.y, now3.z, 3, 0.15, 0.15, 0.15, 0.0);
        Fx.particle(level, ParticleTypes.ELECTRIC_SPARK, now3.x, now3.y, now3.z, 4, 0.2, 0.2, 0.2, 0.1);
        if (age % 6 == 0) Fx.sound(level, now3.x, now3.y, now3.z, SoundEvents.AMETHYST_BLOCK_CHIME, 2.0F, 0.5F + (float) prog);

        if (age >= CLAIM_TICKS) {
            ItemStack sword = SwordOfKingsItem.forgeFor(sp, new ItemStack(ModItems.SWORD_OF_KINGS.get()));
            if (!sp.getInventory().add(sword)) sp.drop(sword, false);
            phase = EMPTY;
            claimant = null;
            claimStart = -1L;
            Vec3 c = sp.position().add(0, 1.0, 0);
            Fx.bolt(level, sp.getX(), sp.getY(), sp.getZ());
            Fx.burstRing(level, Fx.RED, c, 48, 0.8);
            Fx.burstRing(level, Fx.WHITE, c, 48, 0.6);
            Fx.burstRing(level, ParticleTypes.ELECTRIC_SPARK, c, 48, 1.0);
            Fx.flash(level, c, 48, 0xFFFFFF, 0.9F, 14);
            Fx.shake(level, c, 48, 1.4F, 30);
            Fx.sound(level, c.x, c.y, c.z, SoundEvents.LIGHTNING_BOLT_IMPACT, 4.0F, 0.8F);
            Fx.sound(level, c.x, c.y, c.z, SoundEvents.END_PORTAL_SPAWN, 2.0F, 1.2F);
            level.getServer().getPlayerList().broadcastSystemMessage(
                    Component.translatable("msg.swordofkings.claimed", sp.getDisplayName()).withStyle(ChatFormatting.DARK_RED), false);
            sync(level);
        }
    }

    private Vec3 spawnPos(ServerLevel level, BlockPos pos) {
        int[][] offsets = {{0, 4}, {4, 0}, {-4, 0}, {0, -4}, {3, 3}, {-3, -3}, {3, -3}, {-3, 3}};
        for (int[] o : offsets) {
            double x = pos.getX() + 0.5 + o[0], y = pos.getY(), z = pos.getZ() + 0.5 + o[1];
            AABB box = new AABB(x - 0.5, y, z - 0.5, x + 0.5, y + 2.8, z + 0.5);
            if (level.noCollision(box)) return new Vec3(x, y, z);
        }
        return new Vec3(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
    }

    // ----------------------------------------------------------------- client
    /** The huge red / black / white aura around the floating sword. */
    public static void clientTick(Level level, BlockPos pos, BlockState state, KingsAltarBlockEntity be) {
        if (be.phase == EMPTY) return;
        RandomSource r = level.random;
        long t = level.getGameTime();
        double cx = pos.getX() + 0.5, cz = pos.getZ() + 0.5, cy = pos.getY() + 2.0;
        boolean angry = be.phase == SUMMONING || be.phase == BOSS;
        int arms = angry ? 7 : 5;
        for (int i = 0; i < arms; i++) {
            double a = t * (angry ? 0.28 : 0.14) + i * (Math.PI * 2 / arms);
            double rad = 0.9 + 0.55 * Math.sin(t * 0.07 + i);
            double h = ((t * 0.05 + i * 0.37) % 2.4) - 1.1;
            DustParticleOptions col = i % 3 == 0 ? RED : (i % 3 == 1 ? WHITE : BLACK);
            level.addParticle(col, cx + Math.cos(a) * rad, cy + h, cz + Math.sin(a) * rad, 0, 0, 0);
        }
        for (int i = 0; i < 3; i++) {
            double a = -t * 0.05 + i * (Math.PI * 2 / 3) + r.nextDouble() * 0.4;
            level.addParticle(BLACK, cx + Math.cos(a) * 2.9, pos.getY() + 1.08, cz + Math.sin(a) * 2.9, 0, 0.01, 0);
            level.addParticle(RED, cx + Math.cos(a + 0.9) * 2.2, pos.getY() + 1.08, cz + Math.sin(a + 0.9) * 2.2, 0, 0.02, 0);
        }
        if (r.nextInt(2) == 0) {
            level.addParticle(ParticleTypes.ELECTRIC_SPARK, cx + (r.nextDouble() - 0.5) * 2.4, cy + (r.nextDouble() - 0.5) * 2.4,
                    cz + (r.nextDouble() - 0.5) * 2.4, 0, 0, 0);
        }
        if (r.nextInt(5) == 0) {
            level.addParticle(ParticleTypes.END_ROD, cx, cy - 0.6, cz, (r.nextDouble() - 0.5) * 0.12, 0.07, (r.nextDouble() - 0.5) * 0.12);
        }
        if (t % 70L == 0L) {
            level.playLocalSound(cx, cy, cz, SoundEvents.BEACON_AMBIENT, SoundSource.BLOCKS, 1.0F, 0.5F, false);
            level.playLocalSound(cx, cy, cz, SoundEvents.WARDEN_HEARTBEAT, SoundSource.BLOCKS, 1.2F, 0.7F, false);
        }
    }

    // ---------------------------------------------------------- persistence
    private void sync(Level level) {
        setChanged();
        level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Phase", phase);
        tag.putLong("ClaimStart", claimStart);
        if (bossId != null) tag.putUUID("Boss", bossId);
        if (claimant != null) tag.putUUID("Claimant", claimant);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        phase = tag.getInt("Phase");
        if (phase == SUMMONING) phase = ARMED;     // a half-finished summoning restarts after a reload
        claimStart = tag.contains("ClaimStart") ? tag.getLong("ClaimStart") : -1L;
        bossId = tag.hasUUID("Boss") ? tag.getUUID("Boss") : null;
        claimant = tag.hasUUID("Claimant") ? tag.getUUID("Claimant") : null;
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag);
        return tag;
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public AABB getRenderBoundingBox() {
        return new AABB(worldPosition).inflate(8.0).expandTowards(0, 4, 0);
    }
}
