package com.swordofkings.ability;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.EnderDragonPart;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

public final class TargetFinder {
    /** The living entity the player is looking at (or the best one inside a narrow cone), or null. */
    @Nullable
    public static LivingEntity find(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(range));
        AABB box = p.getBoundingBox().expandTowards(look.scale(range)).inflate(2.0D);

        EntityHitResult hit = ProjectileUtil.getEntityHitResult(p.level(), p, eye, end, box,
                e -> !e.isSpectator() && e.isPickable() && e != p && (e instanceof LivingEntity || e instanceof EnderDragonPart));
        if (hit != null) {
            LivingEntity le = resolve(hit.getEntity());
            if (le != null && AbilityUtil.canHarm(p, le)) return le;
        }

        LivingEntity best = null;
        double bestScore = -1;
        for (LivingEntity le : p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range),
                e -> AbilityUtil.canHarm(p, e))) {
            Vec3 to = le.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist > range || dist < 0.5) continue;
            double dot = to.normalize().dot(look);
            if (dot < 0.86) continue;
            double score = dot - dist * 0.003;
            if (score > bestScore) {
                bestScore = score;
                best = le;
            }
        }
        return best;
    }

    @Nullable
    public static LivingEntity resolve(Entity e) {
        if (e instanceof EnderDragonPart part) return part.parentMob;
        return e instanceof LivingEntity le ? le : null;
    }

    private TargetFinder() {}
}
