package com.swordofkings.ability;

import com.swordofkings.SwordOfKingsMod;
import com.swordofkings.network.CooldownPacket;
import com.swordofkings.network.ModNetwork;
import com.swordofkings.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Receives key presses from the client, checks cooldowns and starts the matching ability. */
@Mod.EventBusSubscriber(modid = SwordOfKingsMod.MODID)
public final class AbilityManager {
    public static final int LIGHTNING = 0;
    public static final int DARKNESS = 1;
    public static final int RUSH = 2;
    public static final int GEMS = 3;
    public static final int RECALL = 4;

    /** Cooldowns in ticks (20 ticks = 1 second). */
    public static final int[] COOLDOWN = {160, 320, 140, 260};

    private static final Map<UUID, int[]> READY_AT = new HashMap<>();

    public static void handle(ServerPlayer player, int id) {
        if (id == RECALL) {
            SwordRecall.recall(player);
            return;
        }
        if (id < 0 || id > 3) return;
        if (!holdsSword(player)) {
            player.displayClientMessage(Component.translatable("msg.swordofkings.hold_sword").withStyle(ChatFormatting.RED), true);
            return;
        }
        int now = player.getServer().getTickCount();
        int[] ready = READY_AT.computeIfAbsent(player.getUUID(), k -> new int[4]);
        if (now < ready[id]) {
            int left = (ready[id] - now + 19) / 20;
            player.displayClientMessage(Component.translatable("msg.swordofkings.cooldown", left).withStyle(ChatFormatting.GRAY), true);
            return;
        }

        boolean started;
        switch (id) {
            case LIGHTNING -> started = LightningStorm.start(player);
            case DARKNESS -> started = DarknessControl.start(player);
            case RUSH -> started = ThunderRush.start(player);
            default -> started = GemBarrage.start(player);
        }
        if (!started) return;

        int cooldown = player.isCreative() ? 20 : COOLDOWN[id];
        ready[id] = now + cooldown;
        ModNetwork.toPlayer(player, new CooldownPacket(id, cooldown));
    }

    public static boolean holdsSword(ServerPlayer p) {
        return p.getMainHandItem().is(ModItems.SWORD_OF_KINGS.get()) || p.getOffhandItem().is(ModItems.SWORD_OF_KINGS.get());
    }

    static void noTarget(ServerPlayer p) {
        p.displayClientMessage(Component.translatable("msg.swordofkings.no_target").withStyle(ChatFormatting.GRAY), true);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        READY_AT.clear();
    }

    private AbilityManager() {}
}
