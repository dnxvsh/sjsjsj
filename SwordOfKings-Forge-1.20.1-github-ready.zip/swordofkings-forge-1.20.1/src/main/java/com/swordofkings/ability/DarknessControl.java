package com.swordofkings.ability;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Ability 2 (X): dense darkness gathers into a black tornado, pulls enemies in, then detonates. */
public final class DarknessControl {
    private static final int BUILDUP = 70;
    private static final double PULL_RADIUS = 15.0;
    private static final double BLAST_RADIUS = 13.0;

    public static boolean start(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        LivingEntity target = TargetFinder.find(player, 48.0D);
        final Vec3 center;
        if (target != null) {
            center = target.position();
        } else {
            HitResult hit = player.pick(40.0D, 1.0F, false);
            center = hit.getLocation();
        }

        Fx.sound(level, center.x, center.y, center.z, SoundEvents.WITHER_SPAWN, 2.5F, 0.5F);
        Fx.flash(level, center, 60, 0x000000, 0.7F, 30);
        final int[] age = {0};

        ServerEffects.add(() -> {
            int t = age[0]++;
            if (player.isRemoved()) return true;

            if (t < BUILDUP) {
                double height = Math.min(18.0, 2.0 + t * 0.3);
                double base = t * 0.45;
                // black funnel: three spiralling arms that widen towards the top
                for (int arm = 0; arm < 3; arm++) {
                    for (double h = 0; h <= height; h += 1.25) {
                        double r = 1.0 + h * 0.38;
                        double a = base + arm * (Math.PI * 2 / 3) + h * 0.55;
                        double x = center.x + Math.cos(a) * r;
                        double z = center.z + Math.sin(a) * r;
                        Fx.particle(level, Fx.BLACK, x, center.y + h, z, 1, 0.1, 0.1, 0.1, 0.0);
                        if (((int) (h * 4) + t) % 5 == 0) Fx.particle(level, ParticleTypes.SQUID_INK, x, center.y + h, z, 1, 0.1, 0.1, 0.1, 0.02);
                    }
                }
                // darkness collapsing inwards along the ground
                double ringR = 13.0 - 10.5 * (t / (double) BUILDUP);
                for (int i = 0; i < 18; i++) {
                    double a = i * (Math.PI * 2 / 18) - t * 0.2;
                    Fx.particle(level, Fx.BLACK, center.x + Math.cos(a) * ringR, center.y + 0.2, center.z + Math.sin(a) * ringR, 2, 0.2, 0.1, 0.2, 0.0);
                }
                if (t % 4 == 0) {
                    Fx.particle(level, ParticleTypes.SOUL, center.x, center.y + 1, center.z, 6, 2.5, 1.5, 2.5, 0.03);
                    Fx.particle(level, Fx.RED, center.x, center.y + 2, center.z, 4, 1.5, 2.0, 1.5, 0.0);
                }
                if (t % 20 == 0) {
                    Fx.sound(level, center.x, center.y, center.z, SoundEvents.WARDEN_HEARTBEAT, 4.0F, 0.5F + t / 140.0F);
                }
                if (t % 10 == 0) Fx.shake(level, center, 40, 0.25F + t / 200.0F, 14);

                // pull and blind everything near the vortex
                AABB area = new AABB(center, center).inflate(PULL_RADIUS, 8, PULL_RADIUS);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area, x -> AbilityUtil.canHarm(player, x))) {
                    Vec3 to = center.subtract(e.position());
                    double d = to.horizontalDistance();
                    if (d > PULL_RADIUS) continue;
                    if (t > 5 && d > 1.5) {
                        Vec3 pull = new Vec3(to.x, 0, to.z).normalize().scale(0.09 + 0.1 * (t / (double) BUILDUP));
                        e.setDeltaMovement(e.getDeltaMovement().add(pull.x, 0.02, pull.z));
                        e.hurtMarked = true;
                    }
                    if (t % 20 == 0) {
                        e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
                        e.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0));
                        e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                    }
                }
                return false;
            }

            // detonation
            if (t == BUILDUP) {
                AABB area = new AABB(center, center).inflate(BLAST_RADIUS, BLAST_RADIUS * 0.7, BLAST_RADIUS);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area, x -> AbilityUtil.canHarm(player, x))) {
                    if (e.position().distanceTo(center) > BLAST_RADIUS) continue;
                    Vec3 away = e.position().subtract(center);
                    InfiniteDamage.strike(e, player);
                    if (e.isAlive()) {
                        Vec3 push = new Vec3(away.x, 0, away.z).normalize().scale(1.6).add(0, 0.7, 0);
                        e.setDeltaMovement(push);
                        e.hurtMarked = true;
                    }
                }
                Vec3 mid = center.add(0, 2, 0);
                Fx.particle(level, ParticleTypes.EXPLOSION_EMITTER, mid.x, mid.y, mid.z, 1, 0, 0, 0, 0);
                Fx.particle(level, ParticleTypes.EXPLOSION_EMITTER, mid.x + 3, mid.y + 2, mid.z, 1, 0, 0, 0, 0);
                Fx.particle(level, ParticleTypes.EXPLOSION_EMITTER, mid.x - 3, mid.y + 4, mid.z - 2, 1, 0, 0, 0, 0);
                Fx.particle(level, ParticleTypes.SONIC_BOOM, mid.x, mid.y, mid.z, 1, 0, 0, 0, 0);
                Fx.particle(level, ParticleTypes.FLASH, mid.x, mid.y, mid.z, 1, 0, 0, 0, 0);
                // expanding spherical shell of darkness
                int n = 140;
                for (int i = 0; i < n; i++) {
                    double y = 1 - 2.0 * (i + 0.5) / n;
                    double rr = Math.sqrt(1 - y * y);
                    double phi = i * 2.399963229728653;
                    double dx = Math.cos(phi) * rr, dz = Math.sin(phi) * rr;
                    Fx.particle(level, i % 5 == 0 ? Fx.RED : Fx.BLACK, mid.x, mid.y, mid.z, 0, dx, y, dz, 0.9);
                    if (i % 3 == 0) Fx.particle(level, ParticleTypes.SQUID_INK, mid.x, mid.y, mid.z, 0, dx, y, dz, 0.7);
                    if (i % 4 == 0) Fx.particle(level, ParticleTypes.LARGE_SMOKE, mid.x, mid.y, mid.z, 0, dx, y, dz, 0.5);
                }
                Fx.burstRing(level, ParticleTypes.DRAGON_BREATH, center.add(0, 0.5, 0), 64, 0.8);
                Fx.burstRing(level, Fx.WHITE, center.add(0, 0.3, 0), 48, 0.9);
                Fx.flash(level, center, 80, 0xFFFFFF, 1.0F, 8);
                Fx.shake(level, center, 80, 2.2F, 40);
                Fx.sound(level, center.x, center.y, center.z, SoundEvents.GENERIC_EXPLODE, 6.0F, 0.5F);
                Fx.sound(level, center.x, center.y, center.z, SoundEvents.WARDEN_SONIC_BOOM, 5.0F, 0.7F);
                Fx.sound(level, center.x, center.y, center.z, SoundEvents.DRAGON_FIREBALL_EXPLODE, 5.0F, 0.6F);
                Fx.sound(level, center.x, center.y, center.z, SoundEvents.LIGHTNING_BOLT_THUNDER, 5.0F, 0.5F);
                ServerEffects.delay(8, () -> Fx.flash(level, center, 80, 0x000000, 0.8F, 30));
            }
            return t >= BUILDUP + 2;
        });
        return true;
    }

    private DarknessControl() {}
}
