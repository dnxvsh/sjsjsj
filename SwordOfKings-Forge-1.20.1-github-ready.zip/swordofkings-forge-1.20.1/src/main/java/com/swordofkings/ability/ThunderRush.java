package com.swordofkings.ability;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

/** Ability 3 (C): charge up, then dash at lightning speed through the enemy, piercing it with infinite damage. */
public final class ThunderRush {
    private static final int CHARGE = 8;
    private static final int STEPS = 7;

    public static boolean start(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        LivingEntity target = TargetFinder.find(player, 40.0D);

        final Vec3 dir;
        final double distance;
        if (target != null) {
            Vec3 to = Fx.center(target).subtract(player.getEyePosition());
            dir = to.normalize();
            distance = Math.min(to.length() + 7.0, 46.0);
        } else {
            dir = player.getLookAngle().normalize();
            distance = 22.0;
        }
        final double stepLen = distance / STEPS;
        final float yaw = (float) Math.toDegrees(Math.atan2(-dir.x, dir.z));
        final float pitch = (float) -Math.toDegrees(Math.atan2(dir.y, Math.hypot(dir.x, dir.z)));
        final Set<LivingEntity> hit = new HashSet<>();
        final int[] age = {0};

        Fx.sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.TRIDENT_RIPTIDE_3, 2.0F, 0.8F);
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 50, 4, false, false));

        ServerEffects.add(() -> {
            int t = age[0]++;
            if (!player.isAlive() || player.isRemoved()) return true;

            // charge-up: crackling energy gathers around the player
            if (t < CHARGE) {
                Vec3 p = player.position();
                for (int i = 0; i < 8; i++) {
                    double a = t * 0.9 + i * (Math.PI / 4);
                    double r = 2.2 - t * 0.2;
                    Fx.particle(level, i % 2 == 0 ? Fx.WHITE : Fx.RED, p.x + Math.cos(a) * r, p.y + 0.2 + t * 0.25, p.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
                }
                Fx.particle(level, ParticleTypes.ELECTRIC_SPARK, p.x, p.y + 1, p.z, 10, 0.6, 0.9, 0.6, 0.4);
                if (t == 0) Fx.shake(level, p, 24, 0.5F, 10);
                if (t == CHARGE - 1) {
                    Fx.bolt(level, p.x, p.y, p.z);
                    Fx.sound(level, p.x, p.y, p.z, SoundEvents.LIGHTNING_BOLT_IMPACT, 2.0F, 1.5F);
                }
                return false;
            }

            // dash: a few long, instant hops
            int step = t - CHARGE;
            if (step < STEPS) {
                Vec3 from = player.position();
                Vec3 to = from.add(dir.scale(stepLen));
                if (!level.hasChunkAt(BlockPos.containing(to))) return true;
                AABB moved = player.getBoundingBox().move(to.subtract(from));
                if (!level.noCollision(player, moved)) {
                    to = to.add(0, 1.0, 0);                       // try stepping up one block
                    moved = player.getBoundingBox().move(to.subtract(from));
                    if (!level.noCollision(player, moved)) {
                        finish(level, player, from);
                        return true;
                    }
                }
                player.connection.teleport(to.x, to.y, to.z, yaw, pitch);
                player.fallDistance = 0.0F;

                // pierce everything along this hop
                AABB sweep = new AABB(from, to).inflate(1.7, 1.5, 1.7);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, sweep, x -> AbilityUtil.canHarm(player, x) && !hit.contains(x))) {
                    hit.add(e);
                    InfiniteDamage.strike(e, player);
                    Vec3 c = Fx.center(e);
                    Fx.particle(level, ParticleTypes.SWEEP_ATTACK, c.x, c.y, c.z, 1, 0, 0, 0, 0);
                    Fx.particle(level, ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 30, 0.5, 0.7, 0.5, 0.6);
                    Fx.particle(level, Fx.RED, c.x, c.y, c.z, 20, 0.5, 0.7, 0.5, 0.0);
                    Fx.sound(level, c.x, c.y, c.z, SoundEvents.PLAYER_ATTACK_CRIT, 1.5F, 0.6F);
                }

                // lightning trail
                Vec3 a = from.add(0, 1.0, 0), b = to.add(0, 1.0, 0);
                Fx.line(level, ParticleTypes.ELECTRIC_SPARK, a, b, 0.6);
                Fx.line(level, ParticleTypes.END_ROD, a, b, 1.2);
                Fx.line(level, Fx.WHITE, a, b, 0.9);
                Fx.line(level, Fx.RED, a.add(0, 0.5, 0), b.add(0, 0.5, 0), 0.9);
                if (step % 2 == 0) Fx.bolt(level, from.x, from.y, from.z);
                Fx.sound(level, to.x, to.y, to.z, SoundEvents.TRIDENT_THUNDER, 1.2F, 1.4F);

                if (step == STEPS - 1) {
                    finish(level, player, to);
                    return true;
                }
                return false;
            }
            return true;
        });
        return true;
    }

    private static void finish(ServerLevel level, ServerPlayer player, Vec3 at) {
        player.setDeltaMovement(player.getLookAngle().scale(0.4));
        player.hurtMarked = true;
        player.fallDistance = 0.0F;
        Vec3 c = at.add(0, 1.0, 0);
        for (int i = 0; i < 6; i++) {
            Fx.particle(level, ParticleTypes.SWEEP_ATTACK, c.x, c.y, c.z, 1, 1.2, 0.8, 1.2, 0);
        }
        Fx.particle(level, ParticleTypes.SONIC_BOOM, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        Fx.burstRing(level, ParticleTypes.ELECTRIC_SPARK, c, 36, 0.8);
        Fx.burstRing(level, Fx.RED, c, 24, 0.5);
        Fx.shake(level, c, 40, 1.2F, 14);
        Fx.flash(level, c, 24, 0xFFFFFF, 0.5F, 6);
        Fx.sound(level, c.x, c.y, c.z, SoundEvents.LIGHTNING_BOLT_THUNDER, 2.5F, 1.2F);
        Fx.sound(level, c.x, c.y, c.z, SoundEvents.PLAYER_ATTACK_SWEEP, 2.0F, 0.6F);
    }

    private ThunderRush() {}
}
