package com.swordofkings.ability;

import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;

public final class AbilityUtil {
    /** Whether the sword's abilities may hurt this entity (protects the owner, pets, villagers, allies, peaceful players). */
    public static boolean canHarm(LivingEntity owner, LivingEntity target) {
        if (target == owner || !target.isAlive() || target.isSpectator()) return false;
        if (target instanceof ArmorStand || target instanceof AbstractVillager) return false;
        if (target instanceof TamableAnimal pet && pet.isOwnedBy(owner)) return false;
        if (target.isAlliedTo(owner)) return false;
        if (target instanceof Player p) {
            MinecraftServer server = p.getServer();
            if (server == null || !server.isPvpAllowed() || p.isCreative()) return false;
        }
        return true;
    }

    private AbilityUtil() {}
}
