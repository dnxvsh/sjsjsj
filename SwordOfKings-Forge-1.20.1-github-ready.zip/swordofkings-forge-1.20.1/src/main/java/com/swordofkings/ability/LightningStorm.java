package com.swordofkings.ability;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/** Ability 1 (Z): a barrage of lightning on the targeted creature, each bolt dealing infinite damage. */
public final class LightningStorm {
    private static final int DURATION = 64;

    public static boolean start(ServerPlayer player) {
        LivingEntity target = TargetFinder.find(player, 48.0D);
        if (target == null) {
            AbilityManager.noTarget(player);
            return false;
        }
        ServerLevel level = player.serverLevel();
        RandomSource rnd = level.random;
        final Vec3[] last = {Fx.center(target)};
        final int[] age = {0};

        Fx.sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.BEACON_ACTIVATE, 2.0F, 0.6F);
        Fx.particle(level, ParticleTypes.ELECTRIC_SPARK, player.getX(), player.getY() + 1.2, player.getZ(), 40, 0.5, 0.8, 0.5, 0.5);

        ServerEffects.add(() -> {
            int t = age[0]++;
            if (player.isRemoved()) return true;
            if (target.isAlive()) last[0] = Fx.center(target);
            Vec3 c = last[0];
            double groundY = target.getY();

            if (t == 0) {
                Fx.flash(level, c, 48, 0xFFFFFF, 0.55F, 8);
                Fx.shake(level, c, 48, 0.9F, 50);
                Fx.sound(level, c.x, c.y, c.z, SoundEvents.LIGHTNING_BOLT_THUNDER, 4.0F, 0.8F);
            }

            // beam of sparks from the sky + charged ring around the victim
            if (t < 46) {
                if (t % 3 == 0) {
                    Fx.line(level, ParticleTypes.ELECTRIC_SPARK, c.add(0, 26, 0), c, 1.3);
                    Fx.line(level, Fx.WHITE, c.add(0, 18, 0), c, 1.6);
                }
                double r = 2.4;
                for (int i = 0; i < 10; i++) {
                    double a = t * 0.5 + i * (Math.PI * 2 / 10);
                    double y = c.y - 0.8 + ((t * 0.12 + i * 0.2) % 2.2);
                    Fx.particle(level, i % 2 == 0 ? Fx.RED : Fx.WHITE, c.x + Math.cos(a) * r, y, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
                }
                Fx.particle(level, Fx.BLACK, c.x, c.y, c.z, 2, 0.8, 0.9, 0.8, 0.0);
            }

            // many bolts crashing around the target
            if (t < 44 && t % 2 == 0) {
                for (int k = 0; k < 2; k++) {
                    double ang = rnd.nextDouble() * Math.PI * 2;
                    double dist = k == 0 ? rnd.nextDouble() * 0.6 : 1.5 + rnd.nextDouble() * 2.5;
                    Fx.bolt(level, c.x + Math.cos(ang) * dist, groundY, c.z + Math.sin(ang) * dist);
                }
                Fx.particle(level, ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 24, 0.9, 1.0, 0.9, 0.35);
            }

            // infinite damage, repeatedly, on the chosen creature
            if (t < 44 && t % 4 == 0 && target.isAlive() && AbilityUtil.canHarm(player, target)) {
                InfiniteDamage.strike(target, player);
            }

            // finale
            if (t == 50) {
                for (int k = 0; k < 4; k++) {
                    double ang = k * Math.PI / 2;
                    Fx.bolt(level, c.x + Math.cos(ang) * 2.2, groundY, c.z + Math.sin(ang) * 2.2);
                }
                Fx.bolt(level, c.x, groundY, c.z);
                Fx.particle(level, ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
                Fx.particle(level, ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
                Fx.burstRing(level, ParticleTypes.ELECTRIC_SPARK, c, 48, 0.9);
                Fx.burstRing(level, ParticleTypes.END_ROD, c, 32, 0.6);
                Fx.flash(level, c, 48, 0xFFFFFF, 0.9F, 10);
                Fx.shake(level, c, 48, 1.6F, 20);
                Fx.sound(level, c.x, c.y, c.z, SoundEvents.LIGHTNING_BOLT_IMPACT, 4.0F, 0.7F);
                if (target.isAlive() && AbilityUtil.canHarm(player, target)) InfiniteDamage.strike(target, player);
            }
            return t >= DURATION;
        });
        return true;
    }

    private LightningStorm() {}
}
