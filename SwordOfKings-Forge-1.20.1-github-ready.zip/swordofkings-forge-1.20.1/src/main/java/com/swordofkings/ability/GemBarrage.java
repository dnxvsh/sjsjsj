package com.swordofkings.ability;

import com.swordofkings.entity.KingGemEntity;
import com.swordofkings.registry.ModItems;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Ability 4 (V): gems circle the enemy, spin faster and faster, then plunge in and explode. */
public final class GemBarrage {
    public static final int COUNT = 12;
    public static final int EXPLODE_AT = 62;
    private static final double BLAST_RADIUS = 9.0;

    public static boolean start(ServerPlayer player) {
        LivingEntity target = TargetFinder.find(player, 48.0D);
        if (target == null) {
            AbilityManager.noTarget(player);
            return false;
        }
        ServerLevel level = player.serverLevel();
        List<KingGemEntity> gems = new ArrayList<>();
        for (int i = 0; i < COUNT; i++) {
            KingGemEntity g = KingGemEntity.spawn(level, target, i, COUNT, i % 3);
            if (g != null) gems.add(g);
        }
        final Vec3[] last = {Fx.center(target)};
        final int[] age = {0};

        Fx.sound(level, last[0].x, last[0].y, last[0].z, SoundEvents.AMETHYST_CLUSTER_PLACE, 3.0F, 0.6F);
        Fx.sound(level, last[0].x, last[0].y, last[0].z, SoundEvents.BEACON_POWER_SELECT, 2.0F, 1.4F);
        target.addEffect(new MobEffectInstance(MobEffects.GLOWING, EXPLODE_AT + 10, 0, false, false));
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, EXPLODE_AT, 5, false, false));

        ServerEffects.add(() -> {
            int t = age[0]++;
            if (player.isRemoved()) {
                gems.forEach(g -> g.discard());
                return true;
            }
            if (target.isAlive()) last[0] = Fx.center(target);
            Vec3 c = last[0];

            if (t < EXPLODE_AT - 4) {
                // pulsing coloured ring on the ground that tightens as the gems accelerate
                if (t % 3 == 0) {
                    double r = 4.5 - 3.0 * (t / (double) EXPLODE_AT);
                    for (int i = 0; i < 16; i++) {
                        double a = i * (Math.PI * 2 / 16) + t * 0.3;
                        Fx.particle(level, i % 3 == 0 ? Fx.RED : (i % 3 == 1 ? Fx.WHITE : Fx.BLACK),
                                c.x + Math.cos(a) * r, target.getY() + 0.15, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
                    }
                }
                if (t % 10 == 0) Fx.sound(level, c.x, c.y, c.z, SoundEvents.AMETHYST_BLOCK_CHIME, 2.5F, 0.6F + t / 80.0F);
                if (t % 8 == 0) Fx.shake(level, c, 32, 0.2F + t / 150.0F, 10);
            }

            if (t == EXPLODE_AT) {
                gems.forEach(g -> g.discard());
                AABB area = new AABB(c, c).inflate(BLAST_RADIUS);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area, x -> AbilityUtil.canHarm(player, x))) {
                    if (Fx.center(e).distanceTo(c) > BLAST_RADIUS) continue;
                    Vec3 away = e.position().subtract(c);
                    InfiniteDamage.strike(e, player);
                    if (e.isAlive()) {
                        e.setDeltaMovement(new Vec3(away.x, 0, away.z).normalize().scale(1.3).add(0, 0.6, 0));
                        e.hurtMarked = true;
                    }
                }
                if (target.isAlive() && AbilityUtil.canHarm(player, target)) InfiniteDamage.strike(target, player);

                Fx.particle(level, ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
                Fx.particle(level, ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
                Fx.particle(level, ParticleTypes.TOTEM_OF_UNDYING, c.x, c.y, c.z, 100, 0.4, 0.4, 0.4, 0.9);
                // gem shards flying outwards in every direction
                int n = 120;
                for (int i = 0; i < n; i++) {
                    double y = 1 - 2.0 * (i + 0.5) / n;
                    double rr = Math.sqrt(1 - y * y);
                    double phi = i * 2.399963229728653;
                    double dx = Math.cos(phi) * rr, dz = Math.sin(phi) * rr;
                    int kind = i % 3;
                    Fx.particle(level, kind == 0 ? Fx.RED : (kind == 1 ? Fx.WHITE : Fx.BLACK), c.x, c.y, c.z, 0, dx, y, dz, 0.8);
                    if (i % 2 == 0) {
                        ItemStack gem = new ItemStack(kind == 0 ? ModItems.GEM_RED.get() : (kind == 1 ? ModItems.GEM_WHITE.get() : ModItems.GEM_BLACK.get()));
                        Fx.particle(level, new ItemParticleOption(ParticleTypes.ITEM, gem), c.x, c.y, c.z, 0, dx, y + 0.2, dz, 0.5);
                    }
                    if (i % 4 == 0) Fx.particle(level, ParticleTypes.END_ROD, c.x, c.y, c.z, 0, dx, y, dz, 0.7);
                }
                Fx.burstRing(level, ParticleTypes.ELECTRIC_SPARK, c, 40, 0.9);
                Fx.flash(level, c, 64, 0xFFFFFF, 0.9F, 12);
                Fx.shake(level, c, 64, 1.8F, 30);
                Fx.sound(level, c.x, c.y, c.z, SoundEvents.GENERIC_EXPLODE, 5.0F, 1.1F);
                Fx.sound(level, c.x, c.y, c.z, SoundEvents.GLASS_BREAK, 5.0F, 0.6F);
                Fx.sound(level, c.x, c.y, c.z, SoundEvents.AMETHYST_BLOCK_BREAK, 5.0F, 0.5F);
                Fx.sound(level, c.x, c.y, c.z, SoundEvents.WARDEN_SONIC_BOOM, 3.0F, 1.3F);
            }
            return t >= EXPLODE_AT + 2;
        });
        return true;
    }

    private GemBarrage() {}
}
