package com.swordofkings.ability;

import com.swordofkings.SwordOfKingsMod;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.enderdragon.phases.EnderDragonPhase;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/** The "infinite" damage of the Sword of Kings: a custom damage type that ignores every protection. */
public final class InfiniteDamage {
    public static final ResourceKey<DamageType> KINGS_WRATH =
            ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation(SwordOfKingsMod.MODID, "kings_wrath"));

    public static DamageSource source(Level level, @Nullable Entity attacker) {
        Holder<DamageType> holder = level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(KINGS_WRATH);
        return new DamageSource(holder, attacker, attacker);
    }

    /** Deals Float.MAX_VALUE damage that bypasses armor, effects, totems, invulnerability and hurt-cooldown. */
    public static void strike(LivingEntity target, @Nullable Entity attacker) {
        if (target.level().isClientSide) return;
        DamageSource src = source(target.level(), attacker);
        for (int i = 0; i < 6; i++) {
            if (!target.isAlive()) break;
            if (target instanceof EnderDragon dragon) {
                if (dragon.getPhaseManager().getCurrentPhase().getPhase() == EnderDragonPhase.DYING) break;
                dragon.hurt(dragon.head, src, Float.MAX_VALUE);
            } else {
                target.invulnerableTime = 0;
                target.hurt(src, Float.MAX_VALUE);
            }
        }
    }

    private InfiniteDamage() {}
}
