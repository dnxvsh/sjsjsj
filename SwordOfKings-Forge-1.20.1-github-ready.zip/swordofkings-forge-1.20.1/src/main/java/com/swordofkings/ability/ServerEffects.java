package com.swordofkings.ability;

import com.swordofkings.SwordOfKingsMod;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

/** Tiny server-side scheduler: every Effect is ticked once per server tick until it returns true. */
@Mod.EventBusSubscriber(modid = SwordOfKingsMod.MODID)
public final class ServerEffects {
    public interface Effect {
        /** @return true when the effect is finished and must be removed. */
        boolean tick();
    }

    private static final List<Effect> ACTIVE = new ArrayList<>();
    private static final List<Effect> PENDING = new ArrayList<>();

    public static void add(Effect effect) {
        PENDING.add(effect);
    }

    /** Runs the task after {@code ticks} server ticks. */
    public static void delay(int ticks, Runnable task) {
        final int[] left = {ticks};
        add(() -> {
            if (--left[0] > 0) return false;
            task.run();
            return true;
        });
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!PENDING.isEmpty()) {
            ACTIVE.addAll(PENDING);
            PENDING.clear();
        }
        ACTIVE.removeIf(effect -> {
            try {
                return effect.tick();
            } catch (Exception ex) {
                SwordOfKingsMod.LOGGER.error("Sword of Kings effect failed", ex);
                return true;
            }
        });
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        ACTIVE.clear();
        PENDING.clear();
    }

    private ServerEffects() {}
}
