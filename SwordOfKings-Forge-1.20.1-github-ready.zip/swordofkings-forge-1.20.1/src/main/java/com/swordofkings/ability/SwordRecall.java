package com.swordofkings.ability;

import com.swordofkings.item.SwordOfKingsItem;
import com.swordofkings.registry.ModItems;
import com.swordofkings.world.KingsWorldData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Container;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/** The "summon" key: pulls the player's sword back from wherever it is (or re-forges it from the soul bond). */
public final class SwordRecall {
    public static void recall(ServerPlayer p) {
        MinecraftServer server = p.getServer();
        if (server == null) return;
        KingsWorldData data = KingsWorldData.get(server);
        KingsWorldData.Progress progress = data.of(p.getUUID());
        if (!progress.swordClaimed) {
            msg(p, "msg.swordofkings.recall_none", ChatFormatting.GRAY);
            return;
        }
        if (hasSword(p.getInventory())) {
            msg(p, "msg.swordofkings.recall_already", ChatFormatting.GRAY);
            return;
        }

        // 1) loose in a loaded level
        ItemEntity found = null;
        for (ServerLevel lvl : server.getAllLevels()) {
            for (Entity e : lvl.getAllEntities()) {
                if (e instanceof ItemEntity ie && isMine(ie.getItem(), p, progress)) {
                    found = ie;
                    break;
                }
            }
            if (found != null) break;
        }
        if (found != null) {
            ItemStack stack = found.getItem().copy();
            if (found.level() instanceof ServerLevel from) {
                trail(from, found.position(), p.position().add(0, 1, 0));
                Fx.bolt(from, found.getX(), found.getY(), found.getZ());
            }
            found.discard();
            arrive(p, stack);
            return;
        }

        // 2) ender chest
        Container ender = p.getEnderChestInventory();
        for (int i = 0; i < ender.getContainerSize(); i++) {
            ItemStack s = ender.getItem(i);
            if (isMine(s, p, progress)) {
                ender.setItem(i, ItemStack.EMPTY);
                arrive(p, s);
                return;
            }
        }

        // 3) nowhere to be found: re-forge it, the old copy (if any) turns to dust when it is next seen
        ItemStack fresh = SwordOfKingsItem.forgeFor(p, new ItemStack(ModItems.SWORD_OF_KINGS.get()));
        msg(p, "msg.swordofkings.recall_forged", ChatFormatting.DARK_RED);
        arrive(p, fresh);
    }

    private static void arrive(ServerPlayer p, ItemStack stack) {
        if (!p.getInventory().add(stack)) p.drop(stack, false);
        ServerLevel level = p.serverLevel();
        Fx.bolt(level, p.getX(), p.getY(), p.getZ());
        Fx.particle(level, ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1, p.getZ(), 40, 0.6, 0.9, 0.6, 0.4);
        Fx.particle(level, Fx.RED, p.getX(), p.getY() + 1, p.getZ(), 30, 0.6, 0.9, 0.6, 0.0);
        Fx.particle(level, Fx.WHITE, p.getX(), p.getY() + 1, p.getZ(), 20, 0.6, 0.9, 0.6, 0.0);
        Fx.sound(level, p.getX(), p.getY(), p.getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT, 1.0F, 1.4F);
        Fx.sound(level, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_POWER_SELECT, 1.0F, 0.6F);
        msg(p, "msg.swordofkings.recall_ok", ChatFormatting.RED);
    }

    private static void trail(ServerLevel level, Vec3 a, Vec3 b) {
        Fx.line(level, Fx.RED, a, b, 0.8);
        Fx.line(level, ParticleTypes.ELECTRIC_SPARK, a, b, 1.6);
    }

    private static boolean isMine(ItemStack s, ServerPlayer p, KingsWorldData.Progress progress) {
        if (s.isEmpty() || !s.is(ModItems.SWORD_OF_KINGS.get())) return false;
        CompoundTag tag = s.getTag();
        if (tag == null || !tag.hasUUID(SwordOfKingsItem.TAG_OWNER) || !tag.hasUUID(SwordOfKingsItem.TAG_UID)) return false;
        return tag.getUUID(SwordOfKingsItem.TAG_OWNER).equals(p.getUUID())
                && tag.getUUID(SwordOfKingsItem.TAG_UID).equals(progress.sword);
    }

    public static boolean hasSword(net.minecraft.world.entity.player.Inventory inv) {
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).is(ModItems.SWORD_OF_KINGS.get())) return true;
        }
        return false;
    }

    private static void msg(ServerPlayer p, String key, ChatFormatting color) {
        p.displayClientMessage(Component.translatable(key).withStyle(color), true);
    }

    private SwordRecall() {}
}
