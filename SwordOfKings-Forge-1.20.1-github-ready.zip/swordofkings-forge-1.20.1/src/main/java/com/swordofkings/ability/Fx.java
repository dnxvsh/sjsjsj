package com.swordofkings.ability;

import com.swordofkings.network.FxPacket;
import com.swordofkings.network.ModNetwork;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Shared server-side visual helpers (particles, bolts, sounds, camera effects). */
public final class Fx {
    public static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(0.85F, 0.03F, 0.08F), 1.7F);
    public static final DustParticleOptions BLACK = new DustParticleOptions(new Vector3f(0.03F, 0.0F, 0.06F), 2.4F);
    public static final DustParticleOptions WHITE = new DustParticleOptions(new Vector3f(1.0F, 1.0F, 1.0F), 1.5F);

    /** Sends a particle burst to every player within 96 blocks (long-distance flag so big effects stay visible). */
    public static void particle(ServerLevel level, ParticleOptions options, double x, double y, double z,
                                int count, double dx, double dy, double dz, double speed) {
        for (ServerPlayer sp : level.players()) {
            if (sp.distanceToSqr(x, y, z) <= 96.0 * 96.0) {
                level.sendParticles(sp, options, true, x, y, z, count, dx, dy, dz, speed);
            }
        }
    }

    public static void particle(ServerLevel level, ParticleOptions options, Vec3 p, int count, double spread, double speed) {
        particle(level, options, p.x, p.y, p.z, count, spread, spread, spread, speed);
    }

    /** A purely visual lightning bolt (no fire, no damage). */
    public static void bolt(ServerLevel level, double x, double y, double z) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt == null) return;
        bolt.moveTo(x, y, z);
        bolt.setVisualOnly(true);
        level.addFreshEntity(bolt);
    }

    public static void line(ServerLevel level, ParticleOptions options, Vec3 a, Vec3 b, double step) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        if (len < 1.0E-4) return;
        Vec3 dir = d.scale(1.0 / len);
        for (double t = 0; t <= len; t += step) {
            Vec3 p = a.add(dir.scale(t));
            particle(level, options, p.x, p.y, p.z, 1, 0.05, 0.05, 0.05, 0.0);
        }
    }

    /** Horizontal ring of particles. */
    public static void ring(ServerLevel level, ParticleOptions options, Vec3 center, double radius, int points, double speed) {
        for (int i = 0; i < points; i++) {
            double a = Math.PI * 2 * i / points;
            particle(level, options, center.x + Math.cos(a) * radius, center.y, center.z + Math.sin(a) * radius,
                    1, 0.0, 0.0, 0.0, speed);
        }
    }

    /** Ring of particles that move outwards (speed along the radial direction). */
    public static void burstRing(ServerLevel level, ParticleOptions options, Vec3 center, int points, double speed) {
        for (int i = 0; i < points; i++) {
            double a = Math.PI * 2 * i / points;
            particle(level, options, center.x, center.y, center.z, 0, Math.cos(a), 0.05, Math.sin(a), speed);
        }
    }

    public static void sound(ServerLevel level, double x, double y, double z, SoundEvent sound, float volume, float pitch) {
        level.playSound(null, x, y, z, sound, SoundSource.PLAYERS, volume, pitch);
    }

    public static void shake(ServerLevel level, Vec3 pos, double radius, float intensity, int duration) {
        ModNetwork.near(level, pos.x, pos.y, pos.z, radius, FxPacket.shake(intensity, duration));
    }

    public static void flash(ServerLevel level, Vec3 pos, double radius, int rgb, float alpha, int duration) {
        ModNetwork.near(level, pos.x, pos.y, pos.z, radius, FxPacket.flash(rgb, alpha, duration));
    }

    public static Vec3 center(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.5, 0);
    }

    private Fx() {}
}
