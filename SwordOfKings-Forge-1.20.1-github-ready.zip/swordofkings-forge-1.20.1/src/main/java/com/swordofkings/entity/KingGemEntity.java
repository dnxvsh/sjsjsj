package com.swordofkings.entity;

import com.swordofkings.registry.ModEntities;
import com.swordofkings.registry.ModItems;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import org.joml.Vector3f;

import javax.annotation.Nullable;

/**
 * A floating gem used by the "Gem Storm" ability. Its position is a pure function of the target's position and its own age,
 * computed on BOTH sides every tick, so the orbit is perfectly smooth without any movement packets.
 */
public class KingGemEntity extends Entity implements ItemSupplier {
    private static final EntityDataAccessor<Integer> DATA_TARGET = SynchedEntityData.defineId(KingGemEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_INDEX = SynchedEntityData.defineId(KingGemEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TOTAL = SynchedEntityData.defineId(KingGemEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_KIND = SynchedEntityData.defineId(KingGemEntity.class, EntityDataSerializers.INT);

    private static final DustParticleOptions DUST_RED = new DustParticleOptions(new Vector3f(0.9F, 0.05F, 0.1F), 1.0F);
    private static final DustParticleOptions DUST_BLACK = new DustParticleOptions(new Vector3f(0.1F, 0.0F, 0.2F), 1.2F);
    private static final DustParticleOptions DUST_WHITE = new DustParticleOptions(new Vector3f(1.0F, 1.0F, 1.0F), 0.9F);

    public KingGemEntity(EntityType<? extends KingGemEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    @Nullable
    public static KingGemEntity spawn(ServerLevel level, LivingEntity target, int index, int total, int kind) {
        KingGemEntity gem = ModEntities.KING_GEM.get().create(level);
        if (gem == null) return null;
        gem.entityData.set(DATA_TARGET, target.getId());
        gem.entityData.set(DATA_INDEX, index);
        gem.entityData.set(DATA_TOTAL, total);
        gem.entityData.set(DATA_KIND, kind);
        Vec3 p = orbit(target.position().add(0, target.getBbHeight() * 0.5, 0), index, total, 0);
        gem.setPos(p.x, p.y, p.z);
        level.addFreshEntity(gem);
        return gem;
    }

    /** Position of gem {@code index} around {@code center} after {@code age} ticks: orbit, accelerate, then plunge inwards. */
    public static Vec3 orbit(Vec3 center, int index, int total, int age) {
        double plunge = age <= 42 ? 0.0 : Math.min(1.0, (age - 42) / 14.0);
        double eased = plunge * plunge;
        double theta = index * (Math.PI * 2.0 / total) + age * 0.14 + age * age * 0.0032;
        double radius = (3.4 - 0.7 * Math.min(1.0, age / 40.0)) * (1.0 - eased);
        double height = (Math.sin(age * 0.17 + index * 1.3) * 0.9 + ((index % 3) - 1) * 0.7) * (1.0 - eased);
        return center.add(Math.cos(theta) * radius, height, Math.sin(theta) * radius);
    }

    @Override
    public void tick() {
        super.tick();
        Entity target = this.level().getEntity(this.entityData.get(DATA_TARGET));
        if (target instanceof LivingEntity living) {
            Vec3 c = living.position().add(0, living.getBbHeight() * 0.5, 0);
            Vec3 p = orbit(c, this.entityData.get(DATA_INDEX), Math.max(1, this.entityData.get(DATA_TOTAL)), this.tickCount);
            this.setPos(p.x, p.y, p.z);
        } else if (!this.level().isClientSide && this.tickCount > 4) {
            this.discard();
        }
        if (!this.level().isClientSide && this.tickCount > 90) {
            this.discard();
        }
        if (this.level().isClientSide) {
            int kind = this.entityData.get(DATA_KIND);
            DustParticleOptions dust = kind == 0 ? DUST_RED : (kind == 1 ? DUST_BLACK : DUST_WHITE);
            this.level().addParticle(dust, this.getX(), this.getY() + 0.1, this.getZ(), 0, 0, 0);
            if (this.tickCount % 2 == 0) {
                this.level().addParticle(ParticleTypes.END_ROD, this.getX(), this.getY() + 0.1, this.getZ(), 0, 0.01, 0);
            }
        }
    }

    @Override
    public ItemStack getItem() {
        int kind = this.entityData.get(DATA_KIND);
        return new ItemStack(kind == 0 ? ModItems.GEM_RED.get() : (kind == 1 ? ModItems.GEM_BLACK.get() : ModItems.GEM_WHITE.get()));
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_TARGET, -1);
        this.entityData.define(DATA_INDEX, 0);
        this.entityData.define(DATA_TOTAL, 12);
        this.entityData.define(DATA_KIND, 0);
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
