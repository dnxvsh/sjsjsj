package com.swordofkings.item;

import com.swordofkings.ability.Fx;
import com.swordofkings.ability.InfiniteDamage;
import com.swordofkings.world.KingsWorldData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.EnderDragonPart;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class SwordOfKingsItem extends SwordItem {
    public static final String TAG_OWNER = "KingOwner";
    public static final String TAG_UID = "KingUid";

    /** Unbreakable (0 uses), enormous base damage on top of the infinite-damage hook. */
    private static final Tier KINGS_TIER = new Tier() {
        @Override public int getUses() { return 0; }
        @Override public float getSpeed() { return 14.0F; }
        @Override public float getAttackDamageBonus() { return 996.0F; }
        @Override public int getLevel() { return 5; }
        @Override public int getEnchantmentValue() { return 30; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
    };

    private static final int[] PALETTE = {0xFF1A1A, 0xAA0000, 0xFFFFFF, 0xFF5555, 0x8B0000, 0xB0B0B0, 0x9B30D0};
    private static final String[] DECO = {"✦", "✧", "†", "♛", "✶"};

    public SwordOfKingsItem(Properties properties) {
        super(KINGS_TIER, 3, -1.4F, properties);
    }

    // ------------------------------------------------------------------ combat
    /** Called (server and client) before vanilla handles a left click on an entity. Return true to cancel vanilla. */
    @Override
    public boolean onLeftClickEntity(ItemStack stack, Player player, Entity entity) {
        if (player.level().isClientSide) return false;
        Entity real = entity instanceof EnderDragonPart part ? part.parentMob : entity;
        if (!(real instanceof LivingEntity living)) return false;
        if (living instanceof Player other && !player.canHarmPlayer(other)) return false;

        InfiniteDamage.strike(living, player);

        ServerLevel level = (ServerLevel) player.level();
        Vec3 c = Fx.center(living);
        Fx.particle(level, ParticleTypes.SWEEP_ATTACK, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        Fx.particle(level, Fx.RED, c.x, c.y, c.z, 14, 0.5, 0.6, 0.5, 0.0);
        Fx.particle(level, Fx.WHITE, c.x, c.y, c.z, 6, 0.4, 0.5, 0.4, 0.0);
        Fx.particle(level, ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 10, 0.4, 0.5, 0.4, 0.3);
        level.playSound(null, c.x, c.y, c.z, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0F, 0.7F);
        level.playSound(null, c.x, c.y, c.z, SoundEvents.TRIDENT_THUNDER, SoundSource.PLAYERS, 0.5F, 1.6F);
        player.resetAttackStrengthTicker();
        return true;
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (!attacker.level().isClientSide) InfiniteDamage.strike(target, attacker);
        return true;
    }

    // ----------------------------------------------------- soul-binding upkeep
    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || level.getGameTime() % 20L != 0L) return;
        MinecraftServer server = level.getServer();
        if (server != null && isStale(stack, server)) {
            stack.shrink(stack.getCount());
            if (entity instanceof Player p) {
                p.displayClientMessage(Component.translatable("msg.swordofkings.crumbled").withStyle(ChatFormatting.DARK_RED), true);
            }
        }
    }

    @Override
    public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
        Level level = entity.level();
        if (!level.isClientSide && entity.tickCount % 20 == 0) {
            MinecraftServer server = level.getServer();
            if (server != null && isStale(stack, server)) entity.discard();
        }
        return false;
    }

    /** A sword whose uid no longer matches the owner's current sword (an older copy) turns to dust. */
    public static boolean isStale(ItemStack stack, MinecraftServer server) {
        CompoundTag tag = stack.getTag();
        if (tag == null || !tag.hasUUID(TAG_OWNER) || !tag.hasUUID(TAG_UID)) return false;
        UUID current = KingsWorldData.get(server).currentSword(tag.getUUID(TAG_OWNER));
        return current != null && !current.equals(tag.getUUID(TAG_UID));
    }

    /** Creates a fresh sword bound to the player and registers it as that player's current sword. */
    public static ItemStack forgeFor(ServerPlayer player, ItemStack fresh) {
        KingsWorldData data = KingsWorldData.get(player.getServer());
        KingsWorldData.Progress progress = data.of(player.getUUID());
        UUID uid = UUID.randomUUID();
        CompoundTag tag = fresh.getOrCreateTag();
        tag.putUUID(TAG_OWNER, player.getUUID());
        tag.putUUID(TAG_UID, uid);
        progress.sword = uid;
        progress.swordClaimed = true;
        data.setDirty();
        return fresh;
    }

    // ------------------------------------------------------------- appearance
    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public boolean isEnchantable(ItemStack stack) {
        return false;
    }

    @Override
    public boolean isBookEnchantable(ItemStack stack, ItemStack book) {
        return false;
    }

    /** The name flickers: random colours, obfuscated letters and jumping ornaments, re-rolled ~11 times a second. */
    @Override
    public Component getName(ItemStack stack) {
        String base = Component.translatable(this.getDescriptionId(stack)).getString();
        long frame = System.currentTimeMillis() / 90L;
        Random rnd = new Random(frame * 7919L + 13L);

        boolean arabic = base.codePoints().anyMatch(cp -> cp >= 0x0600 && cp <= 0x06FF);
        List<String> parts = new ArrayList<>();
        if (arabic) {
            for (String w : base.split(" ")) parts.add(w);   // keep Arabic words whole so letters stay joined
        } else {
            base.codePoints().forEach(cp -> parts.add(new String(Character.toChars(cp))));
        }

        MutableComponent out = Component.empty();
        int lead = rnd.nextInt(3);
        for (int i = 0; i < lead; i++) out.append(ornament(rnd));
        if (lead > 0) out.append(" ");
        for (int i = 0; i < parts.size(); i++) {
            Style style = Style.EMPTY
                    .withColor(PALETTE[rnd.nextInt(PALETTE.length)])
                    .withObfuscated(rnd.nextInt(9) == 0)
                    .withBold(rnd.nextInt(4) == 0);
            out.append(Component.literal(parts.get(i)).withStyle(style));
            if (arabic && i < parts.size() - 1) out.append(" ");
        }
        int trail = rnd.nextInt(3);
        if (trail > 0) out.append(" ");
        for (int i = 0; i < trail; i++) out.append(ornament(rnd));
        return out;
    }

    private static Component ornament(Random rnd) {
        return Component.literal(DECO[rnd.nextInt(DECO.length)])
                .withStyle(Style.EMPTY.withColor(PALETTE[rnd.nextInt(PALETTE.length)]).withObfuscated(rnd.nextInt(5) == 0));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.swordofkings.lore1").withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC));
        tooltip.add(Component.translatable("tooltip.swordofkings.lore2").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        tooltip.add(Component.empty());
        tooltip.add(Component.translatable("tooltip.swordofkings.damage").withStyle(ChatFormatting.RED));
        tooltip.add(Component.translatable("tooltip.swordofkings.unbreakable").withStyle(ChatFormatting.DARK_PURPLE));
    }
}
