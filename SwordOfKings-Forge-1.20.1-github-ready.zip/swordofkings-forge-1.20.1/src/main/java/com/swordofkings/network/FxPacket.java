package com.swordofkings.network;

import com.swordofkings.client.ClientFx;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: camera shake or full-screen colour flash. */
public class FxPacket {
    public static final int SHAKE = 0;
    public static final int FLASH = 1;

    private final int type;
    private final int color;
    private final float intensity;
    private final int duration;

    public FxPacket(int type, int color, float intensity, int duration) {
        this.type = type;
        this.color = color;
        this.intensity = intensity;
        this.duration = duration;
    }

    public static FxPacket shake(float intensity, int duration) {
        return new FxPacket(SHAKE, 0, intensity, duration);
    }

    public static FxPacket flash(int rgb, float alpha, int duration) {
        return new FxPacket(FLASH, rgb, alpha, duration);
    }

    public static void encode(FxPacket msg, FriendlyByteBuf buf) {
        buf.writeByte(msg.type);
        buf.writeInt(msg.color);
        buf.writeFloat(msg.intensity);
        buf.writeInt(msg.duration);
    }

    public static FxPacket decode(FriendlyByteBuf buf) {
        return new FxPacket(buf.readByte(), buf.readInt(), buf.readFloat(), buf.readInt());
    }

    public static void handle(FxPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientFx.handle(msg.type, msg.color, msg.intensity, msg.duration)));
        c.setPacketHandled(true);
    }
}
