package com.swordofkings.network;

import com.swordofkings.ability.AbilityManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: the player pressed an ability key (0-3) or the recall key (4). */
public class AbilityPacket {
    private final int ability;

    public AbilityPacket(int ability) {
        this.ability = ability;
    }

    public static void encode(AbilityPacket msg, FriendlyByteBuf buf) {
        buf.writeByte(msg.ability);
    }

    public static AbilityPacket decode(FriendlyByteBuf buf) {
        return new AbilityPacket(buf.readByte());
    }

    public static void handle(AbilityPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            if (player != null) AbilityManager.handle(player, msg.ability);
        });
        c.setPacketHandled(true);
    }
}
