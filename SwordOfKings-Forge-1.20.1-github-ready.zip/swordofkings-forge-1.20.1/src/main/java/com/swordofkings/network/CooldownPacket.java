package com.swordofkings.network;

import com.swordofkings.client.ClientFx;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: an ability went on cooldown (used by the HUD). */
public class CooldownPacket {
    private final int ability;
    private final int ticks;

    public CooldownPacket(int ability, int ticks) {
        this.ability = ability;
        this.ticks = ticks;
    }

    public static void encode(CooldownPacket msg, FriendlyByteBuf buf) {
        buf.writeByte(msg.ability);
        buf.writeInt(msg.ticks);
    }

    public static CooldownPacket decode(FriendlyByteBuf buf) {
        return new CooldownPacket(buf.readByte(), buf.readInt());
    }

    public static void handle(CooldownPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientFx.setCooldown(msg.ability, msg.ticks)));
        c.setPacketHandled(true);
    }
}
