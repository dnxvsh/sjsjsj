package com.swordofkings;

import com.mojang.logging.LogUtils;
import com.swordofkings.network.ModNetwork;
import com.swordofkings.registry.ModBlockEntities;
import com.swordofkings.registry.ModBlocks;
import com.swordofkings.registry.ModCreativeTabs;
import com.swordofkings.registry.ModEntities;
import com.swordofkings.registry.ModItems;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(SwordOfKingsMod.MODID)
public class SwordOfKingsMod {
    public static final String MODID = "swordofkings";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SwordOfKingsMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
        modBus.addListener(this::commonSetup);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }
}
