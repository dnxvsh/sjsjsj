package com.swordofkings.registry;

import com.swordofkings.SwordOfKingsMod;
import com.swordofkings.block.KingsAltarBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, SwordOfKingsMod.MODID);

    public static final RegistryObject<BlockEntityType<KingsAltarBlockEntity>> ALTAR = BLOCK_ENTITIES.register("kings_altar",
            () -> BlockEntityType.Builder.of(KingsAltarBlockEntity::new, ModBlocks.KINGS_ALTAR.get()).build(null));

    private ModBlockEntities() {}
}
