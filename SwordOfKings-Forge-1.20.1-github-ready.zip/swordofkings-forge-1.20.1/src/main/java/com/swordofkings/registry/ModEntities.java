package com.swordofkings.registry;

import com.swordofkings.SwordOfKingsMod;
import com.swordofkings.entity.KingBossEntity;
import com.swordofkings.entity.KingGemEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = SwordOfKingsMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SwordOfKingsMod.MODID);

    public static final RegistryObject<EntityType<KingBossEntity>> KING_BOSS = ENTITIES.register("king_boss",
            () -> EntityType.Builder.of(KingBossEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 2.7F)
                    .fireImmune()
                    .clientTrackingRange(10)
                    .build("king_boss"));

    public static final RegistryObject<EntityType<KingGemEntity>> KING_GEM = ENTITIES.register("king_gem",
            () -> EntityType.Builder.<KingGemEntity>of(KingGemEntity::new, MobCategory.MISC)
                    .sized(0.4F, 0.4F)
                    .fireImmune()
                    .noSave()
                    .clientTrackingRange(10)
                    .updateInterval(Integer.MAX_VALUE)
                    .setShouldReceiveVelocityUpdates(false)
                    .build("king_gem"));

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(KING_BOSS.get(), KingBossEntity.createAttributes().build());
    }

    private ModEntities() {}
}
