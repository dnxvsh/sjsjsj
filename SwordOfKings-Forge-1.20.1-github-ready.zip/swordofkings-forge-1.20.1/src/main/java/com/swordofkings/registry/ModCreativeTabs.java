package com.swordofkings.registry;

import com.swordofkings.SwordOfKingsMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SwordOfKingsMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.swordofkings"))
                    .icon(() -> new ItemStack(ModItems.SWORD_OF_KINGS.get()))
                    .displayItems((params, out) -> {
                        out.accept(ModItems.SWORD_OF_KINGS.get());
                        out.accept(ModItems.KINGS_ALTAR.get());
                        out.accept(ModItems.KING_BOSS_SPAWN_EGG.get());
                        out.accept(ModItems.KINGS_HAMMER.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
