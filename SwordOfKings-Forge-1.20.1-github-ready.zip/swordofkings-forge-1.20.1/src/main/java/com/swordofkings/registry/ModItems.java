package com.swordofkings.registry;

import com.swordofkings.SwordOfKingsMod;
import com.swordofkings.item.SwordOfKingsItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SwordOfKingsMod.MODID);

    public static final RegistryObject<Item> SWORD_OF_KINGS = ITEMS.register("sword_of_kings",
            () -> new SwordOfKingsItem(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> KINGS_HAMMER = ITEMS.register("kings_hammer",
            () -> new Item(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    public static final RegistryObject<Item> GEM_RED = ITEMS.register("kings_gem_red", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> GEM_BLACK = ITEMS.register("kings_gem_black", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> GEM_WHITE = ITEMS.register("kings_gem_white", () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> KINGS_ALTAR = ITEMS.register("kings_altar",
            () -> new BlockItem(ModBlocks.KINGS_ALTAR.get(), new Item.Properties().rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> KING_BOSS_SPAWN_EGG = ITEMS.register("king_boss_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.KING_BOSS, 0x1E1028, 0xC01830, new Item.Properties()));

    private ModItems() {}
}
