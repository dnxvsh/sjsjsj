package com.swordofkings.registry;

import com.swordofkings.SwordOfKingsMod;
import com.swordofkings.block.KingsAltarBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, SwordOfKingsMod.MODID);

    public static final RegistryObject<Block> KINGS_ALTAR = BLOCKS.register("kings_altar",
            () -> new KingsAltarBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BLACK)
                    .strength(-1.0F, 3600000.0F)
                    .sound(SoundType.DEEPSLATE_TILES)
                    .lightLevel(state -> 12)
                    .noOcclusion()));

    private ModBlocks() {}
}
