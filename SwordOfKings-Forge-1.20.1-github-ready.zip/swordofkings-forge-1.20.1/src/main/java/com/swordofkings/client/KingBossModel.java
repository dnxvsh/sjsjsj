package com.swordofkings.client;

import com.swordofkings.entity.KingBossEntity;
import net.minecraft.client.model.AnimationUtils;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;

/** Zombie-style humanoid with raised arms while attacking (so the hammer is held out in front). */
public class KingBossModel extends HumanoidModel<KingBossEntity> {
    public KingBossModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setupAnim(KingBossEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        AnimationUtils.animateZombieArms(this.leftArm, this.rightArm, entity.isAggressive(), this.attackTime, ageInTicks);
    }
}
