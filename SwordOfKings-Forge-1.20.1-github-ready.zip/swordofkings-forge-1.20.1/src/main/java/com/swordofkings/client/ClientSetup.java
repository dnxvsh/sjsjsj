package com.swordofkings.client;

import com.swordofkings.SwordOfKingsMod;
import com.swordofkings.registry.ModBlockEntities;
import com.swordofkings.registry.ModEntities;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SwordOfKingsMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.KING_BOSS.get(), KingBossRenderer::new);
        event.registerEntityRenderer(ModEntities.KING_GEM.get(), ctx -> new ThrownItemRenderer<>(ctx, 1.5F, true));
        event.registerBlockEntityRenderer(ModBlockEntities.ALTAR.get(), AltarRenderer::new);
    }

    @SubscribeEvent
    public static void onKeys(RegisterKeyMappingsEvent event) {
        event.register(KeyBindings.LIGHTNING);
        event.register(KeyBindings.DARKNESS);
        event.register(KeyBindings.RUSH);
        event.register(KeyBindings.GEMS);
        event.register(KeyBindings.RECALL);
    }

    @SubscribeEvent
    public static void onOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("kings_hud", HudOverlay.OVERLAY);
    }

    private ClientSetup() {}
}
