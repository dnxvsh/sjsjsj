package com.swordofkings.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

/** Default keys: Z / X / C / V for the four abilities, R to summon the sword back. All can be changed in Controls. */
public final class KeyBindings {
    public static final String CATEGORY = "key.categories.swordofkings";

    public static final KeyMapping LIGHTNING = make("key.swordofkings.lightning", GLFW.GLFW_KEY_Z);
    public static final KeyMapping DARKNESS = make("key.swordofkings.darkness", GLFW.GLFW_KEY_X);
    public static final KeyMapping RUSH = make("key.swordofkings.rush", GLFW.GLFW_KEY_C);
    public static final KeyMapping GEMS = make("key.swordofkings.gems", GLFW.GLFW_KEY_V);
    public static final KeyMapping RECALL = make("key.swordofkings.recall", GLFW.GLFW_KEY_R);

    public static final KeyMapping[] ABILITIES = {LIGHTNING, DARKNESS, RUSH, GEMS};

    private static KeyMapping make(String name, int key) {
        return new KeyMapping(name, KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, key, CATEGORY);
    }

    private KeyBindings() {}
}
