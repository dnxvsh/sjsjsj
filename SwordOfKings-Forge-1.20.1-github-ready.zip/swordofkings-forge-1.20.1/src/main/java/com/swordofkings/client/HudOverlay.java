package com.swordofkings.client;

import com.swordofkings.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** Full-screen flash + the four ability slots (key, name, cooldown) shown while the sword is in hand. */
public final class HudOverlay {
    private static final String[] NAMES = {
            "ability.swordofkings.lightning", "ability.swordofkings.darkness",
            "ability.swordofkings.rush", "ability.swordofkings.gems"};

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;

        if (ClientFx.flashTicks > 0) {
            float a = ClientFx.flashAlpha * Math.max(0F, ClientFx.flashTicks - partialTick) / ClientFx.flashMax;
            int alpha = Math.min(255, Math.max(0, (int) (a * 255F)));
            g.fill(0, 0, width, height, (alpha << 24) | (ClientFx.flashColor & 0xFFFFFF));
        }

        boolean holding = p.getMainHandItem().is(ModItems.SWORD_OF_KINGS.get()) || p.getOffhandItem().is(ModItems.SWORD_OF_KINGS.get());
        if (!holding || mc.options.hideGui) return;

        Font font = mc.font;
        int boxW = 128, boxH = 17, gap = 3;
        int x = width - boxW - 8;
        int y = height - 52 - 5 * (boxH + gap);
        long now = mc.level.getGameTime();

        for (int i = 0; i < 4; i++) {
            int by = y + i * (boxH + gap);
            long left = ClientFx.READY_AT[i] - now;
            boolean ready = left <= 0;
            g.fill(x, by, x + boxW, by + boxH, 0xAA0A0A10);
            if (!ready) {
                int fill = (int) (boxW * Math.min(1.0, left / (double) ClientFx.TOTAL[i]));
                g.fill(x, by, x + fill, by + boxH, 0x99701018);
            }
            g.renderOutline(x, by, boxW, boxH, ready ? 0xFFE02030 : 0xFF55555F);
            String key = KeyBindings.ABILITIES[i].getTranslatedKeyMessage().getString();
            g.drawString(font, Component.literal("[" + key + "] ").append(Component.translatable(NAMES[i])), x + 4, by + 5, ready ? 0xFFFFFF : 0x9A9AA5, true);
            if (!ready) {
                String s = String.format("%.1fs", left / 20.0);
                g.drawString(font, s, x + boxW - 4 - font.width(s), by + 5, 0xFFD0D0, true);
            }
        }
        int ry = y + 4 * (boxH + gap);
        String rk = KeyBindings.RECALL.getTranslatedKeyMessage().getString();
        g.drawString(font, Component.literal("[" + rk + "] ").append(Component.translatable("ability.swordofkings.recall")), x + 4, ry + 4, 0xB0B0B8, true);
    };

    private HudOverlay() {}
}
