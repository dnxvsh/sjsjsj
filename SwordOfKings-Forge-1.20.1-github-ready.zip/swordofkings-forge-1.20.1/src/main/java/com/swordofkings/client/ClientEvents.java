package com.swordofkings.client;

import com.swordofkings.SwordOfKingsMod;
import com.swordofkings.ability.AbilityManager;
import com.swordofkings.network.AbilityPacket;
import com.swordofkings.network.ModNetwork;
import com.swordofkings.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

import java.util.List;

@Mod.EventBusSubscriber(modid = SwordOfKingsMod.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(0.9F, 0.03F, 0.08F), 1.0F);
    private static final DustParticleOptions BLACK = new DustParticleOptions(new Vector3f(0.05F, 0.0F, 0.1F), 1.3F);
    private static final DustParticleOptions WHITE = new DustParticleOptions(new Vector3f(1.0F, 1.0F, 1.0F), 0.8F);
    private static final ItemStack BLOOD_DROP = new ItemStack(Items.REDSTONE_BLOCK);

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        ClientFx.tick();
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        if (mc.screen == null) {
            for (int i = 0; i < 4; i++) {
                KeyMapping key = KeyBindings.ABILITIES[i];
                while (key.consumeClick()) ModNetwork.CHANNEL.sendToServer(new AbilityPacket(i));
            }
            while (KeyBindings.RECALL.consumeClick()) ModNetwork.CHANNEL.sendToServer(new AbilityPacket(AbilityManager.RECALL));
        }
        swordAura(mc);
    }

    /** Blood, sparks and a low heartbeat around every sword that is held, so it feels alive. */
    private static void swordAura(Minecraft mc) {
        RandomSource r = mc.level.random;
        long time = mc.level.getGameTime();
        for (AbstractClientPlayer p : mc.level.players()) {
            if (!p.getMainHandItem().is(ModItems.SWORD_OF_KINGS.get())) continue;
            Vec3 look = p.getViewVector(1.0F);
            Vec3 right = new Vec3(-look.z, 0, look.x).normalize();
            Vec3 hand = p.position().add(0, p.getBbHeight() * 0.62, 0).add(look.scale(0.55)).add(right.scale(0.38));
            Vec3 blade = look.scale(0.45).add(0, 0.9, 0).normalize();
            for (int i = 0; i < 3; i++) {
                double t = r.nextDouble() * 1.5;
                Vec3 pos = hand.add(blade.scale(t));
                DustParticleOptions col = i == 0 ? RED : (i == 1 ? WHITE : BLACK);
                mc.level.addParticle(col, pos.x + (r.nextDouble() - 0.5) * 0.25, pos.y + (r.nextDouble() - 0.5) * 0.25,
                        pos.z + (r.nextDouble() - 0.5) * 0.25, 0, 0.01, 0);
            }
            if (time % 4 == 0) {
                Vec3 pos = hand.add(blade.scale(r.nextDouble() * 1.2));
                mc.level.addParticle(new ItemParticleOption(ParticleTypes.ITEM, BLOOD_DROP), pos.x, pos.y, pos.z, 0, 0, 0);
            }
            if (r.nextInt(5) == 0) {
                Vec3 pos = hand.add(blade.scale(r.nextDouble() * 1.4));
                mc.level.addParticle(ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y, pos.z, 0, 0, 0);
            }
            if (time % 45 == 0) {
                mc.level.playLocalSound(p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.PLAYERS, 0.45F, 0.7F, false);
            }
            if (time % 90 == 0) {
                mc.level.playLocalSound(p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 0.35F, 0.55F, false);
            }
        }
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        if (ClientFx.shakeTicks <= 0) return;
        float fade = ClientFx.shakeTicks / (float) Math.max(1, ClientFx.shakeMax);
        float amp = ClientFx.shakeIntensity * fade;
        RandomSource r = Minecraft.getInstance().level == null ? RandomSource.create() : Minecraft.getInstance().level.random;
        event.setYaw(event.getYaw() + (r.nextFloat() - 0.5F) * amp * 2.0F);
        event.setPitch(event.getPitch() + (r.nextFloat() - 0.5F) * amp * 2.0F);
        event.setRoll(event.getRoll() + (r.nextFloat() - 0.5F) * amp * 3.0F);
    }

    /** Shows the real (rebindable) keys in the sword tooltip. */
    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent event) {
        if (!event.getItemStack().is(ModItems.SWORD_OF_KINGS.get())) return;
        List<Component> tip = event.getToolTip();
        tip.add(Component.empty());
        tip.add(Component.translatable("tooltip.swordofkings.controls").withStyle(ChatFormatting.GOLD));
        String[] names = {"ability.swordofkings.lightning", "ability.swordofkings.darkness", "ability.swordofkings.rush", "ability.swordofkings.gems"};
        for (int i = 0; i < 4; i++) {
            tip.add(Component.literal("[").append(KeyBindings.ABILITIES[i].getTranslatedKeyMessage()).append("] ")
                    .withStyle(ChatFormatting.YELLOW).append(Component.translatable(names[i]).withStyle(ChatFormatting.GRAY)));
        }
        tip.add(Component.literal("[").append(KeyBindings.RECALL.getTranslatedKeyMessage()).append("] ")
                .withStyle(ChatFormatting.YELLOW).append(Component.translatable("ability.swordofkings.recall").withStyle(ChatFormatting.GRAY)));
    }

    private ClientEvents() {}
}
