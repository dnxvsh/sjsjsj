package com.swordofkings.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.swordofkings.SwordOfKingsMod;
import com.swordofkings.entity.KingBossEntity;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

public class KingBossRenderer extends HumanoidMobRenderer<KingBossEntity, KingBossModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(SwordOfKingsMod.MODID, "textures/entity/king_boss.png");
    private static final ResourceLocation EYES = new ResourceLocation(SwordOfKingsMod.MODID, "textures/entity/king_boss_eyes.png");

    public KingBossRenderer(EntityRendererProvider.Context context) {
        super(context, new KingBossModel(context.bakeLayer(ModelLayers.ZOMBIE)), 0.9F);
        this.addLayer(new EyesLayer<KingBossEntity, KingBossModel>(this) {
            @Override
            public RenderType renderType() {
                return RenderType.eyes(EYES);
            }
        });
    }

    @Override
    protected void scale(KingBossEntity entity, PoseStack pose, float partialTick) {
        pose.scale(1.5F, 1.5F, 1.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(KingBossEntity entity) {
        return TEXTURE;
    }
}
