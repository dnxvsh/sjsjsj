package com.swordofkings.client;

import com.swordofkings.network.FxPacket;
import net.minecraft.client.Minecraft;

/** Client-side state for camera shake, screen flash and ability cooldowns (filled by network packets). */
public final class ClientFx {
    /** Game time at which each of the four abilities is ready again, and the length of its last cooldown. */
    public static final long[] READY_AT = new long[4];
    public static final int[] TOTAL = new int[4];

    static float shakeIntensity;
    static int shakeTicks;
    static int shakeMax;

    static int flashColor;
    static float flashAlpha;
    static int flashTicks;
    static int flashMax;

    public static void handle(int type, int color, float intensity, int duration) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (type == FxPacket.SHAKE) {
            float current = shakeMax <= 0 ? 0F : shakeIntensity * shakeTicks / (float) shakeMax;
            if (intensity >= current) {
                shakeIntensity = intensity;
                shakeTicks = duration;
                shakeMax = Math.max(1, duration);
            }
        } else if (type == FxPacket.FLASH) {
            flashColor = color;
            flashAlpha = intensity;
            flashTicks = duration;
            flashMax = Math.max(1, duration);
        }
    }

    public static void setCooldown(int ability, int ticks) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || ability < 0 || ability > 3) return;
        READY_AT[ability] = mc.level.getGameTime() + ticks;
        TOTAL[ability] = Math.max(1, ticks);
    }

    static void tick() {
        if (shakeTicks > 0) shakeTicks--;
        if (flashTicks > 0) flashTicks--;
    }

    private ClientFx() {}
}
