package com.swordofkings.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.swordofkings.block.KingsAltarBlockEntity;
import com.swordofkings.registry.ModItems;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/** Draws the sword floating and spinning above the altar; when claimed it flies to the player. */
public class AltarRenderer implements BlockEntityRenderer<KingsAltarBlockEntity> {
    private final ItemRenderer itemRenderer;
    private ItemStack stack;

    public AltarRenderer(BlockEntityRendererProvider.Context context) {
        this.itemRenderer = context.getItemRenderer();
    }

    @Override
    public void render(KingsAltarBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers, int light, int overlay) {
        int phase = be.getPhase();
        Level level = be.getLevel();
        if (phase == KingsAltarBlockEntity.EMPTY || level == null) return;
        if (stack == null) stack = new ItemStack(ModItems.SWORD_OF_KINGS.get());

        float time = level.getGameTime() + partialTick;
        boolean angry = phase == KingsAltarBlockEntity.SUMMONING || phase == KingsAltarBlockEntity.BOSS;
        double x = 0.5, y = 1.95 + Math.sin(time * 0.08) * 0.12, z = 0.5;
        float spin = time * (angry ? 9.0F : 3.5F);
        float scale = 2.4F;

        UUID claimant = be.getClaimant();
        if (claimant != null && be.getClaimStart() >= 0) {
            float prog = ((level.getGameTime() - be.getClaimStart()) + partialTick) / (float) KingsAltarBlockEntity.CLAIM_TICKS;
            prog = Math.max(0F, Math.min(1F, prog));
            Player p = level.getPlayerByUUID(claimant);
            if (p != null) {
                Vec3 base = Vec3.atBottomCenterOf(be.getBlockPos());
                Vec3 from = base.add(0, 1.95, 0);
                Vec3 to = p.getPosition(partialTick).add(0, p.getBbHeight() * 0.6, 0);
                float e = prog * prog * (3 - 2 * prog);
                Vec3 at = from.lerp(to, e).add(0, Math.sin(prog * Math.PI) * 1.2, 0);
                x = at.x - base.x + 0.5;
                y = at.y - base.y;
                z = at.z - base.z + 0.5;
                spin += prog * 1400.0F;
                scale = 2.4F - 1.3F * prog;
            }
        }

        pose.pushPose();
        pose.translate(x, y, z);
        pose.mulPose(Axis.YP.rotationDegrees(spin));
        pose.mulPose(Axis.ZP.rotationDegrees(-45.0F));     // the sprite is drawn diagonally: stand the blade upright
        pose.scale(scale, scale, scale);
        itemRenderer.renderStatic(stack, ItemDisplayContext.FIXED, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                pose, buffers, level, 0);
        pose.popPose();
    }

    @Override
    public boolean shouldRenderOffScreen(KingsAltarBlockEntity be) {
        return true;
    }
}
