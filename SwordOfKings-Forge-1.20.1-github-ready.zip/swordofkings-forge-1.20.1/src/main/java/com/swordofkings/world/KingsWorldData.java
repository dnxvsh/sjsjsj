package com.swordofkings.world;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** World-level storage: per-player boss progress, vault location and the id of the current sword. */
public class KingsWorldData extends SavedData {
    private static final String NAME = "swordofkings_data";

    public static class Progress {
        public boolean dragon, wither, warden;
        public boolean mapGiven;
        public boolean swordClaimed;
        public boolean hasVault;
        public long vault;
        @Nullable public UUID sword;

        public int count() {
            return (dragon ? 1 : 0) + (wither ? 1 : 0) + (warden ? 1 : 0);
        }

        public boolean allBosses() {
            return dragon && wither && warden;
        }

        public BlockPos vaultPos() {
            return BlockPos.of(vault);
        }
    }

    private final Map<UUID, Progress> players = new HashMap<>();

    public static KingsWorldData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(KingsWorldData::load, KingsWorldData::new, NAME);
    }

    public Progress of(UUID id) {
        return players.computeIfAbsent(id, k -> new Progress());
    }

    @Nullable
    public UUID currentSword(UUID owner) {
        Progress p = players.get(owner);
        return p == null ? null : p.sword;
    }

    public static KingsWorldData load(CompoundTag tag) {
        KingsWorldData data = new KingsWorldData();
        ListTag list = tag.getList("Players", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            if (!t.hasUUID("Id")) continue;
            Progress p = new Progress();
            p.dragon = t.getBoolean("Dragon");
            p.wither = t.getBoolean("Wither");
            p.warden = t.getBoolean("Warden");
            p.mapGiven = t.getBoolean("MapGiven");
            p.swordClaimed = t.getBoolean("SwordClaimed");
            p.hasVault = t.getBoolean("HasVault");
            p.vault = t.getLong("Vault");
            if (t.hasUUID("Sword")) p.sword = t.getUUID("Sword");
            data.players.put(t.getUUID("Id"), p);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, Progress> e : players.entrySet()) {
            Progress p = e.getValue();
            CompoundTag t = new CompoundTag();
            t.putUUID("Id", e.getKey());
            t.putBoolean("Dragon", p.dragon);
            t.putBoolean("Wither", p.wither);
            t.putBoolean("Warden", p.warden);
            t.putBoolean("MapGiven", p.mapGiven);
            t.putBoolean("SwordClaimed", p.swordClaimed);
            t.putBoolean("HasVault", p.hasVault);
            t.putLong("Vault", p.vault);
            if (p.sword != null) t.putUUID("Sword", p.sword);
            list.add(t);
        }
        tag.put("Players", list);
        return tag;
    }
}
