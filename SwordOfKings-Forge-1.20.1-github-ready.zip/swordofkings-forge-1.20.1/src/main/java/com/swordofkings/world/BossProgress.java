package com.swordofkings.world;

import com.swordofkings.SwordOfKingsMod;
import com.swordofkings.ability.Fx;
import com.swordofkings.ability.ServerEffects;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.annotation.Nullable;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Tracks the three required kills (Ender Dragon, Wither, Warden). Every player within 128 blocks of the boss
 * (plus the killer) is credited. When all three are done a treasure map arrives.
 */
@Mod.EventBusSubscriber(modid = SwordOfKingsMod.MODID)
public final class BossProgress {
    private static final int DRAGON = 0, WITHER = 1, WARDEN = 2;

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        LivingEntity dead = event.getEntity();
        if (dead.level().isClientSide) return;
        if (dead instanceof WitherBoss) credit(dead, WITHER, event.getSource());
        else if (dead instanceof Warden) credit(dead, WARDEN, event.getSource());
        else if (dead instanceof EnderDragon) credit(dead, DRAGON, event.getSource());
    }

    /** The dragon plays a long death animation and is removed with reason KILLED at its end - catch that as well. */
    @SubscribeEvent
    public static void onLeave(EntityLeaveLevelEvent event) {
        if (event.getLevel().isClientSide) return;
        if (event.getEntity() instanceof EnderDragon dragon && dragon.getRemovalReason() == Entity.RemovalReason.KILLED) {
            credit(dragon, DRAGON, null);
        }
    }

    private static void credit(LivingEntity dead, int kind, @Nullable DamageSource source) {
        if (!(dead.level() instanceof ServerLevel level)) return;
        MinecraftServer server = level.getServer();
        Set<ServerPlayer> credited = new LinkedHashSet<>();
        if (source != null && source.getEntity() instanceof ServerPlayer killer) credited.add(killer);
        for (ServerPlayer sp : level.players()) {
            if (!sp.isSpectator() && sp.distanceToSqr(dead) <= 128.0 * 128.0) credited.add(sp);
        }
        KingsWorldData data = KingsWorldData.get(server);
        for (ServerPlayer sp : credited) {
            KingsWorldData.Progress pr = data.of(sp.getUUID());
            boolean changed = false;
            switch (kind) {
                case DRAGON -> { if (!pr.dragon) { pr.dragon = true; changed = true; } }
                case WITHER -> { if (!pr.wither) { pr.wither = true; changed = true; } }
                default -> { if (!pr.warden) { pr.warden = true; changed = true; } }
            }
            if (!changed) continue;
            data.setDirty();
            String key = kind == DRAGON ? "boss.swordofkings.dragon" : (kind == WITHER ? "boss.swordofkings.wither" : "boss.swordofkings.warden");
            sp.sendSystemMessage(Component.translatable("msg.swordofkings.boss_progress", Component.translatable(key), pr.count())
                    .withStyle(ChatFormatting.DARK_RED));
            Fx.sound(sp.serverLevel(), sp.getX(), sp.getY(), sp.getZ(), SoundEvents.WITHER_SPAWN, 0.6F, 1.6F);
            if (pr.allBosses() && !pr.mapGiven) {
                pr.mapGiven = true;                   // guard against a second trigger while the delay runs
                data.setDirty();
                ServerEffects.delay(120, () -> giveMap(sp));
            }
        }
    }

    /** Builds the player's vault (once) and hands over the treasure map. */
    public static void giveMap(ServerPlayer sp) {
        MinecraftServer server = sp.getServer();
        if (server == null || sp.isRemoved()) return;
        ServerLevel overworld = server.overworld();
        KingsWorldData data = KingsWorldData.get(server);
        KingsWorldData.Progress pr = data.of(sp.getUUID());
        if (!pr.hasVault) {
            BlockPos origin = sp.level().dimension() == Level.OVERWORLD ? sp.blockPosition() : overworld.getSharedSpawnPos();
            BlockPos vault = VaultBuilder.buildNear(overworld, origin, sp.getRandom());
            pr.vault = vault.asLong();
            pr.hasVault = true;
        }
        pr.mapGiven = true;
        data.setDirty();

        ItemStack map = VaultBuilder.makeMap(overworld, pr.vaultPos());
        if (!sp.getInventory().add(map)) sp.drop(map, false);

        sp.connection.send(new ClientboundSetTitlesAnimationPacket(10, 90, 30));
        sp.connection.send(new ClientboundSetSubtitleTextPacket(Component.translatable("msg.swordofkings.map_subtitle").withStyle(ChatFormatting.GRAY)));
        sp.connection.send(new ClientboundSetTitleTextPacket(Component.translatable("msg.swordofkings.map_title").withStyle(ChatFormatting.DARK_RED)));
        Fx.sound(sp.serverLevel(), sp.getX(), sp.getY(), sp.getZ(), SoundEvents.ENDER_DRAGON_GROWL, 1.0F, 0.6F);
        Fx.sound(sp.serverLevel(), sp.getX(), sp.getY(), sp.getZ(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 0.8F);
    }

    private BossProgress() {}
}
