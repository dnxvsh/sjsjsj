package com.swordofkings.world;

import com.swordofkings.SwordOfKingsMod;
import com.swordofkings.registry.ModItems;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** A dropped Sword of Kings never despawns, burns or gets blown up (the void can still take it - use the recall key). */
@Mod.EventBusSubscriber(modid = SwordOfKingsMod.MODID)
public final class SwordEvents {
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide) return;
        if (event.getEntity() instanceof ItemEntity item && item.getItem().is(ModItems.SWORD_OF_KINGS.get())) {
            item.setUnlimitedLifetime();
            item.setInvulnerable(true);
            item.setGlowingTag(true);
        }
    }

    private SwordEvents() {}
}
