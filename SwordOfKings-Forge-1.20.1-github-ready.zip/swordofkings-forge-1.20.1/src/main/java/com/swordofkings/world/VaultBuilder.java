package com.swordofkings.world;

import com.swordofkings.registry.ModBlocks;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.saveddata.maps.MapDecoration;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;

/** Builds the sealed underground vault that holds the altar, and the treasure map that points to it. */
public final class VaultBuilder {
    /** Interior half-size: the room is 15 x 15, 9 blocks tall, wrapped in a one-block shell. */
    private static final int H = 8;
    private static final int HEIGHT = 9;

    /** Picks a far-away dry spot, builds the vault there and returns the position of the altar. */
    public static BlockPos buildNear(ServerLevel level, BlockPos origin, RandomSource rnd) {
        int x = origin.getX() + 600, z = origin.getZ();
        int surface = 64;
        for (int attempt = 0; attempt < 24; attempt++) {
            double angle = rnd.nextDouble() * Math.PI * 2.0;
            double dist = 450.0 + rnd.nextDouble() * 450.0;
            x = origin.getX() + (int) (Math.cos(angle) * dist);
            z = origin.getZ() + (int) (Math.sin(angle) * dist);
            if (!level.getWorldBorder().isWithinBounds(x, z)) continue;
            level.getChunk(x >> 4, z >> 4);                       // make sure the chunk really exists before reading heights
            surface = level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, x, z);
            Holder<Biome> biome = level.getBiome(new BlockPos(x, surface, z));
            if (biome.is(BiomeTags.IS_OCEAN) || biome.is(BiomeTags.IS_RIVER)) continue;
            break;
        }
        int floorY = Mth.clamp(surface - 28, -44, 48);
        return buildAt(level, new BlockPos(x, floorY, z), rnd);
    }

    /** Builds the vault with its floor centre (and altar) at {@code center}. */
    public static BlockPos buildAt(ServerLevel level, BlockPos center, RandomSource rnd) {
        int cx = center.getX(), cy = center.getY(), cz = center.getZ();

        for (int dx = -H - 1; dx <= H + 1; dx++) {
            for (int dz = -H - 1; dz <= H + 1; dz++) {
                for (int dy = -1; dy <= HEIGHT; dy++) {
                    boolean shell = Math.abs(dx) == H + 1 || Math.abs(dz) == H + 1 || dy == -1 || dy == HEIGHT;
                    BlockPos p = new BlockPos(cx + dx, cy + dy, cz + dz);
                    if (!shell) {
                        level.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
                    } else if (dy == -1 && Math.abs(dx) <= H && Math.abs(dz) <= H) {
                        level.setBlock(p, floorBlock(dx, dz), 2);
                    } else {
                        level.setBlock(p, wallBlock(rnd), 2);
                    }
                }
            }
        }

        // four pillars with soul lanterns, and glowing lights in the ceiling
        int[][] pillars = {{5, 5}, {-5, 5}, {5, -5}, {-5, -5}};
        for (int[] pl : pillars) {
            for (int dy = 0; dy <= 5; dy++) {
                level.setBlock(new BlockPos(cx + pl[0], cy + dy, cz + pl[1]), Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState(), 2);
            }
            level.setBlock(new BlockPos(cx + pl[0], cy + 6, cz + pl[1]), Blocks.CRYING_OBSIDIAN.defaultBlockState(), 2);
            level.setBlock(new BlockPos(cx + pl[0], cy + 7, cz + pl[1]), Blocks.SOUL_LANTERN.defaultBlockState(), 2);
        }
        int[][] lights = {{0, 0}, {5, 0}, {-5, 0}, {0, 5}, {0, -5}};
        for (int[] l : lights) {
            level.setBlock(new BlockPos(cx + l[0], cy + HEIGHT, cz + l[1]), Blocks.SHROOMLIGHT.defaultBlockState(), 2);
        }
        // soul torches on the four walls
        for (int off : new int[]{-4, 0, 4}) {
            level.setBlock(new BlockPos(cx - H, cy + 3, cz + off), Blocks.SOUL_WALL_TORCH.defaultBlockState().setValue(net.minecraft.world.level.block.WallTorchBlock.FACING, Direction.EAST), 2);
            level.setBlock(new BlockPos(cx + H, cy + 3, cz + off), Blocks.SOUL_WALL_TORCH.defaultBlockState().setValue(net.minecraft.world.level.block.WallTorchBlock.FACING, Direction.WEST), 2);
            level.setBlock(new BlockPos(cx + off, cy + 3, cz - H), Blocks.SOUL_WALL_TORCH.defaultBlockState().setValue(net.minecraft.world.level.block.WallTorchBlock.FACING, Direction.SOUTH), 2);
            level.setBlock(new BlockPos(cx + off, cy + 3, cz + H), Blocks.SOUL_WALL_TORCH.defaultBlockState().setValue(net.minecraft.world.level.block.WallTorchBlock.FACING, Direction.NORTH), 2);
        }

        level.setBlock(center, ModBlocks.KINGS_ALTAR.get().defaultBlockState(), 3);
        return center;
    }

    private static BlockState floorBlock(int dx, int dz) {
        int d = Math.max(Math.abs(dx), Math.abs(dz));
        if (d <= 1) return Blocks.GILDED_BLACKSTONE.defaultBlockState();
        if (d == 2) return Blocks.RED_NETHER_BRICKS.defaultBlockState();
        if (d == 3) return Blocks.CHISELED_POLISHED_BLACKSTONE.defaultBlockState();
        if (d == H) return ((dx + dz) & 1) == 0 ? Blocks.CRYING_OBSIDIAN.defaultBlockState() : Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        return ((dx + dz) & 1) == 0 ? Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState() : Blocks.BLACKSTONE.defaultBlockState();
    }

    private static BlockState wallBlock(RandomSource rnd) {
        int r = rnd.nextInt(100);
        if (r < 68) return Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        if (r < 83) return Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        if (r < 94) return Blocks.BLACKSTONE.defaultBlockState();
        if (r < 98) return Blocks.GILDED_BLACKSTONE.defaultBlockState();
        return Blocks.CRYING_OBSIDIAN.defaultBlockState();
    }

    /** A filled map centred on the vault with a red X on it. */
    public static ItemStack makeMap(ServerLevel level, BlockPos vault) {
        ItemStack map = MapItem.create(level, vault.getX(), vault.getZ(), (byte) 2, true, true);
        MapItem.renderBiomePreviewMap(level, map);
        MapItemSavedData.addTargetDecoration(map, vault, "+", MapDecoration.Type.RED_X);
        map.setHoverName(Component.translatable("item.swordofkings.kings_map").withStyle(ChatFormatting.DARK_RED));
        return map;
    }

    private VaultBuilder() {}
}
