package com.mco.herobrinemod.entities;

import com.mco.herobrinemod.config.HerobrineConfig;
import com.mco.herobrinemod.main.HerobrineDamageSources;
import com.mco.herobrinemod.main.ModEntities;
import com.mco.herobrinemod.main.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.ChatFormatting;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.items.ItemHandlerHelper;

/**
 * Herobrine, phase 2: the giant. Shrinks at 50% and 25% health, summons a phase 1 copy at 50%
 * and Corrupted Ghasts all the time, and uses four attacks (fireballs, fire breath, sword, lightning).
 */
public class HardHerobrineEntity extends AbstractHerobrine {
    public static final int ANIM_SHOOT = 1;
    public static final int ANIM_FIRE = 2;
    public static final int ANIM_SWORD = 3;
    public static final int ANIM_LIGHTNING = 4;
    public static final int ANIM_DEATH_FULL = 5;
    public static final int ANIM_DEATH = 6;

    /** Model scale per stage (stage 0: full health, 1: at most 50%, 2: at most 25%). */
    private static final float[] STAGE_SCALES = {6.0F, 3.0F, 1.5F};
    private static final int[] STAGE_RESISTANCE = {0, 1, 3};
    private static final int MAX_GHASTS = 8;

    private static final EntityDataAccessor<Integer> DATA_STAGE =
            SynchedEntityData.defineId(HardHerobrineEntity.class, EntityDataSerializers.INT);

    private int deathTicks;
    private boolean spawnedCopy;
    private boolean effectsApplied;

    /** Smoothly interpolated model scale (client only, ticks based, so independent of the frame rate). */
    private float renderScale = STAGE_SCALES[0];
    private float renderScaleOld = STAGE_SCALES[0];

    public HardHerobrineEntity(EntityType<? extends HardHerobrineEntity> type, Level level) {
        super(type, level);
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.FOLLOW_RANGE, 66.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.33D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.ARMOR, 8.0D)
                .add(Attributes.MAX_HEALTH, 1500.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_STAGE, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new RandomStrollGoal(this, 1.5D));
        this.goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 64.0F));
        this.goalSelector.addGoal(2, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Player.class, false));
    }

    // ------------------------------------------------------------------ stage / scale

    public int getStage() {
        return this.entityData.get(DATA_STAGE);
    }

    /** Target scale of the current stage. */
    public float getScale() {
        return STAGE_SCALES[Mth.clamp(getStage(), 0, STAGE_SCALES.length - 1)];
    }

    /** Interpolated scale used by the renderer. */
    public float getRenderScale(float partialTick) {
        return Mth.lerp(partialTick, this.renderScaleOld, this.renderScale);
    }

    public int getDeathTicks() {
        return this.deathTicks;
    }

    /** The flashing frames of the long death animation (used by the model, renderer and layers). */
    public static boolean isDeathPulse(int ticks) {
        return (ticks >= 100 && ticks <= 101)
                || (ticks >= 120 && ticks <= 121)
                || (ticks >= 140 && ticks <= 141)
                || (ticks >= 145 && ticks <= 150 && ticks % 5 == 0)
                || (ticks >= 151 && ticks <= 156 && ticks % 4 == 0)
                || (ticks >= 156 && ticks <= 162 && ticks % 3 == 0)
                || (ticks >= 163 && ticks <= 190 && ticks % 2 == 0);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (DATA_STAGE.equals(key)) {
            this.refreshDimensions();
        }
        super.onSyncedDataUpdated(key);
    }

    /** The hitbox shrinks together with the model (the type is registered with the full-size 4 x 12 box). */
    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return super.getDimensions(pose).scale(getScale() / STAGE_SCALES[0]);
    }

    @Override
    protected int getAnimationDuration(int id) {
        return switch (id) {
            case ANIM_SHOOT -> 70;
            case ANIM_FIRE -> 80;
            case ANIM_SWORD -> 60;
            case ANIM_LIGHTNING -> 100;
            case ANIM_DEATH_FULL -> 200;
            case ANIM_DEATH -> 400;
            default -> 0;
        };
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Stage", getStage());
        tag.putBoolean("SpawnedCopy", this.spawnedCopy);
        tag.putInt("DeathTicks", this.deathTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_STAGE, Mth.clamp(tag.getInt("Stage"), 0, STAGE_SCALES.length - 1));
        this.spawnedCopy = tag.getBoolean("SpawnedCopy");
        this.deathTicks = tag.getInt("DeathTicks");
        this.renderScale = getScale();
        this.renderScaleOld = this.renderScale;
    }

    // ------------------------------------------------------------------ behaviour

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            clientTick();
            return;
        }
        if (isDeadOrDying()) {
            return;
        }
        if (!this.effectsApplied) {
            applyResistance();
            this.effectsApplied = true;
        }
        updateStage();

        LivingEntity target = getTarget();
        if (target != null) {
            if (getAnimation() == ANIM_NONE) {
                switch (this.random.nextInt(16)) {
                    case 0 -> startAnimation(ANIM_SHOOT);
                    case 1 -> startAnimation(ANIM_FIRE);
                    case 2 -> startAnimation(ANIM_SWORD);
                    case 3 -> startAnimation(ANIM_LIGHTNING);
                    default -> {
                    }
                }
            } else {
                runAttack(target);
            }
            approachTarget(target);
            if (this.random.nextInt(100) == 1) {
                summonGhast(target);
            }
        }

        // last stage: constant healing
        if (getStage() == 2 && this.tickCount % 50 == 0 && getHealth() > 0.0F) {
            setHealth(getHealth() + 10.0F);
        }
    }

    private void clientTick() {
        this.renderScaleOld = this.renderScale;
        float goal = getScale();
        this.renderScale += Mth.clamp(goal - this.renderScale, -0.05F, 0.05F);
        if (getAnimation() == ANIM_LIGHTNING && getAnimationTick() == 65) {
            lightningParticles();
        }
    }

    private void updateStage() {
        float fraction = getHealth() / getMaxHealth();
        int stage = fraction <= 0.25F ? 2 : fraction <= 0.5F ? 1 : 0;
        if (stage > getStage()) {
            this.entityData.set(DATA_STAGE, stage);
            applyResistance();
            if (!this.spawnedCopy) {
                this.spawnedCopy = true;
                spawnPhaseOneCopy();
            }
        }
    }

    private void applyResistance() {
        int amplifier = STAGE_RESISTANCE[Mth.clamp(getStage(), 0, STAGE_RESISTANCE.length - 1)];
        addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, MobEffectInstance.INFINITE_DURATION,
                amplifier, false, false));
    }

    private void spawnPhaseOneCopy() {
        HerobrineEntity copy = ModEntities.HEROBRINE.get().create(this.level());
        if (copy != null) {
            copy.setSecondSpawn(true);
            copy.moveTo(getX(), getY(), getZ(), 0.0F, 0.0F);
            this.level().addFreshEntity(copy);
        }
    }

    private void summonGhast(LivingEntity target) {
        int nearby = this.level().getEntitiesOfClass(CorruptedGhast.class, getBoundingBox().inflate(128.0D)).size();
        if (nearby >= MAX_GHASTS) {
            return;
        }
        CorruptedGhast ghast = ModEntities.CORRUPTED_GHAST.get().create(this.level());
        if (ghast != null) {
            ghast.moveTo(target.getX() + this.random.nextInt(5), target.getY() + this.random.nextInt(5),
                    target.getZ() + this.random.nextInt(5), 0.0F, 0.0F);
            if (this.level().noCollision(ghast)) {
                this.level().addFreshEntity(ghast);
            }
        }
    }

    /** Original movement: walk towards the target whenever the body is not facing it. */
    private void approachTarget(LivingEntity target) {
        if (getAnimation() != ANIM_NONE) {
            return;
        }
        float hitAngle = (float) ((Math.atan2(target.getZ() - getZ(), target.getX() - getX()) * 180.0D / Math.PI - 90.0D) % 360.0D);
        float bodyAngle = this.yBodyRot % 360.0F;
        if (hitAngle < 0.0F) {
            hitAngle += 360.0F;
        }
        if (bodyAngle < 0.0F) {
            bodyAngle += 360.0F;
        }
        float relative = hitAngle - bodyAngle;
        boolean facing = (relative <= 15.0F && relative >= -15.0F) || relative >= 345.0F || relative <= -345.0F;
        if (!facing && getNavigation().isDone()) {
            getNavigation().moveTo(target, 0.85D);
        }
    }

    // ------------------------------------------------------------------ attacks

    private void runAttack(LivingEntity target) {
        int tick = getAnimationTick();
        switch (getAnimation()) {
            case ANIM_SHOOT -> {
                if (tick < 10) {
                    lookAt(target, 30.0F, 30.0F);
                }
                if (tick > 10 && tick < 60 && tick % 5 == 0) {
                    shootFireball(target);
                }
            }
            case ANIM_FIRE -> {
                if (tick < 20) {
                    lookAt(target, 30.0F, 30.0F);
                } else {
                    breatheFire(target);
                }
            }
            case ANIM_SWORD -> {
                if (tick == 21 && distanceTo(target) <= getScale() * 2.0F) {
                    target.hurt(HerobrineDamageSources.hardSword(this.level(), this), 7.0F);
                }
            }
            case ANIM_LIGHTNING -> {
                if (tick > 60) {
                    for (int i = 0; i < this.random.nextInt(5); ++i) {
                        BossUtil.lightning(this.level(), target.getX(), target.getY(), target.getZ());
                    }
                }
            }
            default -> {
            }
        }
    }

    private void shootFireball(LivingEntity target) {
        Vec3 look = getViewVector(1.0F);
        float scale = getScale();
        double x = getX() + look.x * scale;
        double y = getY() + getBbHeight() * 0.58D;
        double z = getZ() + look.z * scale;
        this.level().levelEvent(null, 1016, blockPosition(), 0);
        LargeFireball fireball = new LargeFireball(this.level(), this,
                target.getX() - x, target.getY(0.5D) - y, target.getZ() - z, (int) scale);
        fireball.setPos(x, y, z);
        this.level().addFreshEntity(fireball);
    }

    private void breatheFire(LivingEntity target) {
        double y = getY() + getBbHeight() * 0.8D;
        double dx = target.getX() - getX();
        double dy = target.getY(0.5D) - y;
        double dz = target.getZ() - getZ();
        float spread = (float) Math.sqrt(Math.sqrt(distanceToSqr(target))) * 0.05F;
        for (int i = 0; i < 3; ++i) {
            SmallFireball fireball = new SmallFireball(this.level(), this,
                    dx + getRandom().nextGaussian() * spread, dy, dz + getRandom().nextGaussian() * spread);
            fireball.setPos(getX(), y, getZ());
            this.level().addFreshEntity(fireball);
        }
    }

    /** Client side: a big cloud cube around the boss when the lightning attack reaches its peak. */
    private void lightningParticles() {
        float scale = getScale();
        int radius = scale >= 3.0F ? (int) scale - 1 : (int) scale;
        int height = scale >= 3.0F ? (int) scale * 2 : (int) scale * 2 + 1;
        int steps = 10;
        for (int i = 0; i <= steps; ++i) {
            for (int j = 0; j <= steps; ++j) {
                for (int k = 0; k <= steps; ++k) {
                    this.level().addParticle(ParticleTypes.CLOUD,
                            getX() - radius + (2.0D * radius) / steps * i,
                            getY() + (double) height / steps * j,
                            getZ() - radius + (2.0D * radius) / steps * k,
                            this.random.nextGaussian() * 0.005D, this.random.nextGaussian() * 0.005D,
                            this.random.nextGaussian() * 0.005D);
                }
            }
        }
    }

    // ------------------------------------------------------------------ death

    @Override
    public void die(DamageSource source) {
        boolean alreadyDead = this.dead || isRemoved();
        super.die(source);
        if (alreadyDead || this.level().isClientSide) {
            return;
        }
        ItemStack[] drops = HerobrineConfig.enablePhase3() ? hardestSet() : halfHarderSet();
        if (source.getEntity() instanceof Player player) {
            for (ItemStack stack : drops) {
                ItemHandlerHelper.giveItemToPlayer(player, stack);
            }
        } else if (this.level().getGameRules().getBoolean(GameRules.RULE_DOMOBLOOT)) {
            for (ItemStack stack : drops) {
                this.level().addFreshEntity(new ItemEntity(this.level(), getX(), getY(), getZ(), stack));
            }
        }
    }

    private static ItemStack[] hardestSet() {
        return new ItemStack[]{
                new ItemStack(ModItems.HARDEST_HELMET.get()), new ItemStack(ModItems.HARDEST_CHESTPLATE.get()),
                new ItemStack(ModItems.HARDEST_LEGGINGS.get()), new ItemStack(ModItems.HARDEST_BOOTS.get()),
                new ItemStack(ModItems.HARDEST_SWORD.get())};
    }

    private static ItemStack[] halfHarderSet() {
        return new ItemStack[]{
                new ItemStack(ModItems.HALFHARDER_HELMET.get()), new ItemStack(ModItems.HALFHARDER_CHESTPLATE.get()),
                new ItemStack(ModItems.HALFHARDER_LEGGINGS.get()), new ItemStack(ModItems.HALFHARDER_BOOTS.get()),
                new ItemStack(ModItems.HALFHARDER_SWORD.get())};
    }

    @Override
    protected void tickDeath() {
        ++this.deathTicks;
        if (this.level().isClientSide) {
            return;
        }
        updateBossBar();
        boolean phaseThree = HerobrineConfig.enablePhase3();
        int animation = phaseThree ? ANIM_DEATH : ANIM_DEATH_FULL;
        if (getAnimation() != animation) {
            startAnimation(animation);
        }
        if (this.deathTicks > 15 && this.deathTicks % 7 == 0) {
            BossUtil.experience(this, 250);
        }
        if (!phaseThree) {
            if (this.deathTicks >= 170 && this.deathTicks % 10 == 0) {
                deathLightning();
            }
            deathFireball(20);
            if (this.deathTicks % 10 == 0) {
                deathExplosion(13);
            }
            if (this.deathTicks >= 200) {
                this.discard();
            }
        } else {
            if (this.deathTicks < 170) {
                deathFireball(20);
            }
            if (this.deathTicks % 10 == 0 && this.deathTicks < 190) {
                deathExplosion(13);
            }
            if (this.deathTicks == 182) {
                deathText(true);
            }
            if (this.deathTicks == 222) {
                deathText(false);
            }
            if (this.deathTicks == 352) {
                this.level().explode(this, getX(), getY(), getZ(), 70.0F, false, Level.ExplosionInteraction.MOB);
            }
            if (this.deathTicks >= 353) {
                this.discard();
            }
        }
    }

    private void deathLightning() {
        for (int theta = 0; theta <= 360; theta += 15) {
            // the original passed degrees to cos/sin, which just scatters the bolts; kept on purpose
            BossUtil.lightning(this.level(), getX() + Math.cos(theta) * 10.0D, getY(), getZ() + Math.sin(theta) * 10.0D);
        }
    }

    private void deathExplosion(int radius) {
        int theta = this.random.nextInt(360);
        double x = Math.cos(theta) * radius * this.random.nextDouble();
        double z = Math.sin(theta) * radius * this.random.nextDouble();
        this.level().explode(this, getX() + x, getY(), getZ() + z, 3.0F, false, Level.ExplosionInteraction.NONE);
    }

    private void deathFireball(int radius) {
        int theta = this.random.nextInt(360);
        double x = Math.cos(theta) * radius * this.random.nextDouble();
        double z = Math.sin(theta) * radius * this.random.nextDouble();
        LargeFireball fireball = new LargeFireball(this.level(), this, 0.0D, -1.0D, 0.0D, 1);
        fireball.setPos(getX() + x, getY() + 50.0D, getZ() + z);
        this.level().addFreshEntity(fireball);
    }

    private void deathText(boolean first) {
        if (this.level().getServer() == null) {
            return;
        }
        Component noise = Component.literal("1234567891011121314151617181920").withStyle(ChatFormatting.OBFUSCATED);
        Component line = Component.translatable(first ? "message.herobrinemod.grave_mistake" : "message.herobrinemod.last_one")
                .withStyle(ChatFormatting.BOLD);
        for (ServerPlayer player : this.level().getServer().getPlayerList().getPlayers()) {
            if (first) {
                player.sendSystemMessage(noise);
                player.sendSystemMessage(line);
            } else {
                player.sendSystemMessage(line);
                player.sendSystemMessage(noise);
            }
        }
    }
}
