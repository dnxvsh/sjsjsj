package com.mco.herobrinemod.entities;

import java.util.EnumSet;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Ghast;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * The special ghast of phase 2: a vanilla ghast (same size, movement and model) whose fireballs
 * are accompanied by a lightning strike on its target.
 */
public class CorruptedGhast extends Ghast {
    public CorruptedGhast(EntityType<? extends Ghast> type, Level level) {
        super(type, level);
        this.xpReward = 5;
    }

    public static AttributeSupplier.Builder createAttributes() {
        // 10 health, follow range 100 - the same numbers the original set
        return Ghast.createAttributes();
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(5, new RandomFloatAroundGoal(this));
        this.goalSelector.addGoal(7, new LookAroundGoal(this));
        this.goalSelector.addGoal(7, new FireballAttackGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false, null));
    }

    static class RandomFloatAroundGoal extends Goal {
        private final CorruptedGhast ghast;

        RandomFloatAroundGoal(CorruptedGhast ghast) {
            this.ghast = ghast;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            MoveControl control = this.ghast.getMoveControl();
            if (!control.hasWanted()) {
                return true;
            }
            double dx = control.getWantedX() - this.ghast.getX();
            double dy = control.getWantedY() - this.ghast.getY();
            double dz = control.getWantedZ() - this.ghast.getZ();
            double distance = dx * dx + dy * dy + dz * dz;
            return distance < 1.0D || distance > 3600.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return false;
        }

        @Override
        public void start() {
            RandomSource random = this.ghast.getRandom();
            double x = this.ghast.getX() + (random.nextFloat() * 2.0F - 1.0F) * 16.0F;
            double y = this.ghast.getY() + (random.nextFloat() * 2.0F - 1.0F) * 16.0F;
            double z = this.ghast.getZ() + (random.nextFloat() * 2.0F - 1.0F) * 16.0F;
            this.ghast.getMoveControl().setWantedPosition(x, y, z, 1.0D);
        }
    }

    static class LookAroundGoal extends Goal {
        private final CorruptedGhast ghast;

        LookAroundGoal(CorruptedGhast ghast) {
            this.ghast = ghast;
            this.setFlags(EnumSet.of(Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return true;
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity target = this.ghast.getTarget();
            if (target == null) {
                Vec3 movement = this.ghast.getDeltaMovement();
                this.ghast.setYRot(-((float) Mth.atan2(movement.x, movement.z)) * (180.0F / (float) Math.PI));
                this.ghast.yBodyRot = this.ghast.getYRot();
            } else if (target.distanceToSqr(this.ghast) < 4096.0D) {
                double dx = target.getX() - this.ghast.getX();
                double dz = target.getZ() - this.ghast.getZ();
                this.ghast.setYRot(-((float) Mth.atan2(dx, dz)) * (180.0F / (float) Math.PI));
                this.ghast.yBodyRot = this.ghast.getYRot();
            }
        }
    }

    static class FireballAttackGoal extends Goal {
        private final CorruptedGhast ghast;
        private int chargeTime;

        FireballAttackGoal(CorruptedGhast ghast) {
            this.ghast = ghast;
        }

        @Override
        public boolean canUse() {
            return this.ghast.getTarget() != null;
        }

        @Override
        public void start() {
            this.chargeTime = 0;
        }

        @Override
        public void stop() {
            this.ghast.setCharging(false);
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity target = this.ghast.getTarget();
            if (target == null) {
                return;
            }
            if (target.distanceToSqr(this.ghast) < 4096.0D && this.ghast.hasLineOfSight(target)) {
                Level level = this.ghast.level();
                ++this.chargeTime;
                if (this.chargeTime == 10 && !this.ghast.isSilent()) {
                    level.levelEvent(null, 1015, this.ghast.blockPosition(), 0);
                }
                if (this.chargeTime == 20) {
                    Vec3 look = this.ghast.getViewVector(1.0F);
                    double dx = target.getX() - (this.ghast.getX() + look.x * 4.0D);
                    double dy = target.getY(0.5D) - (0.5D + this.ghast.getY(0.5D));
                    double dz = target.getZ() - (this.ghast.getZ() + look.z * 4.0D);
                    if (!this.ghast.isSilent()) {
                        level.levelEvent(null, 1016, this.ghast.blockPosition(), 0);
                    }
                    LargeFireball fireball = new LargeFireball(level, this.ghast, dx, dy, dz, this.ghast.getExplosionPower());
                    fireball.setPos(this.ghast.getX() + look.x * 4.0D, this.ghast.getY(0.5D) + 0.5D,
                            this.ghast.getZ() + look.z * 4.0D);
                    level.addFreshEntity(fireball);
                    BossUtil.lightning(level, target.getX(), target.getY(), target.getZ());
                    this.chargeTime = -40;
                }
            } else if (this.chargeTime > 0) {
                --this.chargeTime;
            }
            this.ghast.setCharging(this.chargeTime > 10);
        }
    }
}
