package com.mco.herobrinemod.main;

import com.mco.herobrinemod.HerobrineMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * In 1.20.1 damage types are data driven (data/herobrinemod/damage_type/*.json).
 * The death messages are death.attack.hard_herobrine / hard_laser / hard_sword in the lang file.
 */
public final class HerobrineDamageSources {
    public static final ResourceKey<DamageType> HARD_HEROBRINE = key("hard_herobrine");
    public static final ResourceKey<DamageType> HARD_LASER = key("hard_laser");
    public static final ResourceKey<DamageType> HARD_SWORD = key("hard_sword");

    private HerobrineDamageSources() {
    }

    private static ResourceKey<DamageType> key(String name) {
        return ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation(HerobrineMod.MODID, name));
    }

    public static DamageSource of(Level level, ResourceKey<DamageType> type, @Nullable Entity attacker) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(type), attacker);
    }

    public static DamageSource hardHerobrine(Level level, @Nullable Entity attacker) {
        return of(level, HARD_HEROBRINE, attacker);
    }

    public static DamageSource hardLaser(Level level, @Nullable Entity attacker) {
        return of(level, HARD_LASER, attacker);
    }

    public static DamageSource hardSword(Level level, @Nullable Entity attacker) {
        return of(level, HARD_SWORD, attacker);
    }
}
