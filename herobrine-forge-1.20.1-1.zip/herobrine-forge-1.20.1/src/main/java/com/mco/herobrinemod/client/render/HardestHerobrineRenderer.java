package com.mco.herobrinemod.client.render;

import com.mco.herobrinemod.HerobrineMod;
import com.mco.herobrinemod.client.model.HerobrineModel;
import com.mco.herobrinemod.client.model.Phase3Model;
import com.mco.herobrinemod.entities.HardestHerobrineEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Phase 3: the 60 block colossus (model scale 30) with its two laser beams. It is always drawn at full
 * brightness, like the original.
 */
public class HardestHerobrineRenderer extends AbstractHerobrineRenderer<HardestHerobrineEntity, Phase3Model> {
    private static final ResourceLocation BEAM_TEXTURE =
            new ResourceLocation(HerobrineMod.MODID, "textures/entity/laser.png");
    private static final float MODEL_SCALE = 30.0F;
    private static final float BEAM_HALF_WIDTH = 1.7F;
    private static final double EYE_SIDE_OFFSET = 2.3D;
    private static final int FULL_BRIGHT = 0xF000F0;

    public HardestHerobrineRenderer(EntityRendererProvider.Context context) {
        super(context, new Phase3Model(context.bakeLayer(HerobrineModel.LAYER_LOCATION)), 0.5F * MODEL_SCALE);
    }

    @Override
    protected void scale(HardestHerobrineEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(MODEL_SCALE, MODEL_SCALE, MODEL_SCALE);
    }

    @Override
    protected int getBlockLightLevel(HardestHerobrineEntity entity, BlockPos pos) {
        return 15;
    }

    @Override
    protected int getSkyLightLevel(HardestHerobrineEntity entity, BlockPos pos) {
        return 15;
    }

    @Override
    public void render(HardestHerobrineEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
        Vec3 laserEnd = entity.getLaserEnd();
        if (laserEnd == null || !entity.isFiringLaser()) {
            return;
        }
        // the pose stack origin is the (interpolated) position of the entity
        double x = Mth.lerp(partialTick, entity.xo, entity.getX());
        double y = Mth.lerp(partialTick, entity.yo, entity.getY());
        double z = Mth.lerp(partialTick, entity.zo, entity.getZ());
        Vec3 end = laserEnd.subtract(x, y, z);

        float yaw = Mth.lerp(partialTick, entity.yHeadRotO, entity.yHeadRot) * Mth.DEG_TO_RAD;
        Vec3 side = new Vec3(Mth.cos(yaw), 0.0D, Mth.sin(yaw));
        Vec3 eye = new Vec3(0.0D, entity.getEyeHeight(), 0.0D);
        // scrolls along the beam while the laser is on
        float scroll = -(entity.getAnimationTick() + partialTick) * 0.25F;

        VertexConsumer consumer = buffer.getBuffer(RenderType.entityTranslucent(BEAM_TEXTURE));
        drawBeam(consumer, poseStack, eye.add(side.scale(EYE_SIDE_OFFSET)), end, scroll);
        drawBeam(consumer, poseStack, eye.add(side.scale(-EYE_SIDE_OFFSET)), end, scroll);
    }

    /** Two crossing ribbons from {@code from} to {@code to}, so the beam looks solid from every side. */
    private static void drawBeam(VertexConsumer consumer, PoseStack poseStack, Vec3 from, Vec3 to, float scroll) {
        Vec3 direction = to.subtract(from);
        double length = direction.length();
        if (length < 1.0E-3D) {
            return;
        }
        Vec3 axis = direction.scale(1.0D / length);
        Vec3 first = axis.cross(new Vec3(0.0D, 1.0D, 0.0D));
        if (first.lengthSqr() < 1.0E-6D) {
            first = new Vec3(1.0D, 0.0D, 0.0D);
        }
        first = first.normalize().scale(BEAM_HALF_WIDTH);
        Vec3 second = first.cross(axis).normalize().scale(BEAM_HALF_WIDTH);

        PoseStack.Pose pose = poseStack.last();
        float v0 = scroll;
        float v1 = scroll + (float) (length / 8.0D);
        ribbon(consumer, pose, from, to, first, v0, v1);
        ribbon(consumer, pose, from, to, second, v0, v1);
    }

    private static void ribbon(VertexConsumer consumer, PoseStack.Pose pose, Vec3 from, Vec3 to, Vec3 half,
                               float v0, float v1) {
        vertex(consumer, pose, from.subtract(half), 0.0F, v0);
        vertex(consumer, pose, from.add(half), 1.0F, v0);
        vertex(consumer, pose, to.add(half), 1.0F, v1);
        vertex(consumer, pose, to.subtract(half), 0.0F, v1);
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, Vec3 pos, float u, float v) {
        Matrix4f matrix = pose.pose();
        Matrix3f normal = pose.normal();
        consumer.vertex(matrix, (float) pos.x, (float) pos.y, (float) pos.z)
                .color(255, 255, 255, 230)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(FULL_BRIGHT)
                .normal(normal, 0.0F, 1.0F, 0.0F)
                .endVertex();
    }
}
