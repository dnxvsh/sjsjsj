package com.mco.herobrinemod.entities;

import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/**
 * Common base of the three Herobrine phases: boss bar, undead, never despawns, and a tiny
 * replacement for the LLibrary animation system (a synched animation id + a local tick counter
 * that is reset whenever the id changes, on both sides).
 */
public abstract class AbstractHerobrine extends Monster {
    public static final int ANIM_NONE = 0;

    private static final EntityDataAccessor<Integer> DATA_ANIMATION =
            SynchedEntityData.defineId(AbstractHerobrine.class, EntityDataSerializers.INT);

    protected final ServerBossEvent bossEvent = (ServerBossEvent) new ServerBossEvent(
            this.getDisplayName(), BossEvent.BossBarColor.WHITE, BossEvent.BossBarOverlay.PROGRESS)
            .setDarkenScreen(true);

    private int animationTick;

    protected AbstractHerobrine(EntityType<? extends AbstractHerobrine> type, Level level) {
        super(type, level);
        // experience is handled by the phases themselves
        this.xpReward = 0;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ANIMATION, ANIM_NONE);
    }

    // ------------------------------------------------------------------ animation

    /** Duration in ticks of the animation with the given id. */
    protected abstract int getAnimationDuration(int id);

    public int getAnimation() {
        return this.entityData.get(DATA_ANIMATION);
    }

    /** Ticks since the current animation started (local counter, valid on both sides). */
    public int getAnimationTick() {
        return this.animationTick;
    }

    /** Server side: starts an animation (the id is synched to the clients). */
    protected void startAnimation(int id) {
        this.animationTick = 0;
        this.entityData.set(DATA_ANIMATION, id);
    }

    protected void stopAnimation() {
        this.animationTick = 0;
        this.entityData.set(DATA_ANIMATION, ANIM_NONE);
    }

    /** True when the given animation is the current one and has not run out yet. */
    public boolean isPlaying(int id) {
        return getAnimation() == id && this.animationTick < getAnimationDuration(id);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (DATA_ANIMATION.equals(key)) {
            this.animationTick = 0;
        }
        super.onSyncedDataUpdated(key);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        int id = getAnimation();
        if (id == ANIM_NONE) {
            this.animationTick = 0;
            return;
        }
        ++this.animationTick;
        if (this.animationTick >= getAnimationDuration(id) && !this.level().isClientSide && !isDeadOrDying()) {
            stopAnimation();
        }
    }

    // ------------------------------------------------------------------ boss bar

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        this.bossEvent.setName(this.getDisplayName());
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        updateBossBar();
    }

    protected void updateBossBar() {
        this.bossEvent.setProgress(Math.max(0.0F, this.getHealth() / this.getMaxHealth()));
    }

    // ------------------------------------------------------------------ misc

    @Override
    public MobType getMobType() {
        return MobType.UNDEAD;
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }
}
