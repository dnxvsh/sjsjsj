package com.mco.herobrinemod;

import com.mco.herobrinemod.config.HerobrineConfig;
import com.mco.herobrinemod.main.AttributeLimits;
import com.mco.herobrinemod.main.ModEntities;
import com.mco.herobrinemod.main.ModItems;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * The Herobrine Mod - ported from Minecraft 1.12.2 to Forge 1.20.1.
 */
@Mod(HerobrineMod.MODID)
public class HerobrineMod {
    public static final String MODID = "herobrinemod";
    public static final String NAME = "The Herobrine Mod";
    public static final Logger LOGGER = LogUtils.getLogger();

    public HerobrineMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, HerobrineConfig.SPEC);

        ModEntities.ENTITY_TYPES.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModItems.CREATIVE_TABS.register(modBus);

        modBus.addListener(ModEntities::registerAttributes);
        modBus.addListener(this::commonSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        // The bosses have more than the vanilla 1024 max health, so the cap has to be raised
        // (the 1.12.2 mod did exactly the same through reflection in preInit).
        event.enqueueWork(AttributeLimits::raiseMaxHealthLimit);
    }
}
