package com.mco.herobrinemod.items;

import com.mco.herobrinemod.HerobrineMod;
import com.mco.herobrinemod.entities.HardHerobrineEntity;
import com.mco.herobrinemod.entities.HerobrineEntity;
import com.mco.herobrinemod.main.HerobrineDamageSources;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class HardSword extends SwordItem {
    private final HardTier hardTier;

    public HardSword(HardTier tier, Properties properties) {
        // same as the 1.12.2 ItemSword: 3 + material damage, vanilla sword attack speed
        super(tier, 3, -2.4F, properties);
        this.hardTier = tier;
    }

    public HardTier getHardTier() {
        return hardTier;
    }

    /**
     * Extra "true" damage against phase 1 and phase 2 (the original subtracted the material damage
     * directly from the health). The original compared the display name; here every sword works.
     */
    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (!attacker.level().isClientSide
                && (target instanceof HerobrineEntity || target instanceof HardHerobrineEntity)
                && target.getHealth() > 0.0F) {
            float remaining = target.getHealth() - hardTier.getAttackDamageBonus();
            if (remaining > 0.0F) {
                target.setHealth(remaining);
            } else {
                target.setHealth(0.0F);
                target.die(HerobrineDamageSources.hardSword(attacker.level(), attacker));
            }
        }
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        tooltip.add(Component.translatable("tooltip." + HerobrineMod.MODID + "." + hardTier.getId() + "_sword")
                .withStyle(ChatFormatting.DARK_PURPLE));
    }
}
