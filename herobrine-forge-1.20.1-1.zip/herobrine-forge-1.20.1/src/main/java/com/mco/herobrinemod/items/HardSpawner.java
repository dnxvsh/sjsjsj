package com.mco.herobrinemod.items;

import com.mco.herobrinemod.entities.HerobrineEntity;
import com.mco.herobrinemod.main.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.pattern.BlockInWorld;
import net.minecraft.world.level.block.state.pattern.BlockPattern;
import net.minecraft.world.level.block.state.pattern.BlockPatternBuilder;
import net.minecraft.world.level.block.state.predicate.BlockStatePredicate;

/**
 * Right-click on a structure made of (top to bottom) a wither skeleton skull, a diamond block
 * and an obsidian block, with air on both sides, to summon Herobrine (phase 1).
 */
public class HardSpawner extends Item {
    private static BlockPattern herobrinePattern;

    public HardSpawner(Properties properties) {
        super(properties);
    }

    private static BlockPattern getPattern() {
        if (herobrinePattern == null) {
            herobrinePattern = BlockPatternBuilder.start()
                    .aisle("ASA", "ADA", "AOA")
                    .where('D', BlockInWorld.hasState(BlockStatePredicate.forBlock(Blocks.DIAMOND_BLOCK)))
                    .where('O', BlockInWorld.hasState(BlockStatePredicate.forBlock(Blocks.OBSIDIAN)))
                    .where('A', BlockInWorld.hasState(state -> state.isAir()))
                    .where('S', BlockInWorld.hasState(
                            BlockStatePredicate.forBlock(Blocks.WITHER_SKELETON_SKULL)
                                    .or(BlockStatePredicate.forBlock(Blocks.WITHER_SKELETON_WALL_SKULL))))
                    .build();
        }
        return herobrinePattern;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPattern pattern = getPattern();
        BlockPattern.BlockPatternMatch match = pattern.find(level, context.getClickedPos());
        if (match == null) {
            return InteractionResult.PASS;
        }
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        // remove the structure (no drops)
        for (int x = 0; x < pattern.getWidth(); ++x) {
            for (int y = 0; y < pattern.getHeight(); ++y) {
                BlockInWorld cell = match.getBlock(x, y, 0);
                BlockState old = cell.getState();
                if (!old.isAir()) {
                    level.setBlock(cell.getPos(), Blocks.AIR.defaultBlockState(), 2);
                    level.levelEvent(2001, cell.getPos(), Block.getId(old));
                }
            }
        }

        BlockPos top = match.getBlock(1, 0, 0).getPos();
        BlockPos spawnPos = match.getBlock(1, 2, 0).getPos();
        float yaw = match.getForwards().getAxis() == Direction.Axis.X ? 0.0F : 90.0F;

        HerobrineEntity herobrine = ModEntities.HEROBRINE.get().create(level);
        if (herobrine != null) {
            herobrine.moveTo(spawnPos.getX() + 0.5D, spawnPos.getY() + 0.55D, spawnPos.getZ() + 0.5D, yaw, 0.0F);
            herobrine.yBodyRot = yaw;
            level.addFreshEntity(herobrine);
            level.explode(herobrine, spawnPos.getX(), spawnPos.getY(), spawnPos.getZ(), 3.0F, true,
                    Level.ExplosionInteraction.MOB);
        }

        Player player = context.getPlayer();
        if (player == null || !player.getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }

        serverLevel.sendParticles(ParticleTypes.SMOKE, top.getX() + 0.5D, top.getY() - 0.05D, top.getZ() + 0.5D,
                120, 0.5D, 1.0D, 0.5D, 0.0D);

        for (int x = 0; x < pattern.getWidth(); ++x) {
            for (int y = 0; y < pattern.getHeight(); ++y) {
                level.blockUpdated(match.getBlock(x, y, 0).getPos(), Blocks.AIR);
            }
        }
        return InteractionResult.SUCCESS;
    }
}
