package com.mco.herobrinemod.entities.ai;

import com.mco.herobrinemod.entities.HerobrineEntity;
import com.mco.herobrinemod.main.HerobrineDamageSources;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;

/** Phase 1 melee: a 4 damage "hard_herobrine" hit every 20 ticks, arms raised shortly before it. */
public class HerobrineMeleeGoal extends MeleeAttackGoal {
    private final HerobrineEntity herobrine;
    private int raiseArmTicks;

    public HerobrineMeleeGoal(HerobrineEntity herobrine, double speedModifier, boolean followEvenIfNotSeen) {
        super(herobrine, speedModifier, followEvenIfNotSeen);
        this.herobrine = herobrine;
    }

    @Override
    public void start() {
        super.start();
        this.raiseArmTicks = 0;
    }

    @Override
    public void stop() {
        super.stop();
        this.herobrine.setAttacking(false);
    }

    @Override
    public void tick() {
        super.tick();
        ++this.raiseArmTicks;
        this.herobrine.setAttacking(this.raiseArmTicks >= 5 && getTicksUntilNextAttack() <= 7);
    }

    @Override
    protected void checkAndPerformAttack(LivingEntity target, double distanceToTargetSqr) {
        if (distanceToTargetSqr <= getAttackReachSqr(target) && isTimeToAttack()) {
            resetAttackCooldown();
            this.herobrine.swing(InteractionHand.MAIN_HAND);
            target.hurt(HerobrineDamageSources.hardHerobrine(this.herobrine.level(), this.herobrine), 4.0F);
        }
    }
}
