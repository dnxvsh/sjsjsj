package com.mco.herobrinemod.entities;

import com.mco.herobrinemod.config.HerobrineConfig;
import com.mco.herobrinemod.entities.ai.HerobrineMeleeGoal;
import com.mco.herobrinemod.main.ModEntities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Herobrine, phase 1. */
public class HerobrineEntity extends AbstractHerobrine {
    public static final int ANIM_DEATH = 1;
    private static final int DEATH_DURATION = 200;

    private static final EntityDataAccessor<Boolean> DATA_ATTACKING =
            SynchedEntityData.defineId(HerobrineEntity.class, EntityDataSerializers.BOOLEAN);

    private int deathTicks;
    /** True for the copy spawned by phase 2 at half health: it just vanishes when killed. */
    private boolean secondSpawn;

    public HerobrineEntity(EntityType<? extends HerobrineEntity> type, Level level) {
        super(type, level);
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.FOLLOW_RANGE, 66.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.33D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.ARMOR, 6.0D)
                .add(Attributes.MAX_HEALTH, 666.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ATTACKING, Boolean.FALSE);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new HerobrineMeleeGoal(this, 2.0D, true));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 32.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(2, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, target(Player.class));
        this.targetSelector.addGoal(3, target(Villager.class));
        this.targetSelector.addGoal(3, target(IronGolem.class));
        this.targetSelector.addGoal(4, target(TamableAnimal.class));
        this.targetSelector.addGoal(5, target(Monster.class));
        this.targetSelector.addGoal(6, target(LivingEntity.class));
    }

    private <T extends LivingEntity> NearestAttackableTargetGoal<T> target(Class<T> type) {
        return new NearestAttackableTargetGoal<>(this, type, 10, false, false, entity -> !BossUtil.isKin(entity));
    }

    // ------------------------------------------------------------------ state

    public void setAttacking(boolean attacking) {
        this.entityData.set(DATA_ATTACKING, attacking);
    }

    public boolean isAttacking() {
        return this.entityData.get(DATA_ATTACKING);
    }

    public void setSecondSpawn(boolean secondSpawn) {
        this.secondSpawn = secondSpawn;
    }

    public boolean isSecondSpawn() {
        return this.secondSpawn;
    }

    public int getDeathTicks() {
        return this.deathTicks;
    }

    @Override
    protected int getAnimationDuration(int id) {
        return id == ANIM_DEATH ? DEATH_DURATION : 0;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("SecondSpawn", this.secondSpawn);
        tag.putInt("DeathTicks", this.deathTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.secondSpawn = tag.getBoolean("SecondSpawn");
        this.deathTicks = tag.getInt("DeathTicks");
    }

    // ------------------------------------------------------------------ behaviour

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide || isDeadOrDying()) {
            return;
        }
        if (getTarget() == null) {
            // like the original: always go after the nearest (non creative) player within 32 blocks
            Player player = this.level().getNearestPlayer(getX(), getY(), getZ(), 32.0D, true);
            if (player != null) {
                setTarget(player);
            }
        }
        LivingEntity target = getTarget();
        if (target != null && this.deathTicks == 0) {
            getLookControl().setLookAt(target, 10.0F, 10.0F);
            if (this.random.nextInt(70) == 1) {
                shootBigFireball(target);
            }
            if (this.random.nextInt(50) == 1) {
                shootBlazeFireballs(target);
            }
        }
    }

    private void shootBigFireball(LivingEntity target) {
        Vec3 look = getViewVector(1.0F);
        double dx = target.getX() - (getX() + look.x * 4.0D);
        double dy = target.getY(0.5D) - (0.5D + getY(0.5D));
        double dz = target.getZ() - (getZ() + look.z * 4.0D);
        this.level().levelEvent(null, 1016, blockPosition(), 0);
        LargeFireball fireball = new LargeFireball(this.level(), this, dx, dy, dz, 1);
        fireball.setPos(getX(), getY(0.5D) - 0.5D, getZ());
        this.level().addFreshEntity(fireball);
    }

    private void shootBlazeFireballs(LivingEntity target) {
        double distanceSqr = distanceToSqr(target);
        double dx = target.getX() - getX();
        double dy = target.getY(0.5D) - getY(0.5D);
        double dz = target.getZ() - getZ();
        float spread = (float) Math.sqrt(Math.sqrt(distanceSqr)) * 0.5F;
        for (int i = 0; i < 4; ++i) {
            SmallFireball fireball = new SmallFireball(this.level(), this,
                    dx + getRandom().nextGaussian() * spread, dy, dz + getRandom().nextGaussian() * spread);
            fireball.setPos(fireball.getX(), getY(0.5D) + 0.5D, fireball.getZ());
            this.level().addFreshEntity(fireball);
        }
    }

    // ------------------------------------------------------------------ death

    @Override
    protected void tickDeath() {
        ++this.deathTicks;
        if (this.level().isClientSide) {
            return;
        }
        updateBossBar();
        boolean second = this.secondSpawn;
        if (!second && HerobrineConfig.enablePhase2()) {
            if (getAnimation() != ANIM_DEATH) {
                startAnimation(ANIM_DEATH);
            }
            if (this.deathTicks > 15 && this.deathTicks % 5 == 0) {
                BossUtil.experience(this, 250);
            }
            if (this.deathTicks >= 170 && this.deathTicks % 10 == 0) {
                for (int angle = 0; angle < 360; angle += 15) {
                    BossUtil.lightning(this.level(),
                            getX() + Math.cos(Math.toRadians(angle)), getY(), getZ() + Math.sin(Math.toRadians(angle)));
                }
            }
            if (this.deathTicks == 199) {
                spawnPhaseTwo();
            }
            if (this.deathTicks >= DEATH_DURATION) {
                this.discard();
            }
        } else {
            if (this.deathTicks == 1 && !second) {
                // phase 2 disabled: the original dropped nothing here, we at least give the experience
                BossUtil.experience(this, 250);
            }
            this.discard();
        }
    }

    private void spawnPhaseTwo() {
        HardHerobrineEntity phaseTwo = ModEntities.HARD_HEROBRINE.get().create(this.level());
        if (phaseTwo != null) {
            phaseTwo.moveTo(getX(), getY(), getZ(), getYRot(), 0.0F);
            this.level().addFreshEntity(phaseTwo);
        }
    }
}
