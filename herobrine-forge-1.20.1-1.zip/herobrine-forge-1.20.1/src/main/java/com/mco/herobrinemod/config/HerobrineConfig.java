package com.mco.herobrinemod.config;

import net.minecraftforge.common.ForgeConfigSpec;

/**
 * Same options as the 1.12.2 config file, now stored in herobrinemod-common.toml.
 */
public class HerobrineConfig {
    public static final ForgeConfigSpec SPEC;

    private static final ForgeConfigSpec.DoubleValue LASER_DAMAGE;
    private static final ForgeConfigSpec.BooleanValue LASER_FIRE;
    private static final ForgeConfigSpec.BooleanValue ENABLE_PHASE_2;
    private static final ForgeConfigSpec.BooleanValue ENABLE_PHASE_3;
    private static final ForgeConfigSpec.BooleanValue DISABLE_EPILEPSY;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        LASER_DAMAGE = builder
                .comment("Damage dealt by direct contact with laser")
                .defineInRange("laserDamage", 10.0D, 0.0D, 1000000.0D);
        LASER_FIRE = builder
                .comment("Should the laser set fire to the terrain")
                .define("laserFire", true);
        ENABLE_PHASE_2 = builder
                .comment("Whether or not to enable the second phase of the Herobrine fight")
                .define("enablePhase2", true);
        ENABLE_PHASE_3 = builder
                .comment("Whether or not to enable the third phase of the Herobrine fight")
                .define("enablePhase3", true);
        DISABLE_EPILEPSY = builder
                .comment("If true, disables a part of the fight that may trigger epilepsy")
                .define("disableEpilepsy", false);

        SPEC = builder.build();
    }

    public static float laserDamage() {
        return LASER_DAMAGE.get().floatValue();
    }

    public static boolean laserFire() {
        return LASER_FIRE.get();
    }

    public static boolean enablePhase2() {
        return ENABLE_PHASE_2.get();
    }

    public static boolean enablePhase3() {
        return ENABLE_PHASE_3.get();
    }

    public static boolean disableEpilepsy() {
        return DISABLE_EPILEPSY.get();
    }
}
