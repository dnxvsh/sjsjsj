package com.mco.herobrinemod.client.layer;

import com.mco.herobrinemod.client.model.HerobrineModel;
import com.mco.herobrinemod.entities.AbstractHerobrine;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

/** The glowing eyes (the original "LayerHerobrineEyes" / "LayerHardEyes"): a full-bright overlay skin. */
public class HerobrineEyesLayer<T extends AbstractHerobrine, M extends HerobrineModel<T>> extends EyesLayer<T, M> {
    private final RenderType renderType;

    public HerobrineEyesLayer(RenderLayerParent<T, M> parent, ResourceLocation glowTexture) {
        super(parent);
        this.renderType = RenderType.eyes(glowTexture);
    }

    @Override
    public RenderType renderType() {
        return this.renderType;
    }
}
