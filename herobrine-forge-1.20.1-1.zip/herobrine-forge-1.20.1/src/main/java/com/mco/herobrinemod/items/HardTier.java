package com.mco.herobrinemod.items;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

/**
 * Sword tiers. Values are the 1.12.2 tool materials of the original mod:
 * harvest level 3, max uses, efficiency, attack damage bonus, enchantability.
 */
public enum HardTier implements Tier {
    HARD("hard", 2342, 12.0F, 15.0F, 15),
    HARDER("harder", 3342, 14.0F, 21.0F, 17),
    HALFHARDER("halfharder", 3842, 15.0F, 24.0F, 18),
    HARDEST("hardest", 4342, 18.0F, 27.0F, 20);

    private final String id;
    private final int uses;
    private final float speed;
    private final float damage;
    private final int enchantability;

    HardTier(String id, int uses, float speed, float damage, int enchantability) {
        this.id = id;
        this.uses = uses;
        this.speed = speed;
        this.damage = damage;
        this.enchantability = enchantability;
    }

    public String getId() {
        return id;
    }

    @Override
    public int getUses() {
        return uses;
    }

    @Override
    public float getSpeed() {
        return speed;
    }

    @Override
    public float getAttackDamageBonus() {
        return damage;
    }

    @Override
    public int getLevel() {
        return 3;
    }

    @Override
    public int getEnchantmentValue() {
        return enchantability;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.EMPTY;
    }
}
