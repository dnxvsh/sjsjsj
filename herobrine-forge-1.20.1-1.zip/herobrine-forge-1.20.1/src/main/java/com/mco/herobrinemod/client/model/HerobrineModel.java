package com.mco.herobrinemod.client.model;

import com.mco.herobrinemod.HerobrineMod;
import com.mco.herobrinemod.entities.AbstractHerobrine;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.model.ArmedModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/**
 * The humanoid body shared by all three phases (the original "ModelHumanoid"): the body is split
 * in two halves and every arm and leg in two segments.
 */
public abstract class HerobrineModel<T extends AbstractHerobrine> extends EntityModel<T> implements ArmedModel {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(HerobrineMod.MODID, "herobrine"), "main");

    private final Map<String, ModelPart> parts = new HashMap<>();

    protected HerobrineModel(ModelPart root) {
        ModelPart chest = root.getChild("Chest");
        ModelPart chestB = chest.getChild("ChestB");
        ModelPart rArmA = chest.getChild("RArmA");
        ModelPart lArmA = chest.getChild("LArmA");
        ModelPart rLegA = chestB.getChild("RLegA");
        ModelPart lLegA = chestB.getChild("LLegA");
        this.parts.put("Chest", chest);
        this.parts.put("ChestB", chestB);
        this.parts.put("Head", chest.getChild("Head"));
        this.parts.put("RArmA", rArmA);
        this.parts.put("RArmB", rArmA.getChild("RArmB"));
        this.parts.put("LArmA", lArmA);
        this.parts.put("LArmB", lArmA.getChild("LArmB"));
        this.parts.put("RLegA", rLegA);
        this.parts.put("RLegB", rLegA.getChild("RLegB"));
        this.parts.put("LLegA", lLegA);
        this.parts.put("LLegB", lLegA.getChild("LLegB"));
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition chest = root.addOrReplaceChild("Chest",
                CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 6.0F, 4.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        chest.addOrReplaceChild("Head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        PartDefinition rArmA = chest.addOrReplaceChild("RArmA",
                CubeListBuilder.create().texOffs(32, 48).addBox(-1.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F),
                PartPose.offset(5.0F, 0.0F, 0.0F));
        rArmA.addOrReplaceChild("RArmB",
                CubeListBuilder.create().texOffs(40, 24).addBox(-2.0F, 1.0F, -2.0F, 4.0F, 6.0F, 4.0F),
                PartPose.offset(1.0F, 5.0F, 0.0F));

        PartDefinition lArmA = chest.addOrReplaceChild("LArmA",
                CubeListBuilder.create().texOffs(32, 48).addBox(-3.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F),
                PartPose.offset(-5.0F, 0.0F, 0.0F));
        lArmA.addOrReplaceChild("LArmB",
                CubeListBuilder.create().texOffs(40, 24).addBox(-2.0F, 1.0F, -2.0F, 4.0F, 6.0F, 4.0F),
                PartPose.offset(-1.0F, 5.0F, 0.0F));

        PartDefinition chestB = chest.addOrReplaceChild("ChestB",
                CubeListBuilder.create().texOffs(16, 22).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 6.0F, 4.0F),
                PartPose.offset(0.0F, 6.0F, 0.0F));

        PartDefinition rLegA = chestB.addOrReplaceChild("RLegA",
                CubeListBuilder.create().texOffs(16, 48).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F),
                PartPose.offset(1.9F, 6.0F, 0.0F));
        rLegA.addOrReplaceChild("RLegB",
                CubeListBuilder.create().texOffs(16, 54).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F),
                PartPose.offset(0.0F, 6.0F, 0.0F));

        PartDefinition lLegA = chestB.addOrReplaceChild("LLegA",
                CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F),
                PartPose.offset(-1.9F, 6.0F, 0.0F));
        lLegA.addOrReplaceChild("LLegB",
                CubeListBuilder.create().texOffs(0, 22).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F),
                PartPose.offset(0.0F, 6.0F, 0.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    protected ModelPart part(String name) {
        return this.parts.get(name);
    }

    /** Applies one of the keyframe animations to the current pose. */
    protected void play(KeyframeAnimation animation, T entity, float partialTick) {
        animation.apply(entity.getAnimationTick(), partialTick, this.parts::get);
    }

    /** Phase specific animations, called after the walking pose was set up. */
    protected abstract void animate(T entity, float partialTick);

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        for (ModelPart part : this.parts.values()) {
            part.resetPose();
        }
        part("Head").xRot = headPitch / 50.0F;
        part("Head").yRot = netHeadYaw / 50.0F;
        part("LLegA").xRot = Mth.cos(limbSwing * 0.3262F) * 1.4F * limbSwingAmount;
        part("LLegB").xRot = Math.abs(Mth.cos(limbSwing * 0.2262F)) * 1.4F * limbSwingAmount;
        part("RArmA").xRot = Mth.cos(limbSwing * 0.2662F) * 1.4F * limbSwingAmount;
        part("RArmB").xRot = Math.abs(Mth.cos(limbSwing * 0.0662F)) * -1.0F * limbSwingAmount;
        part("RLegA").xRot = Mth.cos(limbSwing * 0.3262F + (float) Math.PI) * 1.4F * limbSwingAmount;
        part("RLegB").xRot = Math.abs(Mth.cos(limbSwing * 0.2262F + (float) Math.PI)) * 1.4F * limbSwingAmount;
        part("LArmA").xRot = Mth.cos(limbSwing * 0.1662F + (float) Math.PI) * 1.2F * limbSwingAmount;
        part("LArmB").xRot = Math.abs(Mth.cos(limbSwing * 0.0662F + (float) Math.PI)) * -1.0F * limbSwingAmount;
        part("Chest").xRot = Math.abs(Mth.cos(limbSwing * 0.2662F)) * 0.5F * limbSwingAmount;

        animate(entity, ageInTicks - entity.tickCount);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer consumer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        part("Chest").render(poseStack, consumer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    /** Items are always held by the "LArmA" part, like in the original (for both hands). */
    @Override
    public void translateToHand(HumanoidArm arm, PoseStack poseStack) {
        part("Chest").translateAndRotate(poseStack);
        part("LArmA").translateAndRotate(poseStack);
        poseStack.mulPose(Axis.XP.rotationDegrees(-10.0F));
    }
}
