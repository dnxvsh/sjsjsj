package com.mco.herobrinemod.client.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/**
 * A replacement for LLibrary's ModelAnimator: a list of keyframes whose transforms are <b>added</b> to
 * the base pose. A normal keyframe blends (sine ease-out) from the previous keyframe's transforms to
 * its own, a "hold" keeps the previous transforms, a "reset" blends back to the base pose.
 * Outside of the keyframe time range nothing is applied.
 */
public final class KeyframeAnimation {
    private static final int ROT_X = 0, ROT_Y = 1, ROT_Z = 2, POS_X = 3, POS_Y = 4, POS_Z = 5;

    private record Frame(int start, int duration, boolean hold, Map<String, float[]> from, Map<String, float[]> to) {
    }

    private final List<Frame> frames;
    private final int duration;

    private KeyframeAnimation(List<Frame> frames, int duration) {
        this.frames = frames;
        this.duration = duration;
    }

    public static Builder builder() {
        return new Builder();
    }

    /** Total length of all keyframes in ticks. */
    public int getDuration() {
        return duration;
    }

    /**
     * @param tick    the integer animation tick
     * @param partial the partial tick (0..1)
     * @param parts   looks up a model part by its name
     */
    public void apply(int tick, float partial, Function<String, ModelPart> parts) {
        for (Frame frame : frames) {
            if (tick < frame.start() || tick >= frame.start() + frame.duration()) {
                continue;
            }
            if (frame.hold()) {
                add(parts, frame.from(), 1.0F);
            } else {
                float progress = Mth.clamp((tick - frame.start() + partial) / frame.duration(), 0.0F, 1.0F);
                float inc = Mth.sin(progress * (float) Math.PI / 2.0F);
                add(parts, frame.from(), 1.0F - inc);
                add(parts, frame.to(), inc);
            }
            return;
        }
    }

    private static void add(Function<String, ModelPart> parts, Map<String, float[]> transforms, float weight) {
        for (Map.Entry<String, float[]> entry : transforms.entrySet()) {
            ModelPart part = parts.apply(entry.getKey());
            float[] t = entry.getValue();
            part.xRot += weight * t[ROT_X];
            part.yRot += weight * t[ROT_Y];
            part.zRot += weight * t[ROT_Z];
            part.x += weight * t[POS_X];
            part.y += weight * t[POS_Y];
            part.z += weight * t[POS_Z];
        }
    }

    public static final class Builder {
        private final List<Frame> frames = new ArrayList<>();
        private Map<String, float[]> current = new HashMap<>();
        private Map<String, float[]> building;
        private int building_duration;
        private int cursor;

        private Builder() {
        }

        public Builder start(int duration) {
            this.building = new HashMap<>();
            this.building_duration = duration;
            return this;
        }

        public Builder rot(String part, float x, float y, float z) {
            float[] t = this.building.computeIfAbsent(part, k -> new float[6]);
            t[ROT_X] += x;
            t[ROT_Y] += y;
            t[ROT_Z] += z;
            return this;
        }

        public Builder move(String part, float x, float y, float z) {
            float[] t = this.building.computeIfAbsent(part, k -> new float[6]);
            t[POS_X] += x;
            t[POS_Y] += y;
            t[POS_Z] += z;
            return this;
        }

        public Builder end() {
            this.frames.add(new Frame(this.cursor, this.building_duration, false, this.current, this.building));
            this.cursor += this.building_duration;
            this.current = this.building;
            this.building = null;
            return this;
        }

        public Builder hold(int duration) {
            this.frames.add(new Frame(this.cursor, duration, true, this.current, this.current));
            this.cursor += duration;
            return this;
        }

        public Builder reset(int duration) {
            Map<String, float[]> empty = new HashMap<>();
            this.frames.add(new Frame(this.cursor, duration, false, this.current, empty));
            this.cursor += duration;
            this.current = empty;
            return this;
        }

        public KeyframeAnimation build() {
            return new KeyframeAnimation(List.copyOf(this.frames), this.cursor);
        }
    }
}
