package com.mco.herobrinemod.armor;

import net.minecraft.world.item.ArmorItem;

public class HardArmor extends ArmorItem {
    private final HardArmorMaterial hardMaterial;

    public HardArmor(HardArmorMaterial material, ArmorItem.Type type, Properties properties) {
        super(material, type, properties);
        this.hardMaterial = material;
    }

    public HardArmorMaterial getHardMaterial() {
        return hardMaterial;
    }
}
