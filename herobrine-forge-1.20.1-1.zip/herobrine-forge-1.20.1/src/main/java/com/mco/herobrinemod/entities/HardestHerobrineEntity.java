package com.mco.herobrinemod.entities;

import com.mco.herobrinemod.config.HerobrineConfig;
import com.mco.herobrinemod.main.HerobrineDamageSources;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Herobrine, phase 3: a 60 block tall colossus that sweeps a huge laser around.
 * (In the original mod this phase is only available through its spawn egg.)
 */
public class HardestHerobrineEntity extends AbstractHerobrine {
    public static final int ANIM_LASER = 1;
    public static final int ANIM_DEATH = 2;

    @Nullable
    private Vec3 laserStart;
    @Nullable
    private Vec3 laserEnd;

    public HardestHerobrineEntity(EntityType<? extends HardestHerobrineEntity> type, Level level) {
        super(type, level);
        this.noCulling = true;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.FOLLOW_RANGE, 66.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.33D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.ARMOR, 6.0D)
                .add(Attributes.MAX_HEALTH, 666.0D);
    }

    @Override
    protected int getAnimationDuration(int id) {
        return switch (id) {
            case ANIM_LASER -> 91;
            case ANIM_DEATH -> 200;
            default -> 0;
        };
    }

    /** Eye position of the beam (client use: renderer). */
    @Nullable
    public Vec3 getLaserStart() {
        return this.laserStart;
    }

    /** Where the beam ends (client use: renderer). */
    @Nullable
    public Vec3 getLaserEnd() {
        return this.laserEnd;
    }

    /** True while the beam is actually being fired. */
    public boolean isFiringLaser() {
        return getAnimation() == ANIM_LASER && getAnimationTick() > 1 && getAnimationTick() < 90;
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, net.minecraft.world.damagesource.DamageSource source) {
        return false;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (isDeadOrDying()) {
            return;
        }
        if (!this.level().isClientSide && getAnimation() == ANIM_NONE && this.random.nextInt(32) == 0) {
            startAnimation(ANIM_LASER);
        }
        if (getAnimation() == ANIM_LASER) {
            if (!this.level().isClientSide) {
                // look down and sweep 1 degree per tick (rotation is synched to the clients by vanilla)
                setXRot(38.0F);
                if (isFiringLaser()) {
                    float yaw = getYRot() + 1.0F;
                    setYRot(yaw);
                    setYHeadRot(yaw);
                    this.yBodyRot = yaw;
                }
            }
            if (isFiringLaser()) {
                laser();
            }
        }
    }

    private void laser() {
        Level level = this.level();
        Vec3 start = getEyePosition(1.0F);
        Vec3 rayStart = start.add(0.0D, -10.0D, 0.0D);
        Vec3 look = getViewVector(1.0F);
        Vec3 rayEnd = rayStart.add(look.scale(75.0D));
        BlockHitResult hit = level.clip(new ClipContext(rayStart, rayEnd, ClipContext.Block.OUTLINE, ClipContext.Fluid.ANY, this));
        Vec3 far = hit.getLocation();

        BlockPos corner = BlockPos.containing(far);
        double diffX = corner.getX() - start.x;
        double diffY = corner.getY() - start.y;
        double diffZ = corner.getZ() - start.z;
        double length = Math.sqrt(diffX * diffX + diffY * diffY + diffZ * diffZ);

        for (int i = 0; i < length; ++i) {
            // the original sampled i/32 of the way (not i/length); kept
            double factor = i / 32.0D;
            BlockPos slope = BlockPos.containing(start.x + diffX * factor, start.y + diffY * factor, start.z + diffZ * factor);
            if (level.isClientSide) {
                laserParticles(slope);
            } else {
                AABB box = new AABB(slope.getX() - 2, slope.getY() - 2, slope.getZ() - 2,
                        slope.getX() + 2, slope.getY() + 2, slope.getZ() + 2);
                burnEntities(box);
                carveBlocks(box);
            }
        }

        if (!level.isClientSide && HerobrineConfig.laserFire()) {
            for (int x = 0; x < 5; ++x) {
                for (int z = 0; z < 5; ++z) {
                    BlockPos firePos = findFirePos(corner.offset(x, 0, z));
                    if (firePos != null) {
                        level.setBlockAndUpdate(firePos, BaseFireBlock.getState(level, firePos));
                    }
                }
            }
        }
        this.laserStart = start;
        this.laserEnd = far;
    }

    private void burnEntities(AABB box) {
        for (Entity entity : this.level().getEntities(this, box)) {
            entity.hurt(HerobrineDamageSources.hardLaser(this.level(), this), HerobrineConfig.laserDamage());
            entity.setSecondsOnFire(10);
        }
    }

    private void carveBlocks(AABB box) {
        BlockPos origin = blockPosition();
        for (double x = box.minX; x < box.maxX; x += 1.0D) {
            for (double y = box.minY; y < box.maxY; y += 1.0D) {
                for (double z = box.minZ; z < box.maxZ; z += 1.0D) {
                    BlockPos pos = BlockPos.containing(x, y, z);
                    if (Math.sqrt(pos.distSqr(origin)) >= 100.0D) {
                        continue;
                    }
                    BlockState state = this.level().getBlockState(pos);
                    if (state.isAir() || !state.getFluidState().isEmpty() || state.is(Blocks.FIRE)
                            || state.getDestroySpeed(this.level(), pos) < 0.0F) {
                        continue;
                    }
                    this.level().setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
    }

    /** Looks (a few blocks down, then a few up) for an air block that fire can stand in. */
    @Nullable
    private BlockPos findFirePos(BlockPos pos) {
        Level level = this.level();
        BlockPos current = pos;
        for (int i = 0; i < 6 && level.isInWorldBounds(current) && level.getBlockState(current).isAir(); ++i) {
            if (!level.getBlockState(current.below()).isAir()) {
                return BaseFireBlock.canBePlacedAt(level, current, net.minecraft.core.Direction.UP) ? current : null;
            }
            current = current.below();
        }
        current = pos;
        for (int i = 0; i < 6 && level.isInWorldBounds(current); ++i) {
            if (level.getBlockState(current).isAir()) {
                return BaseFireBlock.canBePlacedAt(level, current, net.minecraft.core.Direction.UP) ? current : null;
            }
            current = current.above();
        }
        return null;
    }

    private void laserParticles(BlockPos slope) {
        Level level = this.level();
        if (this.random.nextInt(5) == 0) {
            level.addParticle(ParticleTypes.END_ROD,
                    slope.getX() + (this.random.nextDouble() - 0.5D) * 4.0D,
                    slope.getY() + this.random.nextDouble() * 6.0D,
                    slope.getZ() + (this.random.nextDouble() - 0.5D) * 4.0D, 0.0D, 0.0D, 0.0D);
        }
        if (this.random.nextInt(2) == 0) {
            level.addParticle(ParticleTypes.FLAME,
                    slope.getX() + (this.random.nextDouble() - 0.5D) * 4.0D,
                    slope.getY() + this.random.nextDouble() * 6.0D,
                    slope.getZ() + (this.random.nextDouble() - 0.5D) * 4.0D, 0.0D, 0.0D, 0.0D);
        }
    }
}
