package com.mco.herobrinemod.client;

import com.mco.herobrinemod.HerobrineMod;
import com.mco.herobrinemod.client.model.HerobrineModel;
import com.mco.herobrinemod.client.render.CorruptedGhastRenderer;
import com.mco.herobrinemod.client.render.HardHerobrineRenderer;
import com.mco.herobrinemod.client.render.HardestHerobrineRenderer;
import com.mco.herobrinemod.client.render.HerobrineRenderer;
import com.mco.herobrinemod.main.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client only: model layers and entity renderers (loaded only on the physical client). */
@Mod.EventBusSubscriber(modid = HerobrineMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {
    }

    @SubscribeEvent
    public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(HerobrineModel.LAYER_LOCATION, HerobrineModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.HEROBRINE.get(), HerobrineRenderer::new);
        event.registerEntityRenderer(ModEntities.HARD_HEROBRINE.get(), HardHerobrineRenderer::new);
        event.registerEntityRenderer(ModEntities.HARDEST_HEROBRINE.get(), HardestHerobrineRenderer::new);
        event.registerEntityRenderer(ModEntities.CORRUPTED_GHAST.get(), CorruptedGhastRenderer::new);
    }
}
