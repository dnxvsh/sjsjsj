package com.mco.herobrinemod.main;

import com.mco.herobrinemod.HerobrineMod;
import com.mco.herobrinemod.armor.HardArmor;
import com.mco.herobrinemod.armor.HardArmorMaterial;
import com.mco.herobrinemod.items.HardSpawner;
import com.mco.herobrinemod.items.HardSword;
import com.mco.herobrinemod.items.HardTier;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, HerobrineMod.MODID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, HerobrineMod.MODID);

    /** Everything in here is shown in the creative tab, in registration order. */
    private static final List<RegistryObject<Item>> TAB_ITEMS = new ArrayList<>();

    // ---- swords
    public static final RegistryObject<Item> HARD_SWORD = sword("hard_sword", HardTier.HARD);
    public static final RegistryObject<Item> HARDER_SWORD = sword("harder_sword", HardTier.HARDER);
    public static final RegistryObject<Item> HALFHARDER_SWORD = sword("halfharder_sword", HardTier.HALFHARDER);
    public static final RegistryObject<Item> HARDEST_SWORD = sword("hardest_sword", HardTier.HARDEST);

    // ---- armor
    public static final RegistryObject<Item> HARD_HELMET = armor("hard_helmet", HardArmorMaterial.HARD, ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> HARD_CHESTPLATE = armor("hard_chestplate", HardArmorMaterial.HARD, ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> HARD_LEGGINGS = armor("hard_leggings", HardArmorMaterial.HARD, ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> HARD_BOOTS = armor("hard_boots", HardArmorMaterial.HARD, ArmorItem.Type.BOOTS);

    public static final RegistryObject<Item> HARDER_HELMET = armor("harder_helmet", HardArmorMaterial.HARDER, ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> HARDER_CHESTPLATE = armor("harder_chestplate", HardArmorMaterial.HARDER, ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> HARDER_LEGGINGS = armor("harder_leggings", HardArmorMaterial.HARDER, ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> HARDER_BOOTS = armor("harder_boots", HardArmorMaterial.HARDER, ArmorItem.Type.BOOTS);

    public static final RegistryObject<Item> HALFHARDER_HELMET = armor("halfharder_helmet", HardArmorMaterial.HALFHARDER, ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> HALFHARDER_CHESTPLATE = armor("halfharder_chestplate", HardArmorMaterial.HALFHARDER, ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> HALFHARDER_LEGGINGS = armor("halfharder_leggings", HardArmorMaterial.HALFHARDER, ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> HALFHARDER_BOOTS = armor("halfharder_boots", HardArmorMaterial.HALFHARDER, ArmorItem.Type.BOOTS);

    public static final RegistryObject<Item> HARDEST_HELMET = armor("hardest_helmet", HardArmorMaterial.HARDEST, ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> HARDEST_CHESTPLATE = armor("hardest_chestplate", HardArmorMaterial.HARDEST, ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> HARDEST_LEGGINGS = armor("hardest_leggings", HardArmorMaterial.HARDEST, ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> HARDEST_BOOTS = armor("hardest_boots", HardArmorMaterial.HARDEST, ArmorItem.Type.BOOTS);

    // ---- spawner item and spawn eggs
    public static final RegistryObject<Item> HARD_SPAWNER = add("hard_spawner", () -> new HardSpawner(new Item.Properties()));

    public static final RegistryObject<Item> HEROBRINE_SPAWN_EGG = add("herobrine_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.HEROBRINE, 0xFFF000, 0x000000, new Item.Properties()));
    public static final RegistryObject<Item> HARD_HEROBRINE_SPAWN_EGG = add("hard_herobrine_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.HARD_HEROBRINE, 0xFFFFFF, 0xFFFFFF, new Item.Properties()));
    public static final RegistryObject<Item> HARDEST_HEROBRINE_SPAWN_EGG = add("hardest_herobrine_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.HARDEST_HEROBRINE, 0x000000, 0x000000, new Item.Properties()));

    // ---- creative tab
    public static final RegistryObject<CreativeModeTab> TAB = CREATIVE_TABS.register("herobrinemod",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + HerobrineMod.MODID))
                    .icon(() -> new ItemStack(HARDEST_SWORD.get()))
                    .displayItems((parameters, output) -> {
                        for (RegistryObject<Item> item : TAB_ITEMS) {
                            output.accept(item.get());
                        }
                    })
                    .build());

    private ModItems() {
    }

    private static RegistryObject<Item> add(String name, Supplier<Item> factory) {
        RegistryObject<Item> object = ITEMS.register(name, factory);
        TAB_ITEMS.add(object);
        return object;
    }

    private static RegistryObject<Item> sword(String name, HardTier tier) {
        return add(name, () -> new HardSword(tier, new Item.Properties()));
    }

    private static RegistryObject<Item> armor(String name, HardArmorMaterial material, ArmorItem.Type type) {
        return add(name, () -> new HardArmor(material, type, new Item.Properties()));
    }
}
