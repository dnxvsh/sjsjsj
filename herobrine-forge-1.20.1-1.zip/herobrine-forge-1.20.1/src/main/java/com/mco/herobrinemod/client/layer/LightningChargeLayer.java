package com.mco.herobrinemod.client.layer;

import com.mco.herobrinemod.client.model.Phase2Model;
import com.mco.herobrinemod.entities.HardHerobrineEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * The crackling "charged" look while the boss gathers lightning (the original "LayerLightningCharge").
 * Uses the vanilla charged-creeper swirl texture.
 */
public class LightningChargeLayer extends RenderLayer<HardHerobrineEntity, Phase2Model> {
    private static final ResourceLocation CHARGE_TEXTURE =
            new ResourceLocation("textures/entity/creeper/creeper_armor.png");

    public LightningChargeLayer(RenderLayerParent<HardHerobrineEntity, Phase2Model> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, HardHerobrineEntity entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (!entity.isPlaying(HardHerobrineEntity.ANIM_LIGHTNING) || entity.getAnimationTick() >= 65) {
            return;
        }
        float time = entity.tickCount + partialTick;
        float offset = (time * 0.005F) % 1.0F;
        VertexConsumer consumer = buffer.getBuffer(RenderType.energySwirl(CHARGE_TEXTURE, offset, offset));
        this.getParentModel().renderToBuffer(poseStack, consumer, 15728640, OverlayTexture.NO_OVERLAY,
                1.0F, 1.0F, 1.0F, 1.0F);
    }
}
