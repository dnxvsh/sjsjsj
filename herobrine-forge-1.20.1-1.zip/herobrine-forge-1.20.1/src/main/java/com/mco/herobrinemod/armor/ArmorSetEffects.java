package com.mco.herobrinemod.armor;

import com.mco.herobrinemod.HerobrineMod;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/**
 * Full-set bonuses. In 1.12.2 this lived in ItemArmor#onArmorTick, which only runs while at
 * least one piece is worn - so the flight of the final set was never taken away after removing
 * the whole armor. A player tick handler fixes that.
 */
@Mod.EventBusSubscriber(modid = HerobrineMod.MODID)
public final class ArmorSetEffects {
    private static final String FLIGHT_TAG = HerobrineMod.MODID + ":armor_flight";
    private static final int REFRESH_INTERVAL = 10;
    private static final int EFFECT_DURATION = 30;

    private ArmorSetEffects() {
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER) {
            return;
        }
        Player player = event.player;
        if (player.isSpectator()) {
            return;
        }
        HardArmorMaterial set = fullSet(player);
        if (set != null && player.tickCount % REFRESH_INTERVAL == 0) {
            applyEffects(player, set);
        }
        updateFlight(player, set == HardArmorMaterial.HARDEST);
    }

    /** The material when all four slots hold pieces of the same tier, otherwise null. */
    private static HardArmorMaterial fullSet(Player player) {
        HardArmorMaterial found = null;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack stack = player.getItemBySlot(slot);
            if (!(stack.getItem() instanceof HardArmor armor)) {
                return null;
            }
            if (found == null) {
                found = armor.getHardMaterial();
            } else if (found != armor.getHardMaterial()) {
                return null;
            }
        }
        return found;
    }

    private static void applyEffects(Player player, HardArmorMaterial set) {
        switch (set) {
            case HARD, HARDER -> {
                give(player, MobEffects.FIRE_RESISTANCE, 2);
                give(player, MobEffects.DAMAGE_RESISTANCE, 1);
                give(player, MobEffects.REGENERATION, 1);
            }
            case HALFHARDER -> {
                give(player, MobEffects.DAMAGE_RESISTANCE, 2);
                give(player, MobEffects.REGENERATION, 1);
                give(player, MobEffects.FIRE_RESISTANCE, 3);
                give(player, MobEffects.DAMAGE_BOOST, 0);
                give(player, MobEffects.ABSORPTION, 1);
            }
            case HARDEST -> {
                give(player, MobEffects.DAMAGE_RESISTANCE, 3);
                give(player, MobEffects.REGENERATION, 3);
                give(player, MobEffects.FIRE_RESISTANCE, 4);
                give(player, MobEffects.DAMAGE_BOOST, 1);
                give(player, MobEffects.ABSORPTION, 3);
            }
        }
    }

    private static void give(Player player, MobEffect effect, int amplifier) {
        player.addEffect(new MobEffectInstance(effect, EFFECT_DURATION, amplifier, true, false, true));
    }

    private static void updateFlight(Player player, boolean grant) {
        boolean flagged = player.getPersistentData().getBoolean(FLIGHT_TAG);
        Abilities abilities = player.getAbilities();
        if (grant) {
            if (!abilities.mayfly) {
                abilities.mayfly = true;
                player.onUpdateAbilities();
            }
            if (!flagged) {
                player.getPersistentData().putBoolean(FLIGHT_TAG, true);
            }
        } else if (flagged) {
            player.getPersistentData().remove(FLIGHT_TAG);
            if (!player.isCreative() && !player.isSpectator()) {
                abilities.mayfly = false;
                abilities.flying = false;
                player.onUpdateAbilities();
            }
        }
    }
}
