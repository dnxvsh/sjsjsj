package com.mco.herobrinemod.client.render;

import com.mco.herobrinemod.HerobrineMod;
import com.mco.herobrinemod.client.layer.HerobrineEyesLayer;
import com.mco.herobrinemod.client.model.HerobrineModel;
import com.mco.herobrinemod.client.model.Phase1Model;
import com.mco.herobrinemod.entities.HerobrineEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

/** Phase 1: the normal sized Herobrine; during its death it swells up (the original steps by death tick). */
public class HerobrineRenderer extends AbstractHerobrineRenderer<HerobrineEntity, Phase1Model> {
    private static final ResourceLocation GLOW =
            new ResourceLocation(HerobrineMod.MODID, "textures/entity/herobrine_glow.png");

    public HerobrineRenderer(EntityRendererProvider.Context context) {
        super(context, new Phase1Model(context.bakeLayer(HerobrineModel.LAYER_LOCATION)), 0.5F);
        this.addLayer(new HerobrineEyesLayer<>(this, GLOW));
    }

    @Override
    protected void scale(HerobrineEntity entity, PoseStack poseStack, float partialTick) {
        int ticks = entity.getDeathTicks();
        if (ticks >= 95) {
            poseStack.scale(1.5F, 1.5F, 1.5F);
            poseStack.translate(0.0F, 0.2F, 0.0F);
        }
        if (ticks >= 105) {
            poseStack.scale(2.5F, 2.5F, 2.5F);
        }
        if (ticks >= 115) {
            poseStack.scale(1.6F, 1.6F, 1.6F);
        }
        if (ticks >= 145) {
            poseStack.translate(0.0F, -0.1F, 0.0F);
        }
    }
}
