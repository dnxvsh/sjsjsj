package com.mco.herobrinemod.client.layer;

import com.mco.herobrinemod.client.model.Phase2Model;
import com.mco.herobrinemod.entities.HardHerobrineEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.util.RandomSource;
import org.joml.Matrix4f;

/**
 * The bundle of white rays that bursts out of the boss shortly before it disappears (the original
 * "LayerDeathGlow"; drawn like the rays of the dying ender dragon).
 */
public class DeathRaysLayer extends RenderLayer<HardHerobrineEntity, Phase2Model> {
    private static final float HALF_SQRT_3 = (float) (Math.sqrt(3.0D) / 2.0D);

    public DeathRaysLayer(RenderLayerParent<HardHerobrineEntity, Phase2Model> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, HardHerobrineEntity entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        int ticks = entity.getDeathTicks();
        if (ticks <= 233 || ticks > 352) {
            return;
        }
        float progress = (ticks + partialTick) / 200.0F;
        RandomSource random = RandomSource.create(432L);
        // 1.20.1 has no RenderType.dragonRays() (added in 1.20.2); the dying ender dragon uses lightning(),
        // which draws QUADS, so every face below is written as four vertices (the tip is written twice).
        VertexConsumer consumer = buffer.getBuffer(RenderType.lightning());

        poseStack.pushPose();
        poseStack.scale(0.07F, 0.07F, 0.07F);
        poseStack.translate(0.0F, 10.0F, -2.0F);
        for (int i = 0; i < (progress + progress * progress) / 2.0F * 60.0F; ++i) {
            poseStack.mulPose(Axis.XP.rotationDegrees(random.nextFloat() * 360.0F));
            poseStack.mulPose(Axis.YP.rotationDegrees(random.nextFloat() * 360.0F));
            poseStack.mulPose(Axis.ZP.rotationDegrees(random.nextFloat() * 360.0F));
            poseStack.mulPose(Axis.XP.rotationDegrees(random.nextFloat() * 360.0F));
            poseStack.mulPose(Axis.YP.rotationDegrees(random.nextFloat() * 360.0F));
            poseStack.mulPose(Axis.ZP.rotationDegrees(random.nextFloat() * 360.0F + progress * 90.0F));
            float length = random.nextFloat() * 20.0F + 5.0F;
            float width = random.nextFloat() * 2.0F + 1.0F;
            Matrix4f matrix = poseStack.last().pose();
            // a three sided pyramid: white tip at the origin, transparent base
            tip(consumer, matrix);
            base(consumer, matrix, -HALF_SQRT_3 * width, length, -0.5F * width);
            base(consumer, matrix, HALF_SQRT_3 * width, length, -0.5F * width);
            tip(consumer, matrix);
            base(consumer, matrix, HALF_SQRT_3 * width, length, -0.5F * width);
            base(consumer, matrix, 0.0F, length, width);
            tip(consumer, matrix);
            base(consumer, matrix, 0.0F, length, width);
            base(consumer, matrix, -HALF_SQRT_3 * width, length, -0.5F * width);
        }
        poseStack.popPose();
    }

    private static void tip(VertexConsumer consumer, Matrix4f matrix) {
        // two identical vertices: together with the two base vertices they form one degenerate quad (a triangle)
        consumer.vertex(matrix, 0.0F, 0.0F, 0.0F).color(255, 255, 255, 255).endVertex();
        consumer.vertex(matrix, 0.0F, 0.0F, 0.0F).color(255, 255, 255, 255).endVertex();
    }

    private static void base(VertexConsumer consumer, Matrix4f matrix, float x, float y, float z) {
        consumer.vertex(matrix, x, y, z).color(255, 255, 255, 0).endVertex();
    }
}
