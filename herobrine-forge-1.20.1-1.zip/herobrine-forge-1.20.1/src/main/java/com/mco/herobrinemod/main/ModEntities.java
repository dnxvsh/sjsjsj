package com.mco.herobrinemod.main;

import com.mco.herobrinemod.HerobrineMod;
import com.mco.herobrinemod.entities.CorruptedGhast;
import com.mco.herobrinemod.entities.HardHerobrineEntity;
import com.mco.herobrinemod.entities.HardestHerobrineEntity;
import com.mco.herobrinemod.entities.HerobrineEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, HerobrineMod.MODID);

    /** Phase 1: 0.6 x 1.95, like a player. */
    public static final RegistryObject<EntityType<HerobrineEntity>> HEROBRINE = ENTITY_TYPES.register("herobrine",
            () -> EntityType.Builder.of(HerobrineEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).fireImmune().clientTrackingRange(10).updateInterval(3)
                    .build(id("herobrine")));

    /** Phase 2: 4 x 12 at full size (the hitbox is scaled down with the model, see HardHerobrineEntity). */
    public static final RegistryObject<EntityType<HardHerobrineEntity>> HARD_HEROBRINE = ENTITY_TYPES.register("hard_herobrine",
            () -> EntityType.Builder.of(HardHerobrineEntity::new, MobCategory.MONSTER)
                    .sized(4.0F, 12.0F).fireImmune().clientTrackingRange(16).updateInterval(3)
                    .build(id("hard_herobrine")));

    /** Phase 3: 15 x 60. */
    public static final RegistryObject<EntityType<HardestHerobrineEntity>> HARDEST_HEROBRINE = ENTITY_TYPES.register("hardest_herobrine",
            () -> EntityType.Builder.of(HardestHerobrineEntity::new, MobCategory.MONSTER)
                    .sized(15.0F, 60.0F).fireImmune().clientTrackingRange(32).updateInterval(3)
                    .build(id("hardest_herobrine")));

    /** Same size as a vanilla ghast. */
    public static final RegistryObject<EntityType<CorruptedGhast>> CORRUPTED_GHAST = ENTITY_TYPES.register("corrupted_ghast",
            () -> EntityType.Builder.of(CorruptedGhast::new, MobCategory.MONSTER)
                    .sized(4.0F, 4.0F).fireImmune().clientTrackingRange(10)
                    .build(id("corrupted_ghast")));

    private ModEntities() {
    }

    private static String id(String name) {
        return new ResourceLocation(HerobrineMod.MODID, name).toString();
    }

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(HEROBRINE.get(), HerobrineEntity.createAttributes().build());
        event.put(HARD_HEROBRINE.get(), HardHerobrineEntity.createAttributes().build());
        event.put(HARDEST_HEROBRINE.get(), HardestHerobrineEntity.createAttributes().build());
        event.put(CORRUPTED_GHAST.get(), CorruptedGhast.createAttributes().build());
    }
}
