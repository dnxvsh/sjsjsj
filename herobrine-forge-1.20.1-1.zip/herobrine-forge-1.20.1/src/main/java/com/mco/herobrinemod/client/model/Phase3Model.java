package com.mco.herobrinemod.client.model;

import com.mco.herobrinemod.entities.HardestHerobrineEntity;
import net.minecraft.client.model.geom.ModelPart;

public class Phase3Model extends HerobrineModel<HardestHerobrineEntity> {
    public Phase3Model(ModelPart root) {
        super(root);
    }

    @Override
    protected void animate(HardestHerobrineEntity entity, float partialTick) {
        if (entity.getAnimation() == HardestHerobrineEntity.ANIM_LASER) {
            play(HerobrineAnimations.P3_LASER, entity, partialTick);
        }
    }
}
