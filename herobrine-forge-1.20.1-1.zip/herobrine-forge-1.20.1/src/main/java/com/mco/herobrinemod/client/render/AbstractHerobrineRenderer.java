package com.mco.herobrinemod.client.render;

import com.mco.herobrinemod.HerobrineMod;
import com.mco.herobrinemod.client.model.HerobrineModel;
import com.mco.herobrinemod.entities.AbstractHerobrine;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

/**
 * Common part of the three Herobrine renderers: one skin, the held item (the sword) and no
 * "falling over" when the boss dies (the death sequences are animated instead).
 */
public abstract class AbstractHerobrineRenderer<T extends AbstractHerobrine, M extends HerobrineModel<T>>
        extends MobRenderer<T, M> {
    protected static final ResourceLocation TEXTURE =
            new ResourceLocation(HerobrineMod.MODID, "textures/entity/herobrine.png");

    protected AbstractHerobrineRenderer(EntityRendererProvider.Context context, M model, float shadowRadius) {
        super(context, model, shadowRadius);
        this.addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return TEXTURE;
    }

    @Override
    protected float getFlipDegrees(T entity) {
        return 0.0F;
    }
}
