package com.mco.herobrinemod.client.model;

import com.mco.herobrinemod.entities.HerobrineEntity;
import net.minecraft.client.model.geom.ModelPart;

public class Phase1Model extends HerobrineModel<HerobrineEntity> {
    public Phase1Model(ModelPart root) {
        super(root);
    }

    @Override
    protected void animate(HerobrineEntity entity, float partialTick) {
        if (entity.getAnimation() == HerobrineEntity.ANIM_DEATH) {
            play(HerobrineAnimations.P1_DEATH, entity, partialTick);
        }
    }
}
