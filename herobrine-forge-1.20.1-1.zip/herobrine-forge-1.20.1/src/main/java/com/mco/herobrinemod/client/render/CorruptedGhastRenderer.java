package com.mco.herobrinemod.client.render;

import com.mco.herobrinemod.HerobrineMod;
import com.mco.herobrinemod.entities.CorruptedGhast;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.GhastModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** The vanilla ghast model (4.5 times larger) with the dark "corrupted" skins. */
public class CorruptedGhastRenderer extends MobRenderer<CorruptedGhast, GhastModel<CorruptedGhast>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(HerobrineMod.MODID, "textures/entity/corrupted_ghast.png");
    private static final ResourceLocation SHOOTING_TEXTURE =
            new ResourceLocation(HerobrineMod.MODID, "textures/entity/corrupted_ghast_shooting.png");

    public CorruptedGhastRenderer(EntityRendererProvider.Context context) {
        super(context, new GhastModel<>(context.bakeLayer(ModelLayers.GHAST)), 1.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(CorruptedGhast entity) {
        return entity.isCharging() ? SHOOTING_TEXTURE : TEXTURE;
    }

    @Override
    protected void scale(CorruptedGhast entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(4.5F, 4.5F, 4.5F);
    }
}
