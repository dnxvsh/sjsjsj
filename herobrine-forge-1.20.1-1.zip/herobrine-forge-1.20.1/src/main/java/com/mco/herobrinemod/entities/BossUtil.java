package com.mco.herobrinemod.entities;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;

/** Small helpers shared by the boss entities. */
public final class BossUtil {
    private BossUtil() {
    }

    public static void lightning(Level level, double x, double y, double z) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(x, y, z);
            level.addFreshEntity(bolt);
        }
    }

    /** Spawns experience orbs at the entity, only when mob loot is enabled (like the original). */
    public static void experience(Entity source, int amount) {
        if (source.level() instanceof ServerLevel serverLevel
                && serverLevel.getGameRules().getBoolean(GameRules.RULE_DOMOBLOOT)) {
            ExperienceOrb.award(serverLevel, source.position(), amount);
        }
    }

    /** True for the mod's own bosses and the Corrupted Ghast: they never target each other. */
    public static boolean isKin(Entity entity) {
        return entity instanceof AbstractHerobrine || entity instanceof CorruptedGhast;
    }
}
