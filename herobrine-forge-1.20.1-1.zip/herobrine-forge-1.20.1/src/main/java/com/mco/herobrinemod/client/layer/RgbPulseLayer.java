package com.mco.herobrinemod.client.layer;

import com.mco.herobrinemod.HerobrineMod;
import com.mco.herobrinemod.client.model.Phase2Model;
import com.mco.herobrinemod.config.HerobrineConfig;
import com.mco.herobrinemod.entities.HardHerobrineEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * The colourful flashes during the long death of the second phase (the original "LayerRGB").
 * Disabled by the "disableEpilepsy" option.
 */
public class RgbPulseLayer extends RenderLayer<HardHerobrineEntity, Phase2Model> {
    private static final RenderType RENDER_TYPE =
            RenderType.eyes(new ResourceLocation(HerobrineMod.MODID, "textures/entity/rgbrine.png"));

    public RgbPulseLayer(RenderLayerParent<HardHerobrineEntity, Phase2Model> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, HardHerobrineEntity entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (HerobrineConfig.disableEpilepsy() || !HerobrineConfig.enablePhase3()
                || !HardHerobrineEntity.isDeathPulse(entity.getDeathTicks())) {
            return;
        }
        VertexConsumer consumer = buffer.getBuffer(RENDER_TYPE);
        this.getParentModel().renderToBuffer(poseStack, consumer, 15728640, OverlayTexture.NO_OVERLAY,
                1.0F, 1.0F, 1.0F, 1.0F);
    }
}
