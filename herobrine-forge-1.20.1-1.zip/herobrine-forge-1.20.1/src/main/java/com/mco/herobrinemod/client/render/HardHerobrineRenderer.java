package com.mco.herobrinemod.client.render;

import com.mco.herobrinemod.HerobrineMod;
import com.mco.herobrinemod.client.layer.DeathRaysLayer;
import com.mco.herobrinemod.client.layer.HerobrineEyesLayer;
import com.mco.herobrinemod.client.layer.LightningChargeLayer;
import com.mco.herobrinemod.client.layer.RgbPulseLayer;
import com.mco.herobrinemod.client.model.HerobrineModel;
import com.mco.herobrinemod.client.model.Phase2Model;
import com.mco.herobrinemod.config.HerobrineConfig;
import com.mco.herobrinemod.entities.HardHerobrineEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

/**
 * Phase 2: the giant Herobrine. The model scale follows the stage (6 / 3 / 1.5); the death sequence
 * always plays at full size.
 */
public class HardHerobrineRenderer extends AbstractHerobrineRenderer<HardHerobrineEntity, Phase2Model> {
    /** The original used "herobrine_glow" for this phase (the "hard_glow" skin was never wired up). */
    private static final ResourceLocation GLOW =
            new ResourceLocation(HerobrineMod.MODID, "textures/entity/herobrine_glow.png");

    public HardHerobrineRenderer(EntityRendererProvider.Context context) {
        super(context, new Phase2Model(context.bakeLayer(HerobrineModel.LAYER_LOCATION)), 0.5F);
        this.addLayer(new HerobrineEyesLayer<>(this, GLOW));
        this.addLayer(new RgbPulseLayer(this));
        this.addLayer(new LightningChargeLayer(this));
        this.addLayer(new DeathRaysLayer(this));
    }

    /**
     * Scale of the model. During the long death it shrinks slowly while spinning (the original did this
     * per rendered frame, so the result depended on the frame rate; here it depends on the game ticks).
     */
    private static float modelScale(HardHerobrineEntity entity, float partialTick) {
        int ticks = entity.getDeathTicks();
        if (ticks == 0) {
            return entity.getRenderScale(partialTick);
        }
        float scale = 6.0F;
        if (ticks > 232) {
            float time = Math.min(ticks + partialTick, 350.0F) - 232.0F;
            scale = Math.max(2.5F, 6.0F - 0.015F * time);
        }
        if (HerobrineConfig.enablePhase3() && HardHerobrineEntity.isDeathPulse(ticks)) {
            scale *= 1.1F;
        }
        return scale;
    }

    @Override
    public void render(HardHerobrineEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        this.shadowRadius = 0.5F * modelScale(entity, partialTick);
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }

    @Override
    protected void scale(HardHerobrineEntity entity, PoseStack poseStack, float partialTick) {
        float scale = modelScale(entity, partialTick);
        poseStack.scale(scale, scale, scale);
        int ticks = entity.getDeathTicks();
        if (ticks > 232) {
            float time = (Math.min(ticks + partialTick, 350.0F) - 232.0F) / 6.0F;
            poseStack.mulPose(Axis.YP.rotationDegrees(time * time * time));
        }
    }
}
