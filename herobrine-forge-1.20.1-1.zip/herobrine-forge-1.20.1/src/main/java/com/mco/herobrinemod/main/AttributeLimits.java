package com.mco.herobrinemod.main;

import com.mco.herobrinemod.HerobrineMod;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.RangedAttribute;

public final class AttributeLimits {
    private static final double VANILLA_MAX_HEALTH_LIMIT = 1024.0D;

    private AttributeLimits() {
    }

    /**
     * Raises the upper bound of generic.max_health (vanilla: 1024) so the 1500 health of the
     * second phase is possible. The bound field is found by its value instead of its name, so this
     * works with both the official and the obfuscated (SRG) names.
     */
    public static void raiseMaxHealthLimit() {
        Attribute attribute = Attributes.MAX_HEALTH;
        if (!(attribute instanceof RangedAttribute)) {
            HerobrineMod.LOGGER.warn("generic.max_health is not a RangedAttribute, health limit not raised");
            return;
        }
        boolean changed = false;
        for (Field field : RangedAttribute.class.getDeclaredFields()) {
            if (field.getType() != double.class || Modifier.isStatic(field.getModifiers())) {
                continue;
            }
            try {
                field.setAccessible(true);
                if (field.getDouble(attribute) == VANILLA_MAX_HEALTH_LIMIT) {
                    field.setDouble(attribute, (double) Integer.MAX_VALUE);
                    changed = true;
                }
            } catch (Exception e) {
                HerobrineMod.LOGGER.error("Could not raise the max health limit", e);
            }
        }
        if (!changed) {
            HerobrineMod.LOGGER.warn("Max health limit was not found, bosses will be capped at 1024 health");
        }
    }
}
