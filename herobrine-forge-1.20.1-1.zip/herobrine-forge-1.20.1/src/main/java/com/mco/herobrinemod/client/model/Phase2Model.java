package com.mco.herobrinemod.client.model;

import com.mco.herobrinemod.entities.HardHerobrineEntity;
import net.minecraft.client.model.geom.ModelPart;

public class Phase2Model extends HerobrineModel<HardHerobrineEntity> {
    public Phase2Model(ModelPart root) {
        super(root);
    }

    @Override
    protected void animate(HardHerobrineEntity entity, float partialTick) {
        switch (entity.getAnimation()) {
            case HardHerobrineEntity.ANIM_SHOOT -> play(HerobrineAnimations.P2_SHOOT, entity, partialTick);
            case HardHerobrineEntity.ANIM_FIRE -> play(HerobrineAnimations.P2_FIRE, entity, partialTick);
            case HardHerobrineEntity.ANIM_SWORD -> play(HerobrineAnimations.P2_SWORD, entity, partialTick);
            case HardHerobrineEntity.ANIM_LIGHTNING -> play(HerobrineAnimations.P2_LIGHTNING, entity, partialTick);
            case HardHerobrineEntity.ANIM_DEATH_FULL -> play(HerobrineAnimations.P2_DEATH_FULL, entity, partialTick);
            case HardHerobrineEntity.ANIM_DEATH -> {
                // on the flashing frames the original drew the model in its neutral pose
                if (!HardHerobrineEntity.isDeathPulse(entity.getDeathTicks())) {
                    play(HerobrineAnimations.P2_DEATH, entity, partialTick);
                }
            }
            default -> {
            }
        }
    }
}
