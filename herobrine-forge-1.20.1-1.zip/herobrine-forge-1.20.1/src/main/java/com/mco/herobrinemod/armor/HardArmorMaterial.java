package com.mco.herobrinemod.armor;

import com.mco.herobrinemod.HerobrineMod;
import com.mco.herobrinemod.items.HardTier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/**
 * The four armor materials of the 1.12.2 mod.
 * Defense values are listed in the old order: boots, leggings, chestplate, helmet.
 */
public enum HardArmorMaterial implements ArmorMaterial {
    HARD(HardTier.HARD, 40, new int[]{7, 11, 14, 7}, 18, 8.0F),
    HARDER(HardTier.HARDER, 60, new int[]{12, 16, 19, 12}, 20, 11.0F),
    HALFHARDER(HardTier.HALFHARDER, 70, new int[]{15, 19, 21, 15}, 21, 13.0F),
    HARDEST(HardTier.HARDEST, 80, new int[]{18, 22, 24, 18}, 22, 16.0F);

    /** Vanilla base durability per slot: boots, leggings, chestplate, helmet. */
    private static final int[] BASE_DURABILITY = {13, 15, 16, 11};

    private final HardTier tier;
    private final int durabilityMultiplier;
    private final int[] defense;
    private final int enchantability;
    private final float toughness;

    HardArmorMaterial(HardTier tier, int durabilityMultiplier, int[] defense, int enchantability, float toughness) {
        this.tier = tier;
        this.durabilityMultiplier = durabilityMultiplier;
        this.defense = defense;
        this.enchantability = enchantability;
        this.toughness = toughness;
    }

    public HardTier getTier() {
        return tier;
    }

    private static int index(ArmorItem.Type type) {
        return switch (type) {
            case BOOTS -> 0;
            case LEGGINGS -> 1;
            case CHESTPLATE -> 2;
            case HELMET -> 3;
        };
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return BASE_DURABILITY[index(type)] * durabilityMultiplier;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return defense[index(type)];
    }

    @Override
    public int getEnchantmentValue() {
        return enchantability;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_DIAMOND;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.EMPTY;
    }

    /** Armor texture name: assets/herobrinemod/textures/models/armor/<tier>_layer_1/2.png */
    @Override
    public String getName() {
        return HerobrineMod.MODID + ":" + tier.getId();
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return 0.0F;
    }
}
