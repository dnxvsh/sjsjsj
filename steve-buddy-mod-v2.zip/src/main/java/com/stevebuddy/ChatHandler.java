package com.stevebuddy;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.stevebuddy.entity.BuddyEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BiConsumer;

public class ChatHandler {

    @SubscribeEvent
    public void onChat(ServerChatEvent event) {
        ServerPlayer player = event.getPlayer();
        String msg = event.getRawText();
        if (msg == null || msg.isBlank() || player.getServer() == null) return;

        for (BuddyEntity buddy : findBuddies(player)) {
            if (shouldRespond(buddy, msg)) {
                buddy.brain().onPlayerMessage(msg);
            }
        }
    }

    private static boolean shouldRespond(BuddyEntity buddy, String msg) {
        if (BuddyConfig.RESPOND_TO_ALL_CHAT.get()) return true;
        String m = msg.toLowerCase(Locale.ROOT);
        String name = BuddyConfig.name().toLowerCase(Locale.ROOT);
        return m.contains(name) || m.contains("steve") || m.contains("ستيف");
    }

    public static List<BuddyEntity> findBuddies(ServerPlayer player) {
        List<BuddyEntity> out = new ArrayList<>();
        if (player.getServer() == null) return out;
        for (ServerLevel level : player.getServer().getAllLevels()) {
            out.addAll(level.getEntities(EntityTypeTest.forClass(BuddyEntity.class),
                    b -> b.isAlive() && player.getUUID().equals(b.getOwnerId())));
        }
        return out;
    }

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("steve")
                .then(Commands.literal("come").executes(c -> run(c, (b, p) -> {
                    if (b.level() == p.level()) {
                        b.moveTo(p.getX(), p.getY(), p.getZ());
                        b.getNavigation().stop();
                    } else {
                        p.sendSystemMessage(Component.literal("Steve is in another dimension."));
                    }
                })))
                .then(Commands.literal("stop").executes(c -> run(c, (b, p) -> b.brain().stopAll())))
                .then(Commands.literal("reset").executes(c -> run(c, (b, p) -> b.brain().reset())))
                .then(Commands.literal("status").executes(c -> run(c, (b, p) ->
                        p.sendSystemMessage(Component.literal(b.statusLine()))))));
    }

    private static int run(CommandContext<CommandSourceStack> ctx, BiConsumer<BuddyEntity, ServerPlayer> action)
            throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        List<BuddyEntity> list = findBuddies(p);
        if (list.isEmpty()) {
            ctx.getSource().sendFailure(Component.literal("No Steve found. Spawn one with the Steve Buddy spawn egg."));
            return 0;
        }
        list.forEach(b -> action.accept(b, p));
        return list.size();
    }
}
