package com.stevebuddy.entity;

import com.stevebuddy.BuddyConfig;
import com.stevebuddy.ai.BuddyBrain;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** A second "Steve" that follows the player, chats through an AI, and carries out requests. */
public class BuddyEntity extends PathfinderMob {
    public static final double REACH = 4.8D;
    private static final Set<String> BAD_FOOD = Set.of("rotten_flesh", "spider_eye", "pufferfish",
            "poisonous_potato", "chorus_fruit", "suspicious_stew");

    public enum Mode { FOLLOW, STAY }

    public final SimpleContainer inventory = new SimpleContainer(36);
    public Mode mode = Mode.FOLLOW;

    private UUID ownerId;
    private BuddyBrain brain;
    private int food = 20;
    private int foodTimer, regenTimer, starveTimer, eatCooldown;
    private boolean greeted;
    private boolean ownerCreative;
    private final Set<UUID> ignoredItems = new HashSet<>();

    public BuddyEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            this.setDropChance(slot, 2.0F);
        }
        if (this.getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
            nav.setCanFloat(true);
        }
        if (!level.isClientSide) {
            this.setCustomName(Component.literal(BuddyConfig.name()));
            this.setCustomNameVisible(true);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 1.0D)
                .add(Attributes.ATTACK_KNOCKBACK, 0.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new OpenDoorGoal(this, true));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));
    }

    // ------------------------------------------------------------------ brain / owner

    public BuddyBrain brain() {
        if (brain == null) brain = new BuddyBrain(this);
        return brain;
    }

    @Nullable
    public UUID getOwnerId() {
        return ownerId;
    }

    @Nullable
    public ServerPlayer getOwnerPlayer() {
        MinecraftServer server = level().getServer();
        if (ownerId == null || server == null) return null;
        return server.getPlayerList().getPlayer(ownerId);
    }

    public boolean isGreeted() { return greeted; }
    public void markGreeted() { greeted = true; }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (ownerId == null) {
            Player p = level().getNearestPlayer(this, 24.0D);
            if (p != null) ownerId = p.getUUID();
        }
        tickSurvival();
        tickPickup();
        brain().tick();
    }

    // ------------------------------------------------------------------ survival (hunger / regen)

    private void tickSurvival() {
        ServerPlayer owner = getOwnerPlayer();
        if (owner != null && tickCount % 20 == 0) ownerCreative = owner.isCreative();
        if (ownerCreative) {
            food = 20;
            return;
        }
        if (++foodTimer >= 1400) {
            foodTimer = 0;
            if (food > 0) food--;
        }
        if (food >= 15 && getHealth() < getMaxHealth() && ++regenTimer >= 100) {
            regenTimer = 0;
            heal(1.0F);
        }
        if (food <= 0 && ++starveTimer >= 80) {
            starveTimer = 0;
            if (getHealth() > 1.0F) hurt(damageSources().starve(), 1.0F);
        }
        if (eatCooldown > 0) eatCooldown--;
        if (food <= 12 && eatCooldown == 0) {
            eatCooldown = tryEat() ? 40 : 200;
        }
        if (tickCount % 100 == 0) autoEquipArmor();
    }

    public int getFood() { return food; }

    /** Eats the best available food. Returns true if something was eaten. */
    public boolean tryEat() {
        int best = -1;
        double bestScore = -1;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty() || !s.isEdible()) continue;
            FoodProperties fp = s.getItem().getFoodProperties();
            if (fp == null || BAD_FOOD.contains(idOf(s.getItem()))) continue;
            double score = fp.getNutrition() + fp.getSaturationModifier();
            if (score > bestScore) {
                bestScore = score;
                best = i;
            }
        }
        if (best < 0) return false;
        ItemStack s = inventory.getItem(best);
        FoodProperties fp = s.getItem().getFoodProperties();
        int nutrition = fp == null ? 2 : fp.getNutrition();
        this.swing(InteractionHand.MAIN_HAND);
        this.eat(level(), s);
        food = Math.min(20, food + nutrition);
        if (s.isEmpty()) inventory.setItem(best, ItemStack.EMPTY);
        return true;
    }

    public void autoEquipArmor() {
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty() || !(s.getItem() instanceof ArmorItem armor)) continue;
            EquipmentSlot slot = armor.getEquipmentSlot();
            ItemStack cur = getItemBySlot(slot);
            double newValue = armor.getDefense() + armor.getToughness();
            double curValue = cur.getItem() instanceof ArmorItem ca ? ca.getDefense() + ca.getToughness() : -1;
            if (newValue > curValue) {
                inventory.setItem(i, cur);
                setItemSlot(slot, s);
            }
        }
    }

    // ------------------------------------------------------------------ inventory helpers

    private void tickPickup() {
        if (tickCount % 5 != 0) return;
        List<ItemEntity> items = level().getEntitiesOfClass(ItemEntity.class, getBoundingBox().inflate(1.5D, 0.5D, 1.5D));
        for (ItemEntity ie : items) {
            if (!ie.isAlive() || ie.tickCount < 40 || ignoredItems.contains(ie.getUUID())) continue;
            ItemStack stack = ie.getItem();
            ItemStack left = inventory.addItem(stack.copy());
            int taken = stack.getCount() - left.getCount();
            if (taken > 0) {
                take(ie, taken);
                if (left.isEmpty()) ie.discard();
                else ie.setItem(left);
            }
        }
    }

    public void ignoreItem(UUID id) {
        if (ignoredItems.size() > 300) ignoredItems.clear();
        ignoredItems.add(id);
    }

    public boolean isIgnored(UUID id) {
        return ignoredItems.contains(id);
    }

    public void giveOrDrop(ItemStack stack) {
        if (stack.isEmpty()) return;
        ItemStack left = inventory.addItem(stack);
        if (!left.isEmpty()) {
            ItemEntity ie = spawnAtLocation(left);
            if (ie != null) ignoreItem(ie.getUUID());
        }
    }

    /** Throws an item toward an entity (or just drops it in front when null). */
    public void throwItem(ItemStack stack, @Nullable Entity toward) {
        if (stack.isEmpty()) return;
        ItemEntity ie = new ItemEntity(level(), getX(), getEyeY() - 0.3D, getZ(), stack);
        ie.setPickUpDelay(40);
        if (toward != null) {
            Vec3 d = toward.position().subtract(position());
            Vec3 n = d.lengthSqr() < 1.0E-4D ? Vec3.ZERO : d.normalize().scale(0.3D);
            ie.setDeltaMovement(n.x, 0.2D, n.z);
        }
        ignoreItem(ie.getUUID());
        level().addFreshEntity(ie);
    }

    public int findItemSlot(Item item) {
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (!s.isEmpty() && s.getItem() == item) return i;
        }
        return -1;
    }

    public int countItem(Item item) {
        int n = 0;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (!s.isEmpty() && s.getItem() == item) n += s.getCount();
        }
        return n;
    }

    public int removeItem(Item item, int amount) {
        int left = amount;
        for (int i = 0; i < inventory.getContainerSize() && left > 0; i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty() || s.getItem() != item) continue;
            int t = Math.min(left, s.getCount());
            s.shrink(t);
            left -= t;
            if (s.isEmpty()) inventory.setItem(i, ItemStack.EMPTY);
        }
        return amount - left;
    }

    /** Moves whatever is in the hands back into the inventory. */
    public void stashHands() {
        ItemStack main = getMainHandItem();
        if (!main.isEmpty()) {
            setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            giveOrDrop(main);
        }
    }

    public void swapMainHand(int slot) {
        ItemStack cur = getMainHandItem();
        ItemStack s = inventory.getItem(slot);
        inventory.setItem(slot, cur);
        setItemSlot(EquipmentSlot.MAINHAND, s);
    }

    public void equipBestToolFor(BlockState state) {
        float bestSpeed = getMainHandItem().getDestroySpeed(state);
        int best = -1;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty()) continue;
            float sp = s.getDestroySpeed(state);
            if (sp > bestSpeed) {
                bestSpeed = sp;
                best = i;
            }
        }
        if (best >= 0) swapMainHand(best);
    }

    public void equipBestWeapon() {
        double bestDmg = weaponDamage(getMainHandItem());
        int best = -1;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty()) continue;
            double d = weaponDamage(s);
            if (d > bestDmg) {
                bestDmg = d;
                best = i;
            }
        }
        if (best >= 0) swapMainHand(best);
    }

    private static double weaponDamage(ItemStack s) {
        if (s.isEmpty()) return 0;
        double d = 0;
        for (AttributeModifier m : s.getAttributeModifiers(EquipmentSlot.MAINHAND).get(Attributes.ATTACK_DAMAGE)) {
            d += m.getAmount();
        }
        return d;
    }

    public static String idOf(Item item) {
        ResourceLocation rl = ForgeRegistries.ITEMS.getKey(item);
        return rl == null ? "unknown" : rl.getPath();
    }

    public Map<String, Integer> inventoryCounts() {
        Map<String, Integer> m = new LinkedHashMap<>();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (!s.isEmpty()) m.merge(idOf(s.getItem()), s.getCount(), Integer::sum);
        }
        return m;
    }

    // ------------------------------------------------------------------ chat helpers

    public void say(String text) {
        MinecraftServer server = level().getServer();
        if (server == null || text == null || text.isBlank()) return;
        Component c = Component.literal("<" + BuddyConfig.name() + "> ").withStyle(ChatFormatting.GREEN)
                .append(Component.literal(text).withStyle(ChatFormatting.WHITE));
        server.getPlayerList().broadcastSystemMessage(c, false);
    }

    public void tell(String text, ChatFormatting color) {
        ServerPlayer o = getOwnerPlayer();
        if (o != null) {
            o.sendSystemMessage(Component.literal("[" + BuddyConfig.name() + "] " + text).withStyle(color));
        }
    }

    public String statusLine() {
        StringBuilder sb = new StringBuilder();
        sb.append("HP ").append((int) getHealth()).append('/').append((int) getMaxHealth())
                .append(" | Food ").append(food).append("/20")
                .append(" | Hand: ").append(getMainHandItem().isEmpty() ? "empty" : idOf(getMainHandItem().getItem()))
                .append(" | Doing: ").append(brain().describeActivity())
                .append(" | Items: ");
        Map<String, Integer> inv = inventoryCounts();
        if (inv.isEmpty()) sb.append("none");
        else inv.forEach((k, v) -> sb.append(k).append(" x").append(v).append(", "));
        return sb.toString();
    }

    // ------------------------------------------------------------------ interaction / damage / save

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (ownerId == null) ownerId = player.getUUID();
        if (!player.getUUID().equals(ownerId)) return InteractionResult.PASS;

        ItemStack held = player.getItemInHand(hand);
        if (!held.isEmpty()) {
            ItemStack left = inventory.addItem(held.copy());
            int moved = held.getCount() - left.getCount();
            if (moved > 0) {
                String name = idOf(held.getItem());
                held.shrink(moved);
                tell("Got it: " + name + " x" + moved, ChatFormatting.GRAY);
            } else {
                tell("My pockets are full!", ChatFormatting.GRAY);
            }
        } else {
            tell(statusLine(), ChatFormatting.GRAY);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (ownerCreative && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return true;
        return super.isInvulnerableTo(source);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide) {
            ServerPlayer o = getOwnerPlayer();
            if (o != null) o.sendSystemMessage(getCombatTracker().getDeathMessage());
        }
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (!s.isEmpty()) spawnAtLocation(s);
        }
        inventory.clearContent();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (ownerId != null) tag.putUUID("BuddyOwner", ownerId);
        tag.putInt("BuddyFood", food);
        tag.putBoolean("BuddyGreeted", greeted);
        tag.putString("BuddyMode", mode.name());
        ListTag list = new ListTag();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty()) continue;
            CompoundTag c = new CompoundTag();
            c.putByte("Slot", (byte) i);
            s.save(c);
            list.add(c);
        }
        tag.put("BuddyInventory", list);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("BuddyOwner")) ownerId = tag.getUUID("BuddyOwner");
        food = tag.contains("BuddyFood") ? tag.getInt("BuddyFood") : 20;
        greeted = tag.getBoolean("BuddyGreeted");
        try {
            mode = Mode.valueOf(tag.getString("BuddyMode"));
        } catch (IllegalArgumentException ex) {
            mode = Mode.FOLLOW;
        }
        inventory.clearContent();
        ListTag list = tag.getList("BuddyInventory", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            int slot = c.getByte("Slot") & 255;
            if (slot < inventory.getContainerSize()) inventory.setItem(slot, ItemStack.of(c));
        }
    }
}
