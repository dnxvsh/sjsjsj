package com.stevebuddy.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.stevebuddy.BuddyConfig;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Minimal Gemini REST client (generateContent). Runs on a background thread. */
public final class GeminiClient {

    public record Turn(String role, String text) {}

    public static class ApiException extends RuntimeException {
        public final int code;

        public ApiException(int code, String message) {
            super(message);
            this.code = code;
        }
    }

    private static final ExecutorService POOL = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "SteveBuddy-HTTP");
        t.setDaemon(true);
        return t;
    });

    private static final String KEY_FILE = "stevebuddy-key.txt";

    /**
     * Key lookup order: config/stevebuddy-key.txt (plain file, read fresh on every call, never rewritten by Forge),
     * then the apiKey entry of stevebuddy-common.toml, then the GEMINI_API_KEY environment variable.
     */
    public static String resolveKey() {
        String k = readKeyFile();
        if (k.isEmpty()) k = BuddyConfig.API_KEY.get().trim();
        if (k.isEmpty()) {
            String env = System.getenv("GEMINI_API_KEY");
            if (env != null) k = env.trim();
        }
        return k;
    }

    /** Reads the first non-empty, non-comment line of config/stevebuddy-key.txt. Creates an empty file if missing. */
    private static String readKeyFile() {
        try {
            Path file = FMLPaths.CONFIGDIR.get().resolve(KEY_FILE);
            if (!Files.exists(file)) {
                Files.writeString(file, "", StandardCharsets.UTF_8);
                return "";
            }
            for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                String t = line.replace("\uFEFF", "").trim();
                if (t.isEmpty() || t.startsWith("#")) continue;
                int eq = t.indexOf('=');
                if (eq >= 0) t = t.substring(eq + 1);
                return t.replaceAll("^[\"'\\s]+|[\"'\\s]+$", "");
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    /** Must be called from the server thread (reads config). */
    public static CompletableFuture<String> generate(String system, List<Turn> turns) {
        final String key = resolveKey();
        String m = BuddyConfig.MODEL.get().trim();
        if (m.startsWith("models/")) m = m.substring(7);
        final String model = m;
        final String endpoint = BuddyConfig.ENDPOINT.get().trim();
        if (key.isEmpty()) {
            return CompletableFuture.failedFuture(new ApiException(-2,
                    "No API key set. Open config/stevebuddy-key.txt, paste only your key, save the file, then write to me again (no restart needed)."));
        }
        final String body = buildBody(system, turns);
        return CompletableFuture.supplyAsync(() -> {
            try {
                return post(key, model, endpoint, body);
            } catch (IOException ex) {
                throw new ApiException(-1, "Network error: " + ex.getMessage());
            }
        }, POOL);
    }

    private static String buildBody(String system, List<Turn> turns) {
        JsonObject root = new JsonObject();

        JsonObject sys = new JsonObject();
        sys.add("parts", partsOf(system));
        root.add("systemInstruction", sys);

        // Gemini wants alternating roles: merge consecutive turns with the same role.
        List<Turn> merged = new ArrayList<>();
        for (Turn t : turns) {
            if (!merged.isEmpty() && merged.get(merged.size() - 1).role().equals(t.role())) {
                Turn last = merged.remove(merged.size() - 1);
                merged.add(new Turn(last.role(), last.text() + "\n" + t.text()));
            } else {
                merged.add(t);
            }
        }
        JsonArray contents = new JsonArray();
        for (Turn t : merged) {
            JsonObject c = new JsonObject();
            c.addProperty("role", t.role());
            c.add("parts", partsOf(t.text()));
            contents.add(c);
        }
        root.add("contents", contents);

        JsonObject gen = new JsonObject();
        gen.addProperty("responseMimeType", "application/json");
        gen.addProperty("maxOutputTokens", 8192);
        root.add("generationConfig", gen);
        return root.toString();
    }

    private static JsonArray partsOf(String text) {
        JsonArray parts = new JsonArray();
        JsonObject p = new JsonObject();
        p.addProperty("text", text);
        parts.add(p);
        return parts;
    }

    private static String post(String key, String model, String endpoint, String body) throws IOException {
        String base = endpoint.isEmpty() ? "https://generativelanguage.googleapis.com/v1beta/models/" : endpoint;
        if (!base.endsWith("/")) base += "/";
        URL url = new URL(base + model + ":generateContent");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(120000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("x-goog-api-key", key);
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }
            int code = c.getResponseCode();
            InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
            String resp = is == null ? "" : new String(is.readAllBytes(), StandardCharsets.UTF_8);
            if (code < 200 || code >= 300) {
                throw new ApiException(code, extractError(resp, code));
            }
            return extractText(resp);
        } finally {
            c.disconnect();
        }
    }

    private static String extractError(String resp, int code) {
        try {
            JsonObject o = JsonParser.parseString(resp).getAsJsonObject();
            if (o.has("error")) {
                JsonObject err = o.getAsJsonObject("error");
                String msg = err.has("message") ? err.get("message").getAsString() : resp;
                return "HTTP " + code + ": " + shorten(msg, 300);
            }
        } catch (Exception ignored) {
        }
        return "HTTP " + code + ": " + shorten(resp, 300);
    }

    private static String extractText(String resp) {
        JsonObject o = JsonParser.parseString(resp).getAsJsonObject();
        JsonArray cands = o.has("candidates") && o.get("candidates").isJsonArray() ? o.getAsJsonArray("candidates") : null;
        if (cands == null || cands.size() == 0) {
            String why = o.has("promptFeedback") ? o.get("promptFeedback").toString() : "no candidates";
            throw new ApiException(-3, "Empty reply (" + shorten(why, 200) + ")");
        }
        JsonObject cand = cands.get(0).getAsJsonObject();
        StringBuilder sb = new StringBuilder();
        if (cand.has("content") && cand.getAsJsonObject("content").has("parts")) {
            for (JsonElement el : cand.getAsJsonObject("content").getAsJsonArray("parts")) {
                JsonObject p = el.getAsJsonObject();
                if (p.has("thought") && p.get("thought").getAsBoolean()) continue;
                if (p.has("text")) sb.append(p.get("text").getAsString());
            }
        }
        if (sb.length() == 0) {
            String reason = cand.has("finishReason") ? cand.get("finishReason").getAsString() : "unknown";
            throw new ApiException(-3, "Empty reply (finishReason=" + reason + ")");
        }
        return sb.toString();
    }

    public static String shorten(String s, int max) {
        if (s == null) return "";
        s = s.replace('\n', ' ').trim();
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    private GeminiClient() {}
}
