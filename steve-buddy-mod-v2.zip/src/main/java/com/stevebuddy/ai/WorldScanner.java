package com.stevebuddy.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.stevebuddy.BuddyConfig;
import com.stevebuddy.action.Actions;
import com.stevebuddy.entity.BuddyEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Builds the "eyes" of Steve: a compact JSON snapshot of his surroundings. */
public final class WorldScanner {

    private static final Set<String> BULK = Set.of("stone", "deepslate", "dirt", "grass_block", "netherrack",
            "andesite", "diorite", "granite", "tuff", "bedrock", "sand", "gravel", "end_stone", "sandstone",
            "short_grass", "tall_grass", "grass", "fern", "water", "cobblestone", "calcite", "dripstone_block");

    private static final class Entry {
        int count;
        BlockPos nearest;
        double dist = Double.MAX_VALUE;
    }

    public static JsonObject observe(BuddyEntity e, BuddyBrain brain) {
        Level level = e.level();
        JsonObject root = new JsonObject();
        BlockPos feet = e.blockPosition();
        ServerPlayer owner = e.getOwnerPlayer();

        // --- self
        JsonObject self = new JsonObject();
        self.add("pos", pos(feet));
        self.addProperty("health", Math.round(e.getHealth()));
        self.addProperty("max_health", Math.round(e.getMaxHealth()));
        self.addProperty("food", e.getFood());
        self.addProperty("armor_points", e.getArmorValue());
        self.addProperty("holding", name(e.getMainHandItem()));
        JsonObject worn = new JsonObject();
        worn.addProperty("head", name(e.getItemBySlot(EquipmentSlot.HEAD)));
        worn.addProperty("chest", name(e.getItemBySlot(EquipmentSlot.CHEST)));
        worn.addProperty("legs", name(e.getItemBySlot(EquipmentSlot.LEGS)));
        worn.addProperty("feet", name(e.getItemBySlot(EquipmentSlot.FEET)));
        self.add("wearing", worn);
        self.addProperty("in_water", e.isInWater());
        self.addProperty("standing_on", Actions.blockName(level.getBlockState(feet.below())));
        self.addProperty("current_activity", brain.describeActivity());
        self.addProperty("mode_when_idle", e.mode.name().toLowerCase());
        root.add("self", self);

        // --- inventory
        JsonObject inv = new JsonObject();
        e.inventoryCounts().forEach(inv::addProperty);
        root.add("inventory", inv);

        // --- player
        if (owner != null) {
            JsonObject p = new JsonObject();
            p.addProperty("name", owner.getGameProfile().getName());
            p.add("pos", pos(owner.blockPosition()));
            p.addProperty("same_dimension", owner.level() == level);
            if (owner.level() == level) p.addProperty("distance", Math.round(e.distanceTo(owner)));
            p.addProperty("health", Math.round(owner.getHealth()));
            p.addProperty("food", owner.getFoodData().getFoodLevel());
            p.addProperty("holding", name(owner.getMainHandItem()));
            p.addProperty("game_mode", owner.isCreative() ? "creative" : "survival");
            root.add("player", p);
        }

        // --- world
        JsonObject w = new JsonObject();
        w.addProperty("dimension", level.dimension().location().toString());
        long t = level.getDayTime() % 24000L;
        w.addProperty("time_ticks", t);
        w.addProperty("time_of_day", t < 12000 ? "day" : (t < 13000 ? "sunset" : (t < 23000 ? "night" : "sunrise")));
        w.addProperty("raining", level.isRaining());
        w.addProperty("thundering", level.isThundering());
        w.addProperty("light_level", level.getMaxLocalRawBrightness(feet));
        w.addProperty("biome", level.getBiome(feet).unwrapKey().map(k -> k.location().getPath()).orElse("unknown"));
        w.addProperty("difficulty", level.getDifficulty().getKey());
        root.add("world", w);

        // --- entities
        List<LivingEntity> near = level.getEntitiesOfClass(LivingEntity.class, e.getBoundingBox().inflate(20.0D),
                x -> x != e && x.isAlive());
        near.sort(Comparator.comparingDouble(x -> e.distanceToSqr(x)));
        JsonArray ents = new JsonArray();
        for (int i = 0; i < Math.min(15, near.size()); i++) {
            LivingEntity x = near.get(i);
            JsonObject o = new JsonObject();
            ResourceLocation rl = ForgeRegistries.ENTITY_TYPES.getKey(x.getType());
            o.addProperty("type", rl == null ? "?" : rl.getPath());
            if (x instanceof Player pl) o.addProperty("name", pl.getGameProfile().getName());
            o.add("pos", pos(x.blockPosition()));
            o.addProperty("distance", Math.round(e.distanceTo(x)));
            o.addProperty("health", Math.round(x.getHealth()));
            if (Actions.isHostile(x)) o.addProperty("hostile", true);
            ents.add(o);
        }
        root.add("nearby_entities", ents);

        // --- blocks
        root.add("nearby_blocks", scanBlocks(e));
        return root;
    }

    private static JsonObject scanBlocks(BuddyEntity e) {
        Level level = e.level();
        BlockPos c = e.blockPosition();
        int r = BuddyConfig.SCAN_RADIUS.get();
        int vy = Math.min(r, 12);
        Map<Block, Entry> map = new HashMap<>();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                for (int dy = -vy; dy <= vy; dy++) {
                    m.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (!level.isLoaded(m)) continue;
                    BlockState s = level.getBlockState(m);
                    if (s.isAir()) continue;
                    Entry en = map.computeIfAbsent(s.getBlock(), k -> new Entry());
                    en.count++;
                    double d = dx * dx + dy * dy + dz * dz;
                    if (d < en.dist) {
                        en.dist = d;
                        en.nearest = m.immutable();
                    }
                }
            }
        }
        List<Map.Entry<Block, Entry>> list = new ArrayList<>(map.entrySet());
        list.sort(Comparator.<Map.Entry<Block, Entry>>comparingInt(en -> -priority(path(en.getKey())))
                .thenComparingDouble(en -> en.getValue().dist));
        JsonObject out = new JsonObject();
        for (int i = 0; i < Math.min(30, list.size()); i++) {
            Map.Entry<Block, Entry> en = list.get(i);
            JsonObject o = new JsonObject();
            o.addProperty("count", en.getValue().count);
            o.add("nearest", pos(en.getValue().nearest));
            o.addProperty("distance", Math.round(Math.sqrt(en.getValue().dist)));
            out.add(path(en.getKey()), o);
        }
        return out;
    }

    private static int priority(String p) {
        if (p.endsWith("_ore") || p.equals("ancient_debris")) return 100;
        if (p.endsWith("_log") || p.endsWith("_wood")) return 90;
        if (p.equals("lava")) return 85;
        if (p.equals("crafting_table") || p.equals("furnace") || p.equals("blast_furnace") || p.equals("chest")
                || p.equals("barrel") || p.endsWith("_bed") || p.equals("obsidian") || p.equals("nether_portal")
                || p.equals("spawner") || p.equals("anvil") || p.equals("enchanting_table")) return 70;
        if (BULK.contains(p)) return 10;
        if (p.endsWith("_leaves")) return 20;
        return 50;
    }

    private static String path(Block b) {
        ResourceLocation rl = ForgeRegistries.BLOCKS.getKey(b);
        return rl == null ? "unknown" : rl.getPath();
    }

    private static String name(ItemStack s) {
        return s.isEmpty() ? "none" : BuddyEntity.idOf(s.getItem());
    }

    private static JsonArray pos(BlockPos p) {
        JsonArray a = new JsonArray();
        a.add(p.getX());
        a.add(p.getY());
        a.add(p.getZ());
        return a;
    }

    private WorldScanner() {}
}
