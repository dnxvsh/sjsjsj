package com.stevebuddy.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.stevebuddy.BuddyConfig;
import com.stevebuddy.SteveBuddyMod;
import com.stevebuddy.action.ActionParser;
import com.stevebuddy.action.Actions;
import com.stevebuddy.action.BuddyAction;
import com.stevebuddy.entity.BuddyEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletionException;

/**
 * The "mind" of Steve. Talks to Gemini, turns the answer into actions, runs them one by one,
 * and calls the AI again with the results when it wants to keep working (agent loop).
 */
public class BuddyBrain {
    private static final Set<String> STOP_WORDS = Set.of("stop", "halt", "wait", "قف", "وقف", "توقف", "استنى", "استنا");

    private final BuddyEntity buddy;
    private final Deque<BuddyAction> queue = new ArrayDeque<>();
    private BuddyAction current;
    private BuddyAction combat;
    private LivingEntity combatTarget;

    private final List<GeminiClient.Turn> history = new ArrayList<>();
    private final List<String> results = new ArrayList<>();
    private final List<String> pendingMessages = new ArrayList<>();
    private List<String> inFlightMessages = new ArrayList<>();
    private List<String> inFlightResults = new ArrayList<>();
    private final Map<UUID, Integer> ignoredTargets = new HashMap<>();

    private boolean waiting;
    private boolean wantsContinue;
    private boolean callRequested;
    private String callReason = "player_said";
    private int autoSteps;
    private int retries;
    private int nextCallTick;
    private int generation;

    public BuddyBrain(BuddyEntity buddy) {
        this.buddy = buddy;
    }

    // ------------------------------------------------------------------ public API

    public void onPlayerMessage(String text) {
        String t = text.trim();
        if (t.isEmpty()) return;
        if (STOP_WORDS.contains(t.toLowerCase(Locale.ROOT))) stopAll();
        pendingMessages.add(t);
        autoSteps = 0;
        retries = 0;
        callReason = "player_said";
        callRequested = true;
    }

    public void stopAll() {
        abortCurrent();
        queue.clear();
        wantsContinue = false;
        buddy.getNavigation().stop();
    }

    public void reset() {
        stopAll();
        history.clear();
        results.clear();
        pendingMessages.clear();
        generation++;
        waiting = false;
        callRequested = false;
        buddy.tell("Memory cleared.", ChatFormatting.GRAY);
    }

    public String describeActivity() {
        if (combat != null) return "fighting (" + combat.describe() + ")";
        if (current != null) {
            return current.describe() + (queue.isEmpty() ? "" : " (+" + queue.size() + " more actions queued)");
        }
        return buddy.mode == BuddyEntity.Mode.FOLLOW ? "idle, following the player" : "idle, standing still";
    }

    // ------------------------------------------------------------------ tick

    public void tick() {
        ServerPlayer owner = buddy.getOwnerPlayer();

        if (!buddy.isGreeted() && owner != null) {
            buddy.markGreeted();
            callReason = "just_spawned";
            callRequested = true;
        }

        // instinct: fight nearby monsters
        if (combat != null) {
            BuddyAction.Status s = combat.tick(buddy);
            if (s != BuddyAction.Status.RUNNING) {
                if (s == BuddyAction.Status.FAILED && combatTarget != null) {
                    ignoredTargets.put(combatTarget.getUUID(), buddy.tickCount + 600);
                }
                combat.stop(buddy);
                combat = null;
                combatTarget = null;
            }
        } else {
            checkThreat();
        }

        // run planned actions
        if (combat == null) {
            if (current != null) {
                BuddyAction.Status s = current.tick(buddy);
                if (s != BuddyAction.Status.RUNNING) finishCurrent(s);
            } else if (!queue.isEmpty()) {
                current = queue.poll();
                current.start(buddy);
            } else {
                idle(owner);
            }
        }

        // agent loop: plan finished and AI wants to continue
        if (current == null && queue.isEmpty() && combat == null && !waiting && !callRequested && wantsContinue) {
            if (autoSteps < BuddyConfig.MAX_AUTO_STEPS.get()) {
                autoSteps++;
                callReason = "plan_finished";
                callRequested = true;
            } else {
                wantsContinue = false;
                buddy.tell("I did a lot of steps on my own - tell me if I should continue.", ChatFormatting.GRAY);
            }
        }

        if (callRequested && !waiting && buddy.tickCount >= nextCallTick) {
            doCall();
        }
    }

    private void idle(@Nullable ServerPlayer owner) {
        if (buddy.mode == BuddyEntity.Mode.STAY) return;
        if (owner == null || owner.level() != buddy.level()) return;
        double d = buddy.distanceTo(owner);
        if (d > 40.0D && BuddyConfig.TELEPORT_IF_FAR.get()) {
            buddy.moveTo(owner.getX(), owner.getY(), owner.getZ());
            buddy.getNavigation().stop();
            return;
        }
        if (buddy.tickCount % 10 == 0) {
            if (d > 6.0D) buddy.getNavigation().moveTo(owner, d > 14.0D ? 1.3D : 1.1D);
            else if (d < 3.0D) buddy.getNavigation().stop();
        }
    }

    private void checkThreat() {
        if (!BuddyConfig.AUTO_DEFEND.get() || buddy.tickCount % 10 != 0) return;
        if (current instanceof Actions.Attack) return;
        AABB box = buddy.getBoundingBox().inflate(10.0D, 5.0D, 10.0D);
        List<Mob> list = buddy.level().getEntitiesOfClass(Mob.class, box, m -> m.isAlive() && Actions.isHostile(m)
                && ignoredTargets.getOrDefault(m.getUUID(), 0) < buddy.tickCount);
        Mob best = null;
        double bestD = Double.MAX_VALUE;
        for (Mob m : list) {
            double d = buddy.distanceToSqr(m);
            if (d < bestD) {
                bestD = d;
                best = m;
            }
        }
        if (best != null) {
            final LivingEntity target = best;
            combatTarget = target;
            combat = new Actions.Attack("nearby threat", x -> x == target, 1, 16);
            combat.start(buddy);
        }
        if (ignoredTargets.size() > 200) ignoredTargets.clear();
    }

    private void abortCurrent() {
        if (current != null) {
            current.stop(buddy);
            current = null;
        }
    }

    private void finishCurrent(BuddyAction.Status s) {
        BuddyAction a = current;
        current = null;
        a.stop(buddy);
        if (!a.silent()) {
            String msg = a.message();
            results.add(a.describe() + " -> " + (s == BuddyAction.Status.SUCCESS ? "OK" : "FAILED")
                    + (msg.isEmpty() ? "" : ": " + msg));
            if (results.size() > 25) results.remove(0);
        }
        if (s == BuddyAction.Status.SUCCESS && a instanceof Actions.Attack) {
            queue.addFirst(new Actions.Pickup(8));
        }
        if (s == BuddyAction.Status.FAILED) {
            queue.clear();
            wantsContinue = false;
            if (autoSteps < BuddyConfig.MAX_AUTO_STEPS.get()) {
                autoSteps++;
                callReason = "action_failed";
                callRequested = true;
            }
        }
    }

    // ------------------------------------------------------------------ AI calls

    private void doCall() {
        callRequested = false;
        waiting = true;
        nextCallTick = buddy.tickCount + BuddyConfig.MIN_SECONDS_BETWEEN_CALLS.get() * 20;

        final String reason = callReason;
        inFlightMessages = new ArrayList<>(pendingMessages);
        pendingMessages.clear();
        inFlightResults = new ArrayList<>(results);
        results.clear();

        JsonObject user = new JsonObject();
        user.addProperty("event", reason);
        if (!inFlightMessages.isEmpty()) {
            JsonArray a = new JsonArray();
            inFlightMessages.forEach(a::add);
            user.add("player_messages", a);
        }
        if (!inFlightResults.isEmpty()) {
            JsonArray a = new JsonArray();
            inFlightResults.forEach(a::add);
            user.add("action_results", a);
        }
        user.add("observation", WorldScanner.observe(buddy, this));

        List<GeminiClient.Turn> turns = new ArrayList<>(history);
        turns.add(new GeminiClient.Turn("user", "Current state:\n" + user));

        final String compact = compactLine(reason, inFlightMessages, inFlightResults);
        final int gen = generation;
        final MinecraftServer server = buddy.level().getServer();
        if (server == null) {
            waiting = false;
            return;
        }
        GeminiClient.generate(Prompts.system(), turns)
                .whenComplete((text, err) -> server.execute(() -> onResult(gen, reason, compact, text, err)));
    }

    private static String compactLine(String reason, List<String> msgs, List<String> res) {
        if (!msgs.isEmpty()) return GeminiClient.shorten("PLAYER SAID: " + String.join(" | ", msgs), 600);
        String r = res.isEmpty() ? "" : " | results: " + String.join("; ", res);
        return GeminiClient.shorten("SYSTEM EVENT: " + reason + r, 700);
    }

    private void onResult(int gen, String reason, String compact, String text, Throwable err) {
        if (gen != generation || buddy.isRemoved()) return;
        waiting = false;
        if (err != null) {
            handleError(reason, err);
            return;
        }
        retries = 0;
        history.add(new GeminiClient.Turn("user", compact));
        history.add(new GeminiClient.Turn("model", GeminiClient.shorten(text, 1500)));
        int max = BuddyConfig.HISTORY_TURNS.get() * 2;
        while (history.size() > max) history.remove(0);
        while (!history.isEmpty() && history.get(0).role().equals("model")) history.remove(0);

        applyReply(text);

        if (!pendingMessages.isEmpty()) {
            callReason = "player_said";
            callRequested = true;
        }
    }

    private void handleError(String reason, Throwable err) {
        Throwable t = err;
        while (t instanceof CompletionException && t.getCause() != null) t = t.getCause();
        int code = t instanceof GeminiClient.ApiException a ? a.code : -1;
        boolean retriable = code == 429 || code == 500 || code == 502 || code == 503 || code == 504 || code == -1;
        if (retriable && retries < 2) {
            retries++;
            pendingMessages.addAll(0, inFlightMessages);
            results.addAll(0, inFlightResults);
            callReason = reason;
            callRequested = true;
            nextCallTick = buddy.tickCount + 160;
            buddy.tell("AI is busy (" + (code == -1 ? "network" : code) + "), retrying...", ChatFormatting.GRAY);
            return;
        }
        String msg = t.getMessage() == null ? t.toString() : t.getMessage();
        buddy.tell("[!] AI error: " + GeminiClient.shorten(msg, 260), ChatFormatting.RED);
        SteveBuddyMod.LOGGER.warn("Steve Buddy AI error: {}", msg);
        wantsContinue = false;
    }

    private void applyReply(String raw) {
        JsonObject o;
        try {
            String t = raw.trim();
            int a = t.indexOf('{');
            int b = t.lastIndexOf('}');
            if (a < 0 || b <= a) throw new IllegalArgumentException("not json");
            o = JsonParser.parseString(t.substring(a, b + 1)).getAsJsonObject();
        } catch (Exception ex) {
            buddy.say(GeminiClient.shorten(raw, 200));
            wantsContinue = false;
            return;
        }

        String say = str(o, "say");
        if (!say.isBlank()) buddy.say(say);

        List<BuddyAction> parsed = new ArrayList<>();
        JsonElement ae = o.get("actions");
        if (ae != null && ae.isJsonArray()) {
            for (JsonElement el : ae.getAsJsonArray()) {
                try {
                    parsed.add(ActionParser.parse(el.getAsJsonObject()));
                } catch (Exception ex) {
                    results.add("invalid action " + GeminiClient.shorten(el.toString(), 120) + " -> " + ex.getMessage());
                }
            }
        }
        boolean cont = o.has("continue") && o.get("continue").isJsonPrimitive() && o.get("continue").getAsBoolean();
        boolean busy = current != null || !queue.isEmpty();

        if (!parsed.isEmpty()) {
            abortCurrent();
            queue.clear();
            queue.addAll(parsed);
            wantsContinue = cont;
        } else if (!busy) {
            // nothing to do: continue only if the AI asked to think again, or if its actions were invalid
            wantsContinue = cont || !results.isEmpty() && ae != null && ae.isJsonArray() && ae.getAsJsonArray().size() > 0;
        }
    }

    private static String str(JsonObject o, String key) {
        JsonElement e = o.get(key);
        return e != null && e.isJsonPrimitive() ? e.getAsString() : "";
    }
}
