package com.stevebuddy.action;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.stevebuddy.entity.BuddyEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Locale;
import java.util.function.Predicate;

/** Turns one JSON action object from the AI into a real {@link BuddyAction}. Throws on invalid input. */
public final class ActionParser {
    private ActionParser() {}

    public static BuddyAction parse(JsonObject o) {
        String type = str(o, "type", "").toLowerCase(Locale.ROOT).trim();
        switch (type) {
            case "say":
                return new Actions.Say(str(o, "text", ""));
            case "follow":
            case "follow_player":
                return new Actions.SetMode(BuddyEntity.Mode.FOLLOW);
            case "stay":
            case "stop":
                return new Actions.SetMode(BuddyEntity.Mode.STAY);
            case "goto":
                return new Actions.Goto(pos(o, "x", "y", "z"));
            case "goto_player":
            case "come":
                return new Actions.GotoPlayer();
            case "wait":
                return new Actions.Wait((int) (Mth.clamp(num(o, "seconds", 1), 0, 120) * 20));
            case "collect": {
                String block = str(o, "block", str(o, "item", ""));
                if (block.isEmpty()) throw new IllegalArgumentException("collect needs a \"block\"");
                int count = Mth.clamp((int) num(o, "count", 1), 1, 512);
                int radius = Mth.clamp((int) num(o, "radius", 20), 4, 32);
                return new Actions.Collect(block, blockMatcher(block), count, radius);
            }
            case "mine":
                return new Actions.Mine(pos(o, "x", "y", "z"));
            case "place":
                return new Actions.Place(item(str(o, "item", str(o, "block", ""))), pos(o, "x", "y", "z"));
            case "fill": {
                Item it = item(str(o, "item", str(o, "block", "")));
                BlockPos a = pos(o, "x1", "y1", "z1");
                BlockPos b = pos(o, "x2", "y2", "z2");
                boolean hollow = o.has("hollow") && o.get("hollow").isJsonPrimitive() && o.get("hollow").getAsBoolean();
                return new Actions.Fill(it, a, b, hollow);
            }
            case "attack": {
                String target = str(o, "target", "hostile");
                int count = Mth.clamp((int) num(o, "count", 1), 1, 50);
                int radius = Mth.clamp((int) num(o, "radius", 24), 4, 48);
                return new Actions.Attack(target, entityMatcher(target), count, radius);
            }
            case "craft":
                return new Actions.Craft(item(str(o, "item", "")), Mth.clamp((int) num(o, "count", 1), 1, 576));
            case "smelt":
                return new Actions.Smelt(item(str(o, "item", "")), Mth.clamp((int) num(o, "count", 1), 1, 64));
            case "equip":
                return new Actions.Equip(item(str(o, "item", "")));
            case "eat":
                return new Actions.Eat();
            case "give": {
                String sel = str(o, "item", "all");
                return new Actions.Give(sel, itemMatcher(sel), (int) num(o, "count", 0));
            }
            case "drop": {
                String sel = str(o, "item", "");
                if (sel.isEmpty()) throw new IllegalArgumentException("drop needs an \"item\"");
                return new Actions.Drop(sel, itemMatcher(sel), (int) num(o, "count", 0));
            }
            case "pickup":
                return new Actions.Pickup(Mth.clamp(num(o, "radius", 8), 2, 24));
            default:
                throw new IllegalArgumentException("unknown action type '" + type + "'");
        }
    }

    // ------------------------------------------------------------------ resolvers

    private static ResourceLocation id(String raw) {
        String s = raw.toLowerCase(Locale.ROOT).trim().replace(' ', '_');
        if (s.isEmpty()) throw new IllegalArgumentException("missing id");
        if (!s.contains(":")) s = "minecraft:" + s;
        ResourceLocation rl = ResourceLocation.tryParse(s);
        if (rl == null) throw new IllegalArgumentException("bad id '" + raw + "'");
        return rl;
    }

    static Item item(String raw) {
        ResourceLocation rl = id(raw);
        if (!ForgeRegistries.ITEMS.containsKey(rl)) throw new IllegalArgumentException("unknown item '" + raw + "'");
        return ForgeRegistries.ITEMS.getValue(rl);
    }

    static Predicate<BlockState> blockMatcher(String raw) {
        String s = raw.trim();
        if (s.startsWith("#")) {
            TagKey<Block> tag = TagKey.create(Registries.BLOCK, id(s.substring(1)));
            return st -> st.is(tag);
        }
        ResourceLocation rl = id(s);
        if (!ForgeRegistries.BLOCKS.containsKey(rl)) {
            throw new IllegalArgumentException("unknown block '" + raw + "' (use block ids like coal_ore, oak_log, stone)");
        }
        Block b = ForgeRegistries.BLOCKS.getValue(rl);
        Block variant = null;
        if (rl.getPath().endsWith("_ore") && !rl.getPath().startsWith("deepslate_")) {
            ResourceLocation dv = new ResourceLocation(rl.getNamespace(), "deepslate_" + rl.getPath());
            if (ForgeRegistries.BLOCKS.containsKey(dv)) variant = ForgeRegistries.BLOCKS.getValue(dv);
        }
        final Block deep = variant;
        return st -> st.is(b) || (deep != null && st.is(deep));
    }

    static Predicate<ItemStack> itemMatcher(String raw) {
        String s = raw.trim();
        if (s.equalsIgnoreCase("all") || s.equals("*")) return st -> true;
        if (s.startsWith("#")) {
            TagKey<Item> tag = TagKey.create(Registries.ITEM, id(s.substring(1)));
            return st -> st.is(tag);
        }
        Item it = item(s);
        return st -> st.getItem() == it;
    }

    static Predicate<LivingEntity> entityMatcher(String raw) {
        String s = raw.toLowerCase(Locale.ROOT).trim();
        if (s.equals("hostile") || s.equals("monster") || s.equals("monsters") || s.equals("enemy")) {
            return Actions::isHostile;
        }
        ResourceLocation rl = id(s);
        if (!ForgeRegistries.ENTITY_TYPES.containsKey(rl)) {
            throw new IllegalArgumentException("unknown entity '" + raw + "'");
        }
        return x -> rl.equals(ForgeRegistries.ENTITY_TYPES.getKey(x.getType()));
    }

    // ------------------------------------------------------------------ json helpers

    private static String str(JsonObject o, String key, String def) {
        JsonElement e = o.get(key);
        return e != null && e.isJsonPrimitive() ? e.getAsString() : def;
    }

    private static double num(JsonObject o, String key, double def) {
        JsonElement e = o.get(key);
        if (e == null || !e.isJsonPrimitive()) return def;
        try {
            if (e.getAsJsonPrimitive().isNumber()) return e.getAsDouble();
            return Double.parseDouble(e.getAsString().trim());
        } catch (NumberFormatException ex) {
            return def;
        }
    }

    private static BlockPos pos(JsonObject o, String kx, String ky, String kz) {
        if (o.has(kx) && o.has(ky) && o.has(kz)) {
            return new BlockPos(Mth.floor(num(o, kx, 0)), Mth.floor(num(o, ky, 0)), Mth.floor(num(o, kz, 0)));
        }
        JsonElement p = o.get("pos");
        if (p != null && p.isJsonArray() && kx.equals("x")) {
            JsonArray a = p.getAsJsonArray();
            if (a.size() >= 3) return new BlockPos(a.get(0).getAsInt(), a.get(1).getAsInt(), a.get(2).getAsInt());
        }
        throw new IllegalArgumentException("missing coordinates (" + kx + "," + ky + "," + kz + ")");
    }
}
