package com.stevebuddy.action;

import com.stevebuddy.BuddyConfig;
import com.stevebuddy.entity.BuddyEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.util.LandRandomPos;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.ZombifiedPiglin;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.DirectionalPlaceContext;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/** All concrete actions Steve can perform (his "hands"). */
public final class Actions {
    private Actions() {}

    // ================================================================== helpers

    public static String blockName(BlockState s) {
        ResourceLocation rl = ForgeRegistries.BLOCKS.getKey(s.getBlock());
        return rl == null ? "unknown" : rl.getPath();
    }

    static String itemName(Item i) {
        return BuddyEntity.idOf(i);
    }

    static String posStr(BlockPos p) {
        return p.getX() + "," + p.getY() + "," + p.getZ();
    }

    public static boolean isHostile(LivingEntity x) {
        return x instanceof Enemy && !(x instanceof EnderMan) && !(x instanceof Warden) && !(x instanceof ZombifiedPiglin);
    }

    static boolean inReach(BuddyEntity e, BlockPos p) {
        return e.getEyePosition().distanceToSqr(Vec3.atCenterOf(p)) <= BuddyEntity.REACH * BuddyEntity.REACH;
    }

    /** Closest free (non-solid) neighbour of a block, where Steve could stand to work on it. */
    static BlockPos standSpot(BuddyEntity e, BlockPos target) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (Direction d : Direction.values()) {
            BlockPos p = target.relative(d);
            BlockState s = e.level().getBlockState(p);
            if (!s.blocksMotion() && s.getFluidState().isEmpty()) {
                double dd = e.distanceToSqr(p.getX() + 0.5D, p.getY(), p.getZ() + 0.5D);
                if (dd < bestD) {
                    bestD = dd;
                    best = p;
                }
            }
        }
        return best;
    }

    static boolean exposed(Level level, BlockPos p) {
        for (Direction d : Direction.values()) {
            if (!level.getBlockState(p.relative(d)).blocksMotion()) return true;
        }
        return false;
    }

    static void nudge(BuddyEntity e) {
        Vec3 v = LandRandomPos.getPos(e, 4, 2);
        if (v != null) e.getNavigation().moveTo(v.x, v.y, v.z, 1.0D);
    }

    static BlockPos findNear(BuddyEntity e, Block block, int r) {
        BlockPos c = e.blockPosition();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -Math.min(r, 8); dy <= Math.min(r, 8); dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    double d = dx * dx + dy * dy + dz * dz;
                    if (d >= bestD) continue;
                    m.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (e.level().getBlockState(m).is(block)) {
                        bestD = d;
                        best = m.immutable();
                    }
                }
            }
        }
        return best;
    }

    // ================================================================== simple actions

    public static class SetMode extends BuddyAction {
        private final BuddyEntity.Mode mode;

        public SetMode(BuddyEntity.Mode mode) {
            this.mode = mode;
        }

        @Override public boolean silent() { return true; }

        @Override
        public Status tick(BuddyEntity e) {
            e.mode = mode;
            if (mode == BuddyEntity.Mode.STAY) e.getNavigation().stop();
            return ok("");
        }

        @Override public String describe() { return mode == BuddyEntity.Mode.FOLLOW ? "follow" : "stay"; }
    }

    public static class Say extends BuddyAction {
        private final String text;

        public Say(String text) {
            this.text = text;
        }

        @Override public boolean silent() { return true; }

        @Override
        public Status tick(BuddyEntity e) {
            e.say(text);
            return ok("");
        }

        @Override public String describe() { return "say"; }
    }

    public static class Wait extends BuddyAction {
        private final int ticks;
        private int t;

        public Wait(int ticks) {
            this.ticks = ticks;
        }

        @Override
        public Status tick(BuddyEntity e) {
            return ++t >= ticks ? ok("waited") : Status.RUNNING;
        }

        @Override public String describe() { return "wait(" + ticks / 20 + "s)"; }
    }

    public static class Goto extends BuddyAction {
        private final BlockPos pos;
        private int ticks, fails;

        public Goto(BlockPos pos) {
            this.pos = pos;
        }

        @Override
        public Status tick(BuddyEntity e) {
            ticks++;
            double dx = e.getX() - (pos.getX() + 0.5D);
            double dz = e.getZ() - (pos.getZ() + 0.5D);
            if (dx * dx + dz * dz <= 2.25D && Math.abs(e.getY() - pos.getY()) <= 2.0D) {
                e.mode = BuddyEntity.Mode.STAY;
                e.getNavigation().stop();
                return ok("arrived at " + posStr(pos));
            }
            if (ticks > 1800) return fail("took too long to reach " + posStr(pos));
            if (e.getNavigation().isDone() && ticks % 10 == 1) {
                boolean started = e.getNavigation().moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, 1.1D);
                if (!started || e.getNavigation().isDone()) {
                    if (++fails >= 5) return fail("no walkable path to " + posStr(pos));
                } else {
                    fails = 0;
                }
            }
            return Status.RUNNING;
        }

        @Override public String describe() { return "goto(" + posStr(pos) + ")"; }
    }

    public static class GotoPlayer extends BuddyAction {
        private int ticks;

        @Override
        public Status tick(BuddyEntity e) {
            ServerPlayer o = e.getOwnerPlayer();
            if (o == null || o.level() != e.level()) return fail("the player is not in my dimension");
            float d = e.distanceTo(o);
            if (d <= 3.0F) {
                e.getNavigation().stop();
                return ok("reached the player");
            }
            if (++ticks > 1800) return fail("could not reach the player");
            if (d > 40.0F && BuddyConfig.TELEPORT_IF_FAR.get()) {
                e.moveTo(o.getX(), o.getY(), o.getZ());
                return Status.RUNNING;
            }
            if (ticks % 10 == 1) e.getNavigation().moveTo(o, 1.2D);
            return Status.RUNNING;
        }

        @Override public String describe() { return "goto_player"; }
    }

    // ================================================================== mining

    public static class Mine extends BuddyAction {
        private final BlockPos pos;
        private MineTask task;
        private int ticks;
        private String name = "block";

        public Mine(BlockPos pos) {
            this.pos = pos;
        }

        @Override
        public Status tick(BuddyEntity e) {
            if (++ticks > 1800) return fail("timeout while mining at " + posStr(pos));
            if (task == null) {
                BlockState s = e.level().getBlockState(pos);
                if (s.isAir()) return ok("nothing to mine at " + posStr(pos));
                name = blockName(s);
                if (!inReach(e, pos)) {
                    if (ticks % 10 == 1) {
                        BlockPos stand = standSpot(e, pos);
                        BlockPos goal = stand != null ? stand : pos;
                        e.getNavigation().moveTo(goal.getX() + 0.5D, goal.getY(), goal.getZ() + 0.5D, 1.0D);
                    }
                    return Status.RUNNING;
                }
                e.getNavigation().stop();
                task = new MineTask(e, pos);
            }
            return switch (task.tick()) {
                case WORKING -> Status.RUNNING;
                case DONE -> ok("mined " + name + " at " + posStr(pos));
                case FAILED -> fail(task.error);
            };
        }

        @Override public String describe() { return "mine(" + posStr(pos) + ")"; }
    }

    /** Finds and mines the nearest N blocks matching a predicate; can dig tunnels toward enclosed blocks. */
    public static class Collect extends BuddyAction {
        private final String label;
        private final Predicate<BlockState> matcher;
        private final int count, radius;
        private int collected, ticks, targetTicks, fails, dug;
        private BlockPos target;
        private MineTask task;
        private boolean taskIsTarget, digging;
        private String lastError = "";
        private final Set<BlockPos> bad = new HashSet<>();
        private final Deque<BlockPos> extra = new ArrayDeque<>();

        public Collect(String label, Predicate<BlockState> matcher, int count, int radius) {
            this.label = label;
            this.matcher = matcher;
            this.count = count;
            this.radius = radius;
        }

        private Status finish(String why) {
            if (collected > 0) return ok("collected " + collected + "/" + count + " " + label + " (" + why + ")");
            return fail(why + (lastError.isEmpty() ? "" : "; last problem: " + lastError));
        }

        @Override
        public Status tick(BuddyEntity e) {
            if (collected >= count) return ok("collected " + collected + " " + label);
            if (++ticks > 9000) return finish("ran out of time");
            Level level = e.level();

            if (task != null) {
                MineTask.State st = task.tick();
                if (st == MineTask.State.WORKING) return Status.RUNNING;
                if (st == MineTask.State.DONE) {
                    if (taskIsTarget) {
                        collected++;
                        target = null;
                        digging = false;
                        dug = 0;
                    }
                } else {
                    lastError = task.error;
                    bad.add(target);
                    target = null;
                    digging = false;
                    extra.clear();
                }
                task = null;
                return Status.RUNNING;
            }

            if (!extra.isEmpty()) {
                BlockPos p = extra.poll();
                if (!level.getBlockState(p).isAir() && inReach(e, p)) {
                    task = new MineTask(e, p);
                    taskIsTarget = false;
                }
                return Status.RUNNING;
            }

            if (target == null) {
                target = find(e);
                targetTicks = 0;
                fails = 0;
                digging = false;
                dug = 0;
                if (target == null) return finish("no " + label + " found within " + radius + " blocks");
            }

            if (!matcher.test(level.getBlockState(target))) {
                target = null;
                return Status.RUNNING;
            }
            if (++targetTicks > 1500) {
                lastError = "could not get to the block in time";
                bad.add(target);
                target = null;
                return Status.RUNNING;
            }
            if (inReach(e, target)) {
                e.getNavigation().stop();
                task = new MineTask(e, target);
                taskIsTarget = true;
                return Status.RUNNING;
            }

            if (!digging) {
                if (e.getNavigation().isDone() && targetTicks % 10 == 1) {
                    BlockPos stand = standSpot(e, target);
                    boolean started = false;
                    if (stand != null) {
                        started = e.getNavigation().moveTo(stand.getX() + 0.5D, stand.getY(), stand.getZ() + 0.5D, 1.0D);
                    }
                    if (!started || e.getNavigation().isDone()) {
                        if (++fails >= 4) {
                            if (BuddyConfig.ALLOW_DIGGING.get()) {
                                digging = true;
                            } else {
                                lastError = "no walkable path and digging is disabled";
                                bad.add(target);
                                target = null;
                            }
                        }
                    } else {
                        fails = 0;
                    }
                }
                return Status.RUNNING;
            }
            return digStep(e);
        }

        private Status digStep(BuddyEntity e) {
            Level level = e.level();
            if (dug > 120) {
                lastError = "tunnel got too long";
                bad.add(target);
                target = null;
                return Status.RUNNING;
            }
            Vec3 eye = e.getEyePosition();
            Vec3 tc = Vec3.atCenterOf(target);
            BlockHitResult hit = level.clip(new ClipContext(eye, tc, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, e));
            BlockPos blocker = hit.getType() == HitResult.Type.MISS ? null : hit.getBlockPos();
            if (blocker == null || blocker.equals(target)) {
                e.getMoveControl().setWantedPosition(tc.x, tc.y - 0.5D, tc.z, 1.0D);
                return Status.RUNNING;
            }
            if (!inReach(e, blocker)) {
                e.getMoveControl().setWantedPosition(tc.x, e.getY(), tc.z, 0.8D);
                return Status.RUNNING;
            }
            task = new MineTask(e, blocker);
            taskIsTarget = false;
            dug++;
            BlockPos companion = blocker.getY() > e.blockPosition().getY() ? blocker.below() : blocker.above();
            if (level.getBlockState(companion).blocksMotion()) extra.add(companion);
            return Status.RUNNING;
        }

        private BlockPos find(BuddyEntity e) {
            Level level = e.level();
            BlockPos c = e.blockPosition();
            int vr = Math.min(radius, 16);
            BlockPos best = null;
            double bestScore = Double.MAX_VALUE;
            BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    for (int dy = -vr; dy <= vr; dy++) {
                        double d = dx * dx + dy * dy + dz * dz;
                        if (d > (double) radius * radius || d >= bestScore) continue;
                        m.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                        if (!level.isLoaded(m)) continue;
                        if (!matcher.test(level.getBlockState(m))) continue;
                        BlockPos im = m.immutable();
                        if (bad.contains(im)) continue;
                        double score = d + (exposed(level, im) ? 0 : 100);
                        if (score < bestScore) {
                            bestScore = score;
                            best = im;
                        }
                    }
                }
            }
            return best;
        }

        @Override public String describe() { return "collect(" + label + " x" + count + ")"; }
    }

    // ================================================================== building

    public static class Place extends BuddyAction {
        private final Item item;
        private final BlockPos pos;
        private int ticks;

        public Place(Item item, BlockPos pos) {
            this.item = item;
            this.pos = pos;
        }

        @Override
        public Status tick(BuddyEntity e) {
            String name = itemName(item);
            if (!(item instanceof BlockItem blockItem)) return fail(name + " is not a placeable block");
            if (++ticks > 300) return fail("could not place " + name + " at " + posStr(pos));
            Level level = e.level();
            BlockState cur = level.getBlockState(pos);
            if (cur.is(blockItem.getBlock())) return ok("placed " + name + " at " + posStr(pos));
            if (!cur.canBeReplaced()) return fail("position " + posStr(pos) + " is occupied by " + blockName(cur));
            if (!inReach(e, pos)) {
                if (ticks % 10 == 1) e.getNavigation().moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, 1.0D);
                return Status.RUNNING;
            }
            if (e.getBoundingBox().intersects(new AABB(pos))) {
                if (ticks % 10 == 0) nudge(e);
                return Status.RUNNING;
            }
            int slot = e.findItemSlot(item);
            if (slot < 0) return fail("no " + name + " in inventory");
            ItemStack stack = e.inventory.getItem(slot);
            Direction face = Direction.getNearest((float) (pos.getX() + 0.5D - e.getX()), 0.0F,
                    (float) (pos.getZ() + 0.5D - e.getZ()));
            InteractionResult r = blockItem.place(new DirectionalPlaceContext(level, pos, face, stack, Direction.UP));
            if (stack.isEmpty()) e.inventory.setItem(slot, ItemStack.EMPTY);
            if (r.consumesAction()) {
                e.swing(InteractionHand.MAIN_HAND);
                return ok("placed " + name + " at " + posStr(pos));
            }
            return fail("cannot place " + name + " at " + posStr(pos));
        }

        @Override public String describe() { return "place(" + itemName(item) + " at " + posStr(pos) + ")"; }
    }

    public static class Fill extends BuddyAction {
        private final Item item;
        private final BlockPos a, b;
        private final boolean hollow;
        private List<BlockPos> todo;
        private int idx, placed, skipped, wait;
        private Place sub;

        public Fill(Item item, BlockPos a, BlockPos b, boolean hollow) {
            this.item = item;
            this.a = a;
            this.b = b;
            this.hollow = hollow;
        }

        @Override
        public Status tick(BuddyEntity e) {
            if (!(item instanceof BlockItem blockItem)) return fail(itemName(item) + " is not a placeable block");
            if (todo == null) {
                int x1 = Math.min(a.getX(), b.getX()), x2 = Math.max(a.getX(), b.getX());
                int y1 = Math.min(a.getY(), b.getY()), y2 = Math.max(a.getY(), b.getY());
                int z1 = Math.min(a.getZ(), b.getZ()), z2 = Math.max(a.getZ(), b.getZ());
                long volume = (long) (x2 - x1 + 1) * (y2 - y1 + 1) * (z2 - z1 + 1);
                if (volume > 800) return fail("fill volume " + volume + " is too large (max 800 blocks)");
                todo = new ArrayList<>();
                for (int y = y1; y <= y2; y++) {
                    for (int x = x1; x <= x2; x++) {
                        for (int z = z1; z <= z2; z++) {
                            boolean interior = x > x1 && x < x2 && y > y1 && y < y2 && z > z1 && z < z2;
                            if (hollow && interior) continue;
                            todo.add(new BlockPos(x, y, z));
                        }
                    }
                }
            }
            if (wait > 0) {
                wait--;
                return Status.RUNNING;
            }
            if (sub == null) {
                while (idx < todo.size()) {
                    BlockPos p = todo.get(idx++);
                    BlockState s = e.level().getBlockState(p);
                    if (s.is(blockItem.getBlock())) continue;
                    if (!s.canBeReplaced()) {
                        skipped++;
                        continue;
                    }
                    sub = new Place(item, p);
                    break;
                }
                if (sub == null) return ok("fill done: placed " + placed + ", skipped " + skipped + " occupied");
            }
            Status st = sub.tick(e);
            if (st == Status.RUNNING) return st;
            if (st == Status.SUCCESS) {
                placed++;
                wait = 2;
            } else {
                if (sub.message().startsWith("no ")) {
                    return fail("ran out of " + itemName(item) + " after placing " + placed);
                }
                skipped++;
            }
            sub = null;
            return Status.RUNNING;
        }

        @Override public String describe() { return "fill(" + itemName(item) + " " + posStr(a) + " to " + posStr(b) + ")"; }
    }

    // ================================================================== combat

    public static class Attack extends BuddyAction {
        private final String label;
        private final Predicate<LivingEntity> matcher;
        private final int count, radius;
        private LivingEntity target;
        private int killed, ticks, cooldown;

        public Attack(String label, Predicate<LivingEntity> matcher, int count, int radius) {
            this.label = label;
            this.matcher = matcher;
            this.count = count;
            this.radius = radius;
        }

        @Override
        public void start(BuddyEntity e) {
            e.equipBestWeapon();
        }

        private Status finish(String why) {
            return killed > 0 ? ok("defeated " + killed + " " + label + " (" + why + ")") : fail(why);
        }

        @Override
        public Status tick(BuddyEntity e) {
            if (++ticks > 2400) return finish("fight took too long");
            if (target != null && (!target.isAlive() || target.isRemoved())) {
                killed++;
                target = null;
            }
            if (killed >= count) return ok("defeated " + killed + " " + label);
            if (target == null) {
                target = find(e);
                if (target == null) return finish("no " + label + " nearby");
            }
            e.getLookControl().setLookAt(target, 30.0F, 30.0F);
            double d = e.distanceToSqr(target);
            if (d > 6.25D) {
                if (ticks % 5 == 0 || e.getNavigation().isDone()) e.getNavigation().moveTo(target, 1.25D);
            } else {
                e.getNavigation().stop();
            }
            if (d <= 12.25D && cooldown <= 0 && e.hasLineOfSight(target)) {
                e.swing(InteractionHand.MAIN_HAND);
                e.doHurtTarget(target);
                cooldown = 12;
            }
            if (cooldown > 0) cooldown--;
            return Status.RUNNING;
        }

        private LivingEntity find(BuddyEntity e) {
            List<LivingEntity> list = e.level().getEntitiesOfClass(LivingEntity.class,
                    e.getBoundingBox().inflate(radius),
                    x -> x != e && x.isAlive() && !(x instanceof Player) && !(x instanceof BuddyEntity)
                            && !(x instanceof TamableAnimal t && t.isTame()) && matcher.test(x));
            LivingEntity best = null;
            double bestD = Double.MAX_VALUE;
            for (LivingEntity x : list) {
                double d = e.distanceToSqr(x);
                if (d < bestD) {
                    bestD = d;
                    best = x;
                }
            }
            return best;
        }

        @Override public String describe() { return "attack(" + label + " x" + count + ")"; }
    }

    public static class Pickup extends BuddyAction {
        private final double radius;
        private int ticks;

        public Pickup(double radius) {
            this.radius = radius;
        }

        @Override public boolean silent() { return true; }

        @Override
        public Status tick(BuddyEntity e) {
            if (++ticks > 400) return ok("");
            List<ItemEntity> list = e.level().getEntitiesOfClass(ItemEntity.class, e.getBoundingBox().inflate(radius),
                    ie -> ie.isAlive() && !e.isIgnored(ie.getUUID()));
            if (list.isEmpty()) return ok("picked up nearby items");
            ItemEntity best = null;
            double bestD = Double.MAX_VALUE;
            for (ItemEntity ie : list) {
                double d = e.distanceToSqr(ie);
                if (d < bestD) {
                    bestD = d;
                    best = ie;
                }
            }
            if (ticks % 10 == 1) e.getNavigation().moveTo(best, 1.2D);
            return Status.RUNNING;
        }

        @Override public String describe() { return "pickup"; }
    }

    // ================================================================== inventory actions

    public static class Equip extends BuddyAction {
        private final Item item;

        public Equip(Item item) {
            this.item = item;
        }

        @Override
        public Status tick(BuddyEntity e) {
            int slot = e.findItemSlot(item);
            if (slot < 0) {
                return e.getMainHandItem().getItem() == item ? ok("already holding " + itemName(item))
                        : fail("no " + itemName(item) + " in inventory");
            }
            ItemStack s = e.inventory.getItem(slot);
            EquipmentSlot es = LivingEntity.getEquipmentSlotForItem(s);
            ItemStack cur = e.getItemBySlot(es);
            e.inventory.setItem(slot, cur);
            e.setItemSlot(es, s);
            return ok("equipped " + itemName(item));
        }

        @Override public String describe() { return "equip(" + itemName(item) + ")"; }
    }

    public static class Eat extends BuddyAction {
        @Override
        public Status tick(BuddyEntity e) {
            return e.tryEat() ? ok("ate something") : fail("no food in inventory");
        }

        @Override public String describe() { return "eat"; }
    }

    public static class Give extends BuddyAction {
        private final String label;
        private final Predicate<ItemStack> matcher;
        private final int count;
        private int ticks;

        public Give(String label, Predicate<ItemStack> matcher, int count) {
            this.label = label;
            this.matcher = matcher;
            this.count = count;
        }

        @Override
        public Status tick(BuddyEntity e) {
            ServerPlayer owner = e.getOwnerPlayer();
            if (owner == null || owner.level() != e.level()) return fail("the player is not near me");
            if (e.distanceTo(owner) > 3.0F) {
                if (++ticks > 1800) return fail("could not reach the player");
                if (ticks % 10 == 1) e.getNavigation().moveTo(owner, 1.2D);
                return Status.RUNNING;
            }
            int want = count <= 0 ? Integer.MAX_VALUE : count;
            int given = 0;
            for (int i = 0; i < e.inventory.getContainerSize() && given < want; i++) {
                ItemStack s = e.inventory.getItem(i);
                if (s.isEmpty() || !matcher.test(s)) continue;
                int take = Math.min(want - given, s.getCount());
                ItemStack out = s.split(take);
                if (s.isEmpty()) e.inventory.setItem(i, ItemStack.EMPTY);
                e.throwItem(out, owner);
                given += take;
            }
            return given > 0 ? ok("gave the player " + given + " " + label) : fail("I have no " + label);
        }

        @Override public String describe() { return "give(" + label + ")"; }
    }

    public static class Drop extends BuddyAction {
        private final String label;
        private final Predicate<ItemStack> matcher;
        private final int count;

        public Drop(String label, Predicate<ItemStack> matcher, int count) {
            this.label = label;
            this.matcher = matcher;
            this.count = count;
        }

        @Override
        public Status tick(BuddyEntity e) {
            int want = count <= 0 ? Integer.MAX_VALUE : count;
            int dropped = 0;
            for (int i = 0; i < e.inventory.getContainerSize() && dropped < want; i++) {
                ItemStack s = e.inventory.getItem(i);
                if (s.isEmpty() || !matcher.test(s)) continue;
                int take = Math.min(want - dropped, s.getCount());
                ItemStack out = s.split(take);
                if (s.isEmpty()) e.inventory.setItem(i, ItemStack.EMPTY);
                e.throwItem(out, null);
                dropped += take;
            }
            return dropped > 0 ? ok("dropped " + dropped + " " + label) : fail("I have no " + label);
        }

        @Override public String describe() { return "drop(" + label + ")"; }
    }

    // ================================================================== crafting & smelting

    public static class Craft extends BuddyAction {
        private final Item item;
        private final int count;
        private int crafted, ticks;
        private List<CraftingRecipe> recipes;

        public Craft(Item item, int count) {
            this.item = item;
            this.count = count;
        }

        @Override
        public Status tick(BuddyEntity e) {
            String name = itemName(item);
            if (++ticks > 700) return fail("crafting took too long");
            if (crafted >= count) return ok("crafted " + crafted + " " + name);
            Level level = e.level();
            if (recipes == null) {
                e.stashHands();
                recipes = level.getRecipeManager().getAllRecipesFor(RecipeType.CRAFTING).stream()
                        .filter(r -> !r.isSpecial() && r.getResultItem(level.registryAccess()).is(item))
                        .collect(Collectors.toList());
            }
            if (recipes.isEmpty()) return fail("there is no crafting recipe for " + name);

            CraftingRecipe usable = null;
            for (CraftingRecipe r : recipes) {
                if (consume(e, r, true)) {
                    usable = r;
                    break;
                }
            }
            if (usable == null) {
                String need = ingredientText(recipes.get(0));
                return fail((crafted > 0 ? "crafted " + crafted + " " + name + " but then " : "")
                        + "missing materials for " + name + ". One recipe needs: " + need + " (* = any matching variant)");
            }
            if (!fitsInventory(usable)) {
                BlockPos table = findNear(e, Blocks.CRAFTING_TABLE, 4);
                if (table == null) {
                    BlockPos far = findNear(e, Blocks.CRAFTING_TABLE, 24);
                    if (far == null) {
                        return fail(name + " needs a crafting_table nearby. Craft one (4 planks) and place it first");
                    }
                    if (ticks % 10 == 1) e.getNavigation().moveTo(far.getX() + 0.5D, far.getY(), far.getZ() + 0.5D, 1.0D);
                    return Status.RUNNING;
                }
            }
            consume(e, usable, false);
            ItemStack out = usable.getResultItem(level.registryAccess()).copy();
            e.giveOrDrop(out);
            crafted += out.getCount();
            e.swing(InteractionHand.MAIN_HAND);
            return Status.RUNNING;
        }

        private static boolean fitsInventory(CraftingRecipe r) {
            if (r instanceof ShapedRecipe s) return s.getWidth() <= 2 && s.getHeight() <= 2;
            return r.getIngredients().size() <= 4;
        }

        private static boolean consume(BuddyEntity e, CraftingRecipe r, boolean dry) {
            SimpleContainer inv = e.inventory;
            int[] used = new int[inv.getContainerSize()];
            for (Ingredient ing : r.getIngredients()) {
                if (ing.isEmpty()) continue;
                boolean found = false;
                for (int i = 0; i < used.length; i++) {
                    ItemStack s = inv.getItem(i);
                    if (!s.isEmpty() && s.getCount() - used[i] > 0 && ing.test(s)) {
                        used[i]++;
                        found = true;
                        break;
                    }
                }
                if (!found) return false;
            }
            if (!dry) {
                for (int i = 0; i < used.length; i++) {
                    if (used[i] == 0) continue;
                    ItemStack s = inv.getItem(i);
                    Item it = s.getItem();
                    s.shrink(used[i]);
                    if (s.isEmpty()) inv.setItem(i, ItemStack.EMPTY);
                    if (it.hasCraftingRemainingItem()) {
                        for (int k = 0; k < used[i]; k++) e.giveOrDrop(new ItemStack(it.getCraftingRemainingItem()));
                    }
                }
            }
            return true;
        }

        private static String ingredientText(CraftingRecipe r) {
            Map<String, Integer> m = new LinkedHashMap<>();
            for (Ingredient ing : r.getIngredients()) {
                if (ing.isEmpty()) continue;
                ItemStack[] items = ing.getItems();
                if (items.length == 0) continue;
                m.merge(itemName(items[0].getItem()) + (items.length > 1 ? "*" : ""), 1, Integer::sum);
            }
            return m.entrySet().stream().map(en -> en.getKey() + " x" + en.getValue()).collect(Collectors.joining(", "));
        }

        @Override public String describe() { return "craft(" + itemName(item) + " x" + count + ")"; }
    }

    public static class Smelt extends BuddyAction {
        private final Item input;
        private final int count;
        private int phase, ticks, loaded, collected, waited;
        private BlockPos furnace;

        public Smelt(Item input, int count) {
            this.input = input;
            this.count = count;
        }

        @Override
        public Status tick(BuddyEntity e) {
            String name = itemName(input);
            if (++ticks > 9000) return fail("smelting took too long");
            Level level = e.level();

            if (phase == 0) {
                e.stashHands();
                Optional<SmeltingRecipe> rec = level.getRecipeManager()
                        .getRecipeFor(RecipeType.SMELTING, new SimpleContainer(new ItemStack(input)), level);
                if (rec.isEmpty()) return fail(name + " cannot be smelted");
                furnace = findNear(e, Blocks.FURNACE, 24);
                if (furnace == null) return fail("no furnace within 24 blocks. Craft one (8 cobblestone) and place it first");
                phase = 1;
                return Status.RUNNING;
            }

            if (e.distanceToSqr(Vec3.atCenterOf(furnace)) > 9.0D) {
                if (ticks % 10 == 1) e.getNavigation().moveTo(furnace.getX() + 0.5D, furnace.getY(), furnace.getZ() + 0.5D, 1.0D);
                return Status.RUNNING;
            }
            e.getNavigation().stop();
            if (!(level.getBlockEntity(furnace) instanceof AbstractFurnaceBlockEntity f)) return fail("the furnace disappeared");

            if (phase == 1) {
                ItemStack in = f.getItem(0);
                if (!in.isEmpty() && in.getItem() != input) return fail("the furnace is busy with another item");
                int n = Math.min(Math.min(count, e.countItem(input)), 64 - in.getCount());
                if (n <= 0) return fail("no " + name + " in inventory");

                ItemStack fuelSlot = f.getItem(1);
                int needTicks = n * 200;
                int haveTicks = fuelSlot.isEmpty() ? 0 : ForgeHooks.getBurnTime(fuelSlot, RecipeType.SMELTING) * fuelSlot.getCount();
                if (haveTicks < needTicks) {
                    int idx = bestFuel(e, fuelSlot);
                    if (idx < 0 && haveTicks == 0) return fail("no fuel (coal, charcoal, planks, sticks, logs) in inventory");
                    if (idx >= 0) {
                        ItemStack fs = e.inventory.getItem(idx);
                        int burn = ForgeHooks.getBurnTime(fs, RecipeType.SMELTING);
                        int need = (int) Math.ceil((needTicks - haveTicks) / (double) burn);
                        need = Math.min(Math.min(need, fs.getCount()), 64 - fuelSlot.getCount());
                        if (need > 0) {
                            ItemStack nf = fs.copy();
                            nf.setCount(need + fuelSlot.getCount());
                            f.setItem(1, nf);
                            fs.shrink(need);
                            if (fs.isEmpty()) e.inventory.setItem(idx, ItemStack.EMPTY);
                        }
                    }
                }
                e.removeItem(input, n);
                f.setItem(0, new ItemStack(input, in.getCount() + n));
                loaded = n;
                phase = 2;
                return Status.RUNNING;
            }

            // phase 2: wait and collect results
            waited++;
            if (waited % 20 == 0) {
                ItemStack out = f.getItem(2);
                if (!out.isEmpty()) {
                    ItemStack taken = f.removeItem(2, out.getCount());
                    collected += taken.getCount();
                    e.giveOrDrop(taken);
                }
            }
            boolean inputEmpty = f.getItem(0).isEmpty();
            if (collected >= loaded || (inputEmpty && f.getItem(2).isEmpty() && waited > 40)) {
                return ok("smelted " + collected + " from " + loaded + " " + name);
            }
            return Status.RUNNING;
        }

        private int bestFuel(BuddyEntity e, ItemStack current) {
            int best = -1, bestScore = 0;
            for (int i = 0; i < e.inventory.getContainerSize(); i++) {
                ItemStack s = e.inventory.getItem(i);
                if (s.isEmpty() || s.getItem() == input) continue;
                if (!current.isEmpty() && current.getItem() != s.getItem()) continue;
                if (ForgeHooks.getBurnTime(s, RecipeType.SMELTING) <= 0) continue;
                String id = itemName(s.getItem());
                int score;
                if (id.equals("charcoal") || id.equals("coal")) score = 3;
                else if (id.endsWith("planks") || id.equals("stick")) score = 2;
                else if (id.endsWith("_log") || id.endsWith("_wood")) score = 1;
                else continue;
                if (score > bestScore) {
                    bestScore = score;
                    best = i;
                }
            }
            return best;
        }

        @Override public String describe() { return "smelt(" + itemName(input) + " x" + count + ")"; }
    }
}
