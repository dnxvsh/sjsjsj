package com.stevebuddy.action;

import com.stevebuddy.entity.BuddyEntity;

/** One step Steve can perform (his "hands"). Ticked every game tick until it stops returning RUNNING. */
public abstract class BuddyAction {
    public enum Status { RUNNING, SUCCESS, FAILED }

    protected String message = "";

    public String message() {
        return message;
    }

    /** Silent actions are not reported back to the AI as results. */
    public boolean silent() {
        return false;
    }

    public void start(BuddyEntity e) {
    }

    public abstract Status tick(BuddyEntity e);

    public void stop(BuddyEntity e) {
        e.getNavigation().stop();
    }

    public abstract String describe();

    protected Status ok(String m) {
        message = m;
        return Status.SUCCESS;
    }

    protected Status fail(String m) {
        message = m;
        return Status.FAILED;
    }
}
