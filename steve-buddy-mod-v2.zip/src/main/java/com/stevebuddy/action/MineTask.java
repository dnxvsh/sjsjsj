package com.stevebuddy.action;

import com.stevebuddy.BuddyConfig;
import com.stevebuddy.entity.BuddyEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Breaks one block over time like a survival player (tool speed, drops, tool damage). */
public class MineTask {
    public enum State { WORKING, DONE, FAILED }

    private final BuddyEntity e;
    private final BlockPos pos;
    private int progress = -1;
    private int needed = 1;
    public String error = "";

    public MineTask(BuddyEntity e, BlockPos pos) {
        this.e = e;
        this.pos = pos;
    }

    public State tick() {
        if (!(e.level() instanceof ServerLevel level)) return State.FAILED;
        BlockState state = level.getBlockState(pos);
        if (state.isAir()) return State.DONE;

        if (progress < 0) {
            String name = Actions.blockName(state);
            if (state.getBlock() instanceof LiquidBlock) {
                error = "cannot mine liquid (" + name + ")";
                return State.FAILED;
            }
            float hardness = state.getDestroySpeed(level, pos);
            if (hardness < 0) {
                error = name + " is unbreakable";
                return State.FAILED;
            }
            if (nearLava(level)) {
                error = "lava next to " + name + " at " + pos.getX() + "," + pos.getY() + "," + pos.getZ() + " - refusing to mine";
                return State.FAILED;
            }
            e.equipBestToolFor(state);
            ItemStack tool = e.getMainHandItem();
            float speed = tool.getDestroySpeed(state);
            if (speed > 1.0F) {
                int eff = EnchantmentHelper.getBlockEfficiency(e);
                if (eff > 0) speed += eff * eff + 1;
            }
            speed *= BuddyConfig.MINING_SPEED.get().floatValue();
            boolean correct = !state.requiresCorrectToolForDrops() || tool.isCorrectToolForDrops(state);
            float perTick = hardness == 0.0F ? 1.0F : speed / hardness / (correct ? 30.0F : 100.0F);
            needed = Math.min(600, Math.max(1, (int) Math.ceil(1.0F / Math.max(perTick, 0.0001F))));
            progress = 0;
        }

        e.getLookControl().setLookAt(Vec3.atCenterOf(pos));
        if (progress % 6 == 0) {
            e.swing(InteractionHand.MAIN_HAND);
            level.playSound(null, pos, state.getSoundType().getHitSound(), SoundSource.BLOCKS, 0.4F, 0.8F);
        }
        level.destroyBlockProgress(e.getId(), pos, Math.min(9, progress * 10 / needed));
        progress++;

        if (progress >= needed) {
            harvest(level, state);
            level.destroyBlockProgress(e.getId(), pos, -1);
            return State.DONE;
        }
        return State.WORKING;
    }

    private void harvest(ServerLevel level, BlockState state) {
        ItemStack tool = e.getMainHandItem();
        boolean correct = !state.requiresCorrectToolForDrops() || tool.isCorrectToolForDrops(state);
        BlockEntity be = level.getBlockEntity(pos);
        if (correct) {
            for (ItemStack drop : Block.getDrops(state, level, pos, be, e, tool)) {
                e.giveOrDrop(drop);
            }
        }
        level.destroyBlock(pos, false, e);
        if (!tool.isEmpty() && tool.isDamageableItem() && state.getDestroySpeed(level, pos) > 0) {
            tool.hurtAndBreak(1, e, x -> x.broadcastBreakEvent(EquipmentSlot.MAINHAND));
        }
    }

    private boolean nearLava(ServerLevel level) {
        for (Direction d : Direction.values()) {
            if (level.getFluidState(pos.relative(d)).is(FluidTags.LAVA)) return true;
        }
        return false;
    }
}
