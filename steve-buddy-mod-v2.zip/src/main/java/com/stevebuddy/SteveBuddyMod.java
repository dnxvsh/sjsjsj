package com.stevebuddy;

import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(SteveBuddyMod.MOD_ID)
public class SteveBuddyMod {
    public static final String MOD_ID = "stevebuddy";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SteveBuddyMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModRegistry.register(modBus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, BuddyConfig.SPEC);
        MinecraftForge.EVENT_BUS.register(new ChatHandler());
    }
}
