package com.stevebuddy;

import com.stevebuddy.entity.BuddyEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRegistry {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SteveBuddyMod.MOD_ID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SteveBuddyMod.MOD_ID);

    public static final RegistryObject<EntityType<BuddyEntity>> BUDDY = ENTITIES.register("steve_buddy",
            () -> EntityType.Builder.<BuddyEntity>of(BuddyEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build("steve_buddy"));

    public static final RegistryObject<Item> BUDDY_EGG = ITEMS.register("steve_buddy_spawn_egg",
            () -> new ForgeSpawnEggItem(BUDDY, 0x3FA7A3, 0x6B4A2F, new Item.Properties()));

    public static void register(IEventBus bus) {
        ENTITIES.register(bus);
        ITEMS.register(bus);
        bus.addListener(ModRegistry::onAttributes);
        bus.addListener(ModRegistry::onCreativeTab);
    }

    private static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(BUDDY.get(), BuddyEntity.createAttributes().build());
    }

    private static void onCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(BUDDY_EGG);
        }
    }

    private ModRegistry() {}
}
